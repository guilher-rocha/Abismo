// server/lan.ts
import { createServer } from "node:http";
import { readFile } from "node:fs/promises";
import { existsSync } from "node:fs";
import { dirname, extname, join, normalize, resolve, sep } from "node:path";
import { networkInterfaces } from "node:os";
import { fileURLToPath } from "node:url";
import { WebSocketServer } from "ws";

// src/engine/rng.ts
var RNG = class _RNG {
  state;
  constructor(seed) {
    this.state = typeof seed === "string" ? hashString(seed) : seed >>> 0;
  }
  /** Float em [0, 1). */
  next() {
    this.state = this.state + 1831565813 >>> 0;
    let t = this.state;
    t = Math.imul(t ^ t >>> 15, t | 1);
    t ^= t + Math.imul(t ^ t >>> 7, t | 61);
    return ((t ^ t >>> 14) >>> 0) / 4294967296;
  }
  /** Inteiro em [min, max] (inclusivo). */
  int(min, max) {
    return min + Math.floor(this.next() * (max - min + 1));
  }
  /** true com probabilidade `percent`% (0–100). */
  chance(percent) {
    return this.next() * 100 < percent;
  }
  pick(list) {
    if (list.length === 0) throw new Error("pick() em lista vazia");
    return list[Math.floor(this.next() * list.length)];
  }
  /** Escolha ponderada: cada item tem um peso >= 0. */
  weighted(entries) {
    const total = entries.reduce((s, e) => s + Math.max(0, e.weight), 0);
    if (total <= 0) throw new Error("weighted() sem pesos positivos");
    let r = this.next() * total;
    for (const e of entries) {
      r -= Math.max(0, e.weight);
      if (r < 0) return e.item;
    }
    return entries[entries.length - 1].item;
  }
  /** Embaralha uma cópia da lista (Fisher-Yates). */
  shuffle(list) {
    const a = list.slice();
    for (let i = a.length - 1; i > 0; i--) {
      const j = Math.floor(this.next() * (i + 1));
      [a[i], a[j]] = [a[j], a[i]];
    }
    return a;
  }
  /** Rola dados em notação "XdY+Z" (também aceita "XdY-Z", "dY", "Z"). */
  roll(expr) {
    const d = parseDice(expr);
    let total = d.bonus;
    for (let i = 0; i < d.count; i++) total += this.int(1, d.sides);
    return total;
  }
  /** Cria um RNG derivado e independente (para separar "fluxos": mapa, combate, loot...). */
  fork(label) {
    return new _RNG((hashString(label) ^ this.int(0, 2147483647)) >>> 0);
  }
};
function parseDice(expr) {
  const m2 = /^\s*(\d*)d(\d+)\s*([+-]\s*\d+)?\s*$/i.exec(expr);
  if (m2) {
    return {
      count: m2[1] === "" ? 1 : Number(m2[1]),
      sides: Number(m2[2]),
      bonus: m2[3] ? Number(m2[3].replace(/\s/g, "")) : 0
    };
  }
  const n = Number(expr);
  if (!Number.isNaN(n)) return { count: 0, sides: 0, bonus: n };
  throw new Error(`Nota\xE7\xE3o de dados inv\xE1lida: ${expr}`);
}
function diceToString(d) {
  if (d.count === 0) return String(d.bonus);
  const b2 = d.bonus === 0 ? "" : d.bonus > 0 ? `+${d.bonus}` : String(d.bonus);
  return `${d.count}d${d.sides}${b2}`;
}
function hashString(s) {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

// src/data/tiles.ts
var Tile = {
  Wall: 0,
  Floor: 1,
  Corridor: 2,
  DoorClosed: 3,
  DoorOpen: 4,
  StairsDown: 5,
  StairsUp: 6,
  Water: 7,
  Lava: 8,
  SecretDoor: 9,
  Fountain: 10,
  Altar: 11,
  Fungus: 12,
  Rubble: 13,
  DoorLocked: 14,
  DryFountain: 15
};
var TILES = {
  [Tile.Wall]: { name: "parede", glyph: "#", fg: "lightGray", bg: "black", walkable: false, transparent: false },
  [Tile.Floor]: { name: "ch\xE3o", glyph: ".", fg: "lightGray", bg: "black", walkable: true, transparent: true },
  [Tile.Corridor]: { name: "corredor", glyph: ".", fg: "darkGray", bg: "black", walkable: true, transparent: true },
  [Tile.DoorClosed]: { name: "porta fechada", glyph: "+", fg: "brown", bg: "black", walkable: false, transparent: false },
  [Tile.DoorOpen]: { name: "porta aberta", glyph: "'", fg: "brown", bg: "black", walkable: true, transparent: true },
  [Tile.StairsDown]: { name: "escada para baixo", glyph: ">", fg: "white", bg: "black", walkable: true, transparent: true },
  [Tile.StairsUp]: { name: "escada para cima", glyph: "<", fg: "white", bg: "black", walkable: true, transparent: true },
  [Tile.Water]: { name: "\xE1gua", glyph: "~", fg: "lightBlue", bg: "darkBlue", walkable: true, transparent: true },
  [Tile.Lava]: { name: "lava", glyph: "~", fg: "orange", bg: "darkRed", walkable: true, transparent: true },
  [Tile.SecretDoor]: { name: "parede", glyph: "#", fg: "lightGray", bg: "black", walkable: false, transparent: false },
  [Tile.Fountain]: { name: "fonte", glyph: "{", fg: "lightCyan", bg: "black", walkable: true, transparent: true },
  [Tile.Altar]: { name: "altar", glyph: "_", fg: "white", bg: "black", walkable: true, transparent: true },
  [Tile.Fungus]: { name: "fungo gigante", glyph: "&", fg: "green", bg: "black", walkable: false, transparent: false },
  [Tile.Rubble]: { name: "escombros", glyph: ":", fg: "brown", bg: "black", walkable: true, transparent: true },
  [Tile.DoorLocked]: { name: "porta trancada", glyph: "+", fg: "yellow", bg: "black", walkable: false, transparent: false },
  [Tile.DryFountain]: { name: "fonte seca", glyph: "{", fg: "darkGray", bg: "black", walkable: true, transparent: true }
};
function tileDef(id) {
  return TILES[id] ?? TILES[Tile.Wall];
}

// src/core/map.ts
var MAP_W = 80;
var MAP_H = 24;
function createMap(width = MAP_W, height = MAP_H, fill = Tile.Wall) {
  const n = width * height;
  return {
    width,
    height,
    tiles: new Array(n).fill(fill),
    explored: new Array(n).fill(0),
    visible: new Array(n).fill(0),
    lit: new Array(n).fill(0)
  };
}
function inBounds(map, x, y) {
  return x >= 0 && y >= 0 && x < map.width && y < map.height;
}
function idx(map, x, y) {
  return y * map.width + x;
}
function getTile(map, x, y) {
  return inBounds(map, x, y) ? map.tiles[idx(map, x, y)] : Tile.Wall;
}
function setTile(map, x, y, t) {
  if (inBounds(map, x, y)) map.tiles[idx(map, x, y)] = t;
}
function isWalkable(map, x, y) {
  return inBounds(map, x, y) && tileDef(getTile(map, x, y)).walkable;
}
function isTransparent(map, x, y) {
  return inBounds(map, x, y) && tileDef(getTile(map, x, y)).transparent;
}
var CHAR_TO_TILE = {
  "#": Tile.Wall,
  ".": Tile.Floor,
  ",": Tile.Corridor,
  "+": Tile.DoorClosed,
  "'": Tile.DoorOpen,
  ">": Tile.StairsDown,
  "<": Tile.StairsUp,
  "~": Tile.Water,
  "{": Tile.Fountain,
  "_": Tile.Altar,
  "&": Tile.Fungus,
  ":": Tile.Rubble
};
var DIRS8 = [
  { x: 0, y: -1 },
  { x: 1, y: -1 },
  { x: 1, y: 0 },
  { x: 1, y: 1 },
  { x: 0, y: 1 },
  { x: -1, y: 1 },
  { x: -1, y: 0 },
  { x: -1, y: -1 }
];
var DIRS4 = [
  { x: 0, y: -1 },
  { x: 1, y: 0 },
  { x: 0, y: 1 },
  { x: -1, y: 0 }
];
function distance(a, b2) {
  return Math.max(Math.abs(a.x - b2.x), Math.abs(a.y - b2.y));
}

// src/core/log.ts
var MAX_LOG = 300;
function pushMessage(log, text, color, turn, who) {
  const last = log[log.length - 1];
  if (last && last.text === text && last.who === who && last.turn >= turn - 1) {
    last.count++;
    last.turn = turn;
    return;
  }
  log.push(who === void 0 ? { text, color, turn, count: 1 } : { text, color, turn, count: 1, who });
  if (log.length > MAX_LOG) log.splice(0, log.length - MAX_LOG);
}

// src/core/fov.ts
var MULT = [
  [1, 0, 0, -1, -1, 0, 0, 1],
  [0, 1, -1, 0, 0, -1, 1, 0],
  [0, 1, 1, 0, 0, -1, -1, 0],
  [1, 0, 0, 1, -1, 0, 0, -1]
];
function computeFov(ox, oy, radius, blocks, visit) {
  visit(ox, oy);
  for (let oct = 0; oct < 8; oct++) {
    castLight(ox, oy, 1, 1, 0, radius, MULT[0][oct], MULT[1][oct], MULT[2][oct], MULT[3][oct], blocks, visit);
  }
}
function castLight(cx, cy, row, start, end, radius, xx, xy, yx, yy, blocks, visit) {
  if (start < end) return;
  const r2 = (radius + 0.5) * (radius + 0.5);
  let newStart = 0;
  for (let j = row; j <= radius; j++) {
    let dx = -j - 1;
    const dy = -j;
    let blocked = false;
    while (dx <= 0) {
      dx++;
      const X = cx + dx * xx + dy * xy;
      const Y = cy + dx * yx + dy * yy;
      const lSlope = (dx - 0.5) / (dy + 0.5);
      const rSlope = (dx + 0.5) / (dy - 0.5);
      if (start < rSlope) continue;
      if (end > lSlope) break;
      if (dx * dx + dy * dy < r2) visit(X, Y);
      if (blocked) {
        if (blocks(X, Y)) {
          newStart = rSlope;
          continue;
        }
        blocked = false;
        start = newStart;
      } else if (blocks(X, Y) && j < radius) {
        blocked = true;
        castLight(cx, cy, j + 1, start, lSlope, radius, xx, xy, yx, yy, blocks, visit);
        newStart = rSlope;
      }
    }
    if (blocked) break;
  }
}
var MAX_SIGHT = 30;
function updatePlayerFov(map, px, py, lightRadius, blind = false) {
  map.visible.fill(0);
  if (blind) {
    map.visible[idx(map, px, py)] = 1;
    return;
  }
  const blocks = (x, y) => !isTransparent(map, x, y);
  computeFov(px, py, MAX_SIGHT, blocks, (x, y) => {
    if (!inBounds(map, x, y)) return;
    const i = idx(map, x, y);
    const near = Math.max(Math.abs(x - px), Math.abs(y - py)) <= lightRadius;
    if (near || map.lit[i]) {
      map.visible[i] = 1;
      map.explored[i] = 1;
    }
  });
}
function hasLineOfSight(map, x0, y0, x1, y1) {
  for (const p of bresenham(x0, y0, x1, y1).slice(1, -1)) if (!isTransparent(map, p.x, p.y)) return false;
  return true;
}
function bresenham(x0, y0, x1, y1) {
  const pts = [];
  const dx = Math.abs(x1 - x0);
  const dy = -Math.abs(y1 - y0);
  const sx = x0 < x1 ? 1 : -1;
  const sy = y0 < y1 ? 1 : -1;
  let err = dx + dy;
  let x = x0;
  let y = y0;
  for (; ; ) {
    pts.push({ x, y });
    if (x === x1 && y === y1) break;
    const e2 = 2 * err;
    if (e2 >= dy) {
      err += dy;
      x += sx;
    }
    if (e2 <= dx) {
      err += dx;
      y += sy;
    }
  }
  return pts;
}

// src/core/events.ts
function pushEvent(events, e) {
  events.push(e);
  if (events.length > 200) events.splice(0, events.length - 200);
}

// src/core/game.ts
function createRngs(seed) {
  const root = new RNG(seed);
  return { map: root.fork("map"), combat: root.fork("combat"), loot: root.fork("loot"), ai: root.fork("ai") };
}
function level(game) {
  return game.levels[game.depth];
}
function message(game, text, color = "lightGray", who) {
  const tag = who === null ? void 0 : who ?? (game.party ? game.player.id : void 0);
  pushMessage(game.log, text, color, game.turn, tag);
}
function refreshFov(game) {
  const blind = (game.player.effects ?? []).some((e) => e.id === "blind" && e.turns > 0);
  updatePlayerFov(level(game).map, game.player.x, game.player.y, blind ? 0 : game.player.light, blind);
}
function setDeathCause(game, cause) {
  if (game.over && !game.over.won) game.over.cause = cause;
  const m2 = game.party?.members.find((x) => x.actor === game.player);
  if (m2?.dead) m2.cause = cause;
}
function emit(game, e) {
  pushEvent(game.events, e);
}
function newId(game) {
  return game.nextId++;
}
function actorAt(game, x, y) {
  const party = game.party;
  if (game.player.x === x && game.player.y === y && !(party && game.player.hp <= 0)) return game.player;
  if (party) {
    for (const m2 of party.members) if (!m2.dead && m2.actor !== game.player && m2.actor.x === x && m2.actor.y === y) return m2.actor;
  }
  return level(game).actors.find((a) => a.x === x && a.y === y);
}

// src/core/actor.ts
var ACTION_COST = 100;
var NORMAL_SPEED = 100;
function createActor(id, props) {
  return {
    id,
    gender: "m",
    x: 0,
    y: 0,
    isPlayer: false,
    speed: NORMAL_SPEED,
    energy: 0,
    hp: 1,
    maxHp: 1,
    mp: 0,
    maxMp: 0,
    level: 1,
    light: 0,
    accuracy: 0,
    defense: 0,
    attacks: [{ verb: "acerta", damage: "1d2" }],
    xpValue: 0,
    ai: { state: "wandering", lostTurns: 0 },
    flags: [],
    ...props
  };
}
function hasFlag(a, flag) {
  return a.flags.includes(flag);
}

// src/data/classes.ts
var CLASSES = [
  {
    id: "warrior",
    name: "Guerreiro",
    desc: "Mestre das armas e armaduras. Simples, resistente e mortal de perto.",
    stats: { str: 16, dex: 12, con: 15, int: 8, wis: 10 },
    hitDie: 10,
    hpBase: 12,
    castStat: null,
    mpBase: 0,
    mpPerLevel: 0,
    accuracyPerLevel: 0.9,
    startingItems: ["long_sword", "chain_mail", "small_shield", "potion_heal", "potion_heal", "ration", "ration", "torch"],
    abilities: [
      { level: 1, id: "power_strike", name: "Golpe Poderoso", desc: "Um ataque com o dobro de dano que leva 2 turnos.", active: true },
      { level: 5, id: "whirlwind", name: "Ataque Girat\xF3rio", desc: "Ataca todos os inimigos adjacentes.", active: true },
      { level: 10, id: "second_wind", name: "Segundo F\xF4lego", desc: "Recupera 30% do HP (uma vez a cada 200 turnos).", active: true },
      { level: 15, id: "extra_attack", name: "Ataque Extra", desc: "Ataques corpo a corpo custam 75% do tempo.", active: false },
      { level: 20, id: "unshakable", name: "Inabal\xE1vel", desc: "Imune a medo e confus\xE3o.", active: false }
    ],
    goodRaces: ["dwarf", "half_orc", "human"]
  },
  {
    id: "mage",
    name: "Mago",
    desc: "Estudioso das artes arcanas. Fr\xE1gil, mas devastador \xE0 dist\xE2ncia.",
    stats: { str: 8, dex: 12, con: 12, int: 16, wis: 12 },
    hitDie: 4,
    hpBase: 9,
    castStat: "int",
    mpBase: 4,
    mpPerLevel: 2,
    accuracyPerLevel: 0.4,
    startingItems: ["quarterstaff", "robe", "potion_mana", "potion_heal", "scroll_identify", "ration", "torch"],
    abilities: [
      { level: 1, id: "spellbook", name: "Grim\xF3rio", desc: "Conjura magias arcanas (tecla m). Come\xE7a com M\xEDssil M\xE1gico.", active: false },
      { level: 5, id: "arcane_sight", name: "Vis\xE3o Arcana", desc: "Identifica pergaminhos ao l\xEA-los e sente magia nos itens.", active: false },
      { level: 10, id: "mana_shield", name: "Escudo de Mana", desc: "Parte do dano recebido \xE9 absorvida pelo MP.", active: false }
    ],
    goodRaces: ["elf", "gnome", "human"]
  },
  {
    id: "rogue",
    name: "Ladino",
    desc: "Furtivo e oportunista. Ataca quem n\xE3o o v\xEA com dano triplo.",
    stats: { str: 11, dex: 16, con: 12, int: 12, wis: 10 },
    hitDie: 6,
    hpBase: 8,
    castStat: null,
    mpBase: 0,
    mpPerLevel: 0,
    accuracyPerLevel: 0.7,
    startingItems: ["dagger", "dagger", "dagger", "leather_armor", "potion_heal", "scroll_teleport", "ration", "torch"],
    abilities: [
      { level: 1, id: "sneak_attack", name: "Ataque Furtivo", desc: "Dano \xD73 contra monstros dormindo ou que n\xE3o o veem.", active: false },
      { level: 1, id: "vanish", name: "Desaparecer", desc: "Some nas sombras: os monstros perdem seu rastro.", active: true },
      { level: 5, id: "trap_sense", name: "Sentir Armadilhas", desc: "V\xEA armadilhas ocultas com facilidade.", active: false },
      { level: 10, id: "evasion", name: "Evas\xE3o", desc: "+3 de defesa.", active: false }
    ],
    goodRaces: ["halfling", "elf", "human"]
  },
  {
    id: "cleric",
    name: "Cl\xE9rigo",
    desc: "Servo dos deuses. Cura, aben\xE7oa e destr\xF3i os mortos-vivos.",
    stats: { str: 13, dex: 10, con: 13, int: 9, wis: 16 },
    hitDie: 8,
    hpBase: 10,
    castStat: "wis",
    mpBase: 3,
    mpPerLevel: 2,
    accuracyPerLevel: 0.7,
    startingItems: ["mace", "scale_mail", "potion_heal", "potion_heal", "ration", "ration", "torch"],
    abilities: [
      { level: 1, id: "prayers", name: "Ora\xE7\xF5es", desc: "Conjura magias divinas (tecla m). Come\xE7a com Cura Leve.", active: false },
      { level: 1, id: "turn_undead", name: "Expulsar Mortos-vivos", desc: "Mortos-vivos pr\xF3ximos fogem e sofrem dano sagrado.", active: true },
      { level: 10, id: "divine_favor", name: "Favor Divino", desc: "Regenera MP mais r\xE1pido.", active: false }
    ],
    goodRaces: ["dwarf", "human", "halfling"]
  },
  {
    id: "ranger",
    name: "Patrulheiro",
    desc: "Ca\xE7ador das terras selvagens. Mestre do arco e do rastreamento.",
    stats: { str: 12, dex: 15, con: 13, int: 10, wis: 13 },
    hitDie: 8,
    hpBase: 10,
    castStat: "wis",
    mpBase: 1,
    mpPerLevel: 1,
    accuracyPerLevel: 0.8,
    startingItems: ["short_bow", "arrow", "short_sword", "leather_armor", "potion_heal", "ration", "ration", "torch"],
    abilities: [
      { level: 1, id: "archery", name: "Arquearia", desc: "+3 de precis\xE3o com armas de disparo.", active: false },
      { level: 1, id: "track", name: "Rastrear", desc: "Sente todos os monstros do andar por alguns turnos.", active: true },
      { level: 5, id: "double_shot", name: "Disparo Duplo", desc: "Dispara duas flechas de uma vez.", active: true }
    ],
    goodRaces: ["elf", "halfling", "human"]
  }
];
function classById(id) {
  return CLASSES.find((c) => c.id === id) ?? CLASSES[0];
}

// src/data/races.ts
var RACES = [
  {
    id: "human",
    name: "Humano",
    desc: "Vers\xE1teis e ambiciosos, aprendem mais r\xE1pido que qualquer outro povo.",
    mods: { str: 0, dex: 0, con: 0, int: 0, wis: 0 },
    xpMult: 1.15,
    hpMult: 1,
    speed: 100,
    light: 0,
    carry: 1,
    traits: [],
    traitText: "+15% de XP ganho."
  },
  {
    id: "elf",
    name: "Elfo",
    desc: "\xC1geis e perspicazes, enxergam longe na escurid\xE3o, mas s\xE3o fr\xE1geis.",
    mods: { str: -1, dex: 2, con: -1, int: 1, wis: 0 },
    xpMult: 1,
    hpMult: 0.9,
    speed: 100,
    light: 1,
    carry: 0.9,
    traits: ["sleepResist", "darkvision"],
    traitText: "Vis\xE3o +1, resiste a sono e paralisia, -10% HP."
  },
  {
    id: "dwarf",
    name: "An\xE3o",
    desc: "Robustos e teimosos, nascidos sob a montanha. Um pouco lentos.",
    mods: { str: 1, dex: -1, con: 2, int: 0, wis: -1 },
    xpMult: 1,
    hpMult: 1.1,
    speed: 90,
    light: 0,
    carry: 1.2,
    traits: ["poisonResist", "secretSense"],
    traitText: "Resiste a veneno, acha portas secretas, +10% HP, velocidade 90."
  },
  {
    id: "halfling",
    name: "Halfling",
    desc: "Pequenos, silenciosos e incrivelmente sortudos.",
    mods: { str: -2, dex: 2, con: 0, int: 0, wis: 1 },
    xpMult: 1,
    hpMult: 0.9,
    speed: 100,
    light: 0,
    carry: 0.8,
    traits: ["stealthy", "lucky"],
    traitText: "Furtivo, sorte em cr\xEDticos e saques, carrega menos."
  },
  {
    id: "half_orc",
    name: "Meio-Orc",
    desc: "Fortes e ferozes; o sangue orc ferve quando est\xE3o em perigo.",
    mods: { str: 2, dex: 0, con: 1, int: -2, wis: -1 },
    xpMult: 1,
    hpMult: 1.1,
    speed: 100,
    light: 0,
    carry: 1.1,
    traits: ["regen", "rage"],
    traitText: "Regenera r\xE1pido, f\xFAria (+dano) com HP abaixo de 25%."
  },
  {
    id: "gnome",
    name: "Gnomo",
    desc: "Curiosos e engenhosos, t\xEAm afinidade natural com a magia.",
    mods: { str: -1, dex: 1, con: 0, int: 2, wis: 0 },
    xpMult: 1,
    hpMult: 0.95,
    speed: 100,
    light: 0,
    carry: 0.9,
    traits: ["wandSense", "confuseResist"],
    traitText: "Identifica varinhas ao usar, -falha de magia, resiste a confus\xE3o."
  }
];
function raceById(id) {
  return RACES.find((r) => r.id === id) ?? RACES[0];
}

// src/data/spells.ts
var SPELLS = [
  // ── Arcanas (Inteligência) ───────────────────────────────────────
  {
    id: "magic_missile",
    name: "M\xEDssil M\xE1gico",
    school: "arcane",
    level: 1,
    cost: 2,
    shape: "bolt",
    effect: "damage",
    element: "arcane",
    power: "2d4",
    perLevel: 2,
    range: 10,
    fail: 22,
    color: "lightMagenta",
    desc: "Um dardo de energia pura."
  },
  {
    id: "detect_monsters",
    name: "Detectar Criaturas",
    school: "arcane",
    level: 2,
    cost: 2,
    shape: "self",
    effect: "detect",
    fail: 20,
    color: "lightGreen",
    desc: "Sente todas as criaturas do andar por um tempo."
  },
  {
    id: "blink",
    name: "Piscar",
    school: "arcane",
    level: 3,
    cost: 3,
    shape: "self",
    effect: "blink",
    fail: 25,
    color: "lightMagenta",
    desc: "Teleporte curto para perto."
  },
  {
    id: "sleep",
    name: "Sono",
    school: "arcane",
    level: 4,
    cost: 3,
    shape: "bolt",
    effect: "sleep",
    range: 10,
    fail: 25,
    color: "lightBlue",
    desc: "Faz um monstro adormecer."
  },
  {
    id: "frost_bolt",
    name: "Raio Congelante",
    school: "arcane",
    level: 5,
    cost: 5,
    shape: "bolt",
    effect: "damage",
    element: "cold",
    power: "4d6",
    perLevel: 1,
    range: 10,
    fail: 30,
    color: "lightCyan",
    desc: "Um proj\xE9til de gelo."
  },
  {
    id: "arcane_shield",
    name: "Escudo Arcano",
    school: "arcane",
    level: 6,
    cost: 5,
    shape: "self",
    effect: "shield",
    fail: 30,
    color: "lightBlue",
    desc: "Aumenta a defesa por um tempo."
  },
  {
    id: "lightning",
    name: "Rel\xE2mpago",
    school: "arcane",
    level: 8,
    cost: 7,
    shape: "beam",
    effect: "damage",
    element: "lightning",
    power: "5d6",
    perLevel: 1,
    range: 12,
    fail: 35,
    color: "yellow",
    desc: "Um raio que atravessa todos no caminho."
  },
  {
    id: "haste_self",
    name: "Acelera\xE7\xE3o",
    school: "arcane",
    level: 10,
    cost: 9,
    shape: "self",
    effect: "haste",
    fail: 40,
    color: "yellow",
    desc: "Voc\xEA age 50% mais r\xE1pido por um tempo."
  },
  {
    id: "fireball",
    name: "Bola de Fogo",
    school: "arcane",
    level: 11,
    cost: 11,
    shape: "ball",
    effect: "damage",
    element: "fire",
    power: "6d6",
    perLevel: 1,
    radius: 2,
    range: 10,
    fail: 40,
    color: "orange",
    desc: "Uma explos\xE3o de chamas em \xE1rea."
  },
  {
    id: "teleport_self",
    name: "Teleporte",
    school: "arcane",
    level: 13,
    cost: 9,
    shape: "self",
    effect: "teleport",
    fail: 40,
    color: "lightMagenta",
    desc: "Leva voc\xEA a um ponto distante do andar."
  },
  {
    id: "magic_mapping",
    name: "Clarivid\xEAncia",
    school: "arcane",
    level: 15,
    cost: 10,
    shape: "self",
    effect: "mapping",
    fail: 45,
    color: "lightCyan",
    desc: "Revela a planta do andar."
  },
  // ── Divinas (Sabedoria) ──────────────────────────────────────────
  {
    id: "cure_light",
    name: "Cura Leve",
    school: "divine",
    level: 1,
    cost: 3,
    shape: "self",
    effect: "heal",
    power: "2d6",
    perLevel: 1,
    fail: 20,
    color: "lightGreen",
    desc: "Fecha ferimentos leves."
  },
  {
    id: "bless",
    name: "B\xEAn\xE7\xE3o",
    school: "divine",
    level: 2,
    cost: 3,
    shape: "self",
    effect: "shield",
    duration: "2d10+15",
    fail: 20,
    color: "white",
    desc: "Uma prote\xE7\xE3o divina (+defesa)."
  },
  {
    id: "purify",
    name: "Purificar",
    school: "divine",
    level: 3,
    cost: 4,
    shape: "self",
    effect: "cure",
    fail: 25,
    color: "lightGreen",
    desc: "Cura veneno, confus\xE3o e cegueira."
  },
  {
    id: "holy_light",
    name: "Luz Sagrada",
    school: "divine",
    level: 4,
    cost: 5,
    shape: "ball",
    effect: "damage",
    element: "holy",
    power: "3d6",
    perLevel: 2,
    radius: 1,
    range: 8,
    fail: 28,
    color: "white",
    desc: "Explos\xE3o de luz (dobro contra mortos-vivos)."
  },
  {
    id: "word_of_fear",
    name: "Palavra do Medo",
    school: "divine",
    level: 5,
    cost: 4,
    shape: "bolt",
    effect: "fear",
    range: 8,
    fail: 28,
    color: "lightGray",
    desc: "Um monstro foge apavorado."
  },
  {
    id: "cure_serious",
    name: "Cura S\xE9ria",
    school: "divine",
    level: 7,
    cost: 7,
    shape: "self",
    effect: "heal",
    power: "4d8",
    perLevel: 1,
    fail: 30,
    color: "lightGreen",
    desc: "Cura ferimentos graves."
  },
  {
    id: "smite",
    name: "Castigo Divino",
    school: "divine",
    level: 9,
    cost: 8,
    shape: "bolt",
    effect: "damage",
    element: "holy",
    power: "6d6",
    perLevel: 1,
    range: 10,
    fail: 35,
    color: "yellow",
    desc: "A f\xFAria dos deuses num \xFAnico golpe."
  },
  {
    id: "divine_sight",
    name: "Vis\xE3o Divina",
    school: "divine",
    level: 11,
    cost: 8,
    shape: "self",
    effect: "mapping",
    fail: 35,
    color: "white",
    desc: "Os deuses mostram o caminho (planta do andar)."
  },
  {
    id: "heal",
    name: "Cura Maior",
    school: "divine",
    level: 13,
    cost: 12,
    shape: "self",
    effect: "heal",
    power: "8d8",
    perLevel: 1,
    fail: 40,
    color: "lightGreen",
    desc: "Cura quase todos os ferimentos."
  },
  {
    id: "holy_storm",
    name: "Tempestade Sagrada",
    school: "divine",
    level: 16,
    cost: 16,
    shape: "ball",
    effect: "damage",
    element: "holy",
    power: "8d6",
    perLevel: 1,
    radius: 3,
    range: 10,
    fail: 45,
    color: "white",
    desc: "Uma tempestade de luz devastadora."
  }
];
function spellById(id) {
  return SPELLS.find((s) => s.id === id);
}
var STARTING_SPELLS = {
  mage: ["magic_missile"],
  cleric: ["cure_light"],
  ranger: []
};
var CLASS_SPELL_PROGRESSION = {
  mage: { school: "arcane", maxSpellLevel: 30, every: 1 },
  cleric: { school: "divine", maxSpellLevel: 30, every: 1 },
  ranger: { school: "divine", maxSpellLevel: 5, every: 2 }
};

// src/data/items.ts
var CATEGORY_SLOT = {
  weapon: "weapon",
  launcher: "weapon",
  shield: "offhand",
  armor: "body",
  helm: "head",
  gloves: "hands",
  boots: "feet",
  cloak: "cloak",
  ring: "ring1",
  amulet: "amulet",
  light: "light",
  ammo: "quiver"
};
var b = (x) => x;
var ITEMS = [
  // ── Armas corpo a corpo ─────────────────────────────────────────
  b({
    id: "dagger",
    name: "adaga",
    gender: "f",
    category: "weapon",
    color: "lightGray",
    weight: 1,
    value: 10,
    depth: [1, 8],
    rarity: 8,
    damage: "1d4",
    finesse: true,
    throwDamage: "1d4",
    stackable: true,
    desc: "Leve e equilibrada, boa para arremessar."
  }),
  b({
    id: "short_sword",
    name: "espada curta",
    gender: "f",
    category: "weapon",
    color: "lightGray",
    weight: 3,
    value: 25,
    depth: [1, 10],
    rarity: 7,
    damage: "1d6",
    finesse: true,
    desc: "Uma l\xE2mina curta e \xE1gil."
  }),
  b({
    id: "club",
    name: "clava",
    gender: "f",
    category: "weapon",
    color: "brown",
    weight: 4,
    value: 3,
    depth: [1, 5],
    rarity: 6,
    damage: "1d6",
    desc: "Um peda\xE7o de madeira pesado."
  }),
  b({
    id: "quarterstaff",
    name: "bord\xE3o",
    gender: "m",
    category: "weapon",
    color: "brown",
    weight: 4,
    value: 5,
    depth: [1, 8],
    rarity: 5,
    damage: "1d6",
    twoHanded: true,
    desc: "Um cajado longo de madeira dura, preferido por magos."
  }),
  b({
    id: "mace",
    name: "ma\xE7a",
    gender: "f",
    category: "weapon",
    color: "lightGray",
    weight: 5,
    value: 30,
    depth: [1, 10],
    rarity: 6,
    damage: "1d8",
    desc: "Uma cabe\xE7a de ferro com flanges."
  }),
  b({
    id: "long_sword",
    name: "espada longa",
    gender: "f",
    category: "weapon",
    color: "white",
    weight: 4,
    value: 60,
    depth: [2, 14],
    rarity: 6,
    damage: "1d8",
    desc: "A arma cl\xE1ssica dos cavaleiros."
  }),
  b({
    id: "axe",
    name: "machado de batalha",
    gender: "m",
    category: "weapon",
    color: "lightGray",
    weight: 6,
    value: 50,
    depth: [3, 14],
    rarity: 5,
    damage: "1d10",
    desc: "Um machado de l\xE2mina larga."
  }),
  b({
    id: "spear",
    name: "lan\xE7a",
    gender: "f",
    category: "weapon",
    color: "brown",
    weight: 5,
    value: 20,
    depth: [2, 10],
    rarity: 4,
    damage: "1d8",
    throwDamage: "1d8",
    desc: "Pode ser arremessada."
  }),
  b({
    id: "rapier",
    name: "florete",
    gender: "m",
    category: "weapon",
    color: "lightCyan",
    weight: 2,
    value: 70,
    depth: [4, 16],
    rarity: 4,
    damage: "1d8",
    finesse: true,
    desc: "Uma l\xE2mina fina e precisa."
  }),
  b({
    id: "flail",
    name: "mangual",
    gender: "m",
    category: "weapon",
    color: "lightGray",
    weight: 7,
    value: 80,
    depth: [8, 20],
    rarity: 4,
    damage: "1d10+1",
    desc: "Uma bola cravejada presa a uma corrente."
  }),
  b({
    id: "greatsword",
    name: "montante",
    gender: "m",
    category: "weapon",
    color: "white",
    weight: 10,
    value: 120,
    depth: [8, 20],
    rarity: 4,
    damage: "2d6",
    twoHanded: true,
    desc: "Uma espada enorme, de duas m\xE3os."
  }),
  b({
    id: "halberd",
    name: "alabarda",
    gender: "f",
    category: "weapon",
    color: "lightGray",
    weight: 12,
    value: 150,
    depth: [12, 20],
    rarity: 3,
    damage: "2d8",
    twoHanded: true,
    desc: "Machado e lan\xE7a numa s\xF3 haste."
  }),
  b({
    id: "mithril_blade",
    name: "l\xE2mina de mithril",
    gender: "f",
    category: "weapon",
    color: "lightCyan",
    weight: 2,
    value: 400,
    depth: [14, 20],
    rarity: 2,
    damage: "2d6",
    finesse: true,
    desc: "Leve como uma pena e mais dura que o a\xE7o."
  }),
  b({
    id: "dart",
    name: "dardo",
    gender: "m",
    category: "weapon",
    color: "lightGray",
    weight: 0.2,
    value: 1,
    depth: [1, 6],
    rarity: 5,
    damage: "1d2",
    throwDamage: "1d4+1",
    stackable: true,
    finesse: true,
    desc: "Pequeno proj\xE9til de arremesso."
  }),
  // ── Armas de disparo e munição ──────────────────────────────────
  b({
    id: "sling",
    name: "funda",
    gender: "f",
    category: "launcher",
    color: "brown",
    weight: 0.5,
    value: 5,
    depth: [1, 6],
    rarity: 3,
    damage: "1d2",
    ammoType: "stone",
    multiplier: 2,
    range: 8,
    twoHanded: true,
    desc: "Arremessa pedras."
  }),
  b({
    id: "short_bow",
    name: "arco curto",
    gender: "m",
    category: "launcher",
    color: "brown",
    weight: 2,
    value: 50,
    depth: [1, 12],
    rarity: 4,
    damage: "1d2",
    ammoType: "arrow",
    multiplier: 2,
    range: 10,
    twoHanded: true,
    desc: "Um arco de ca\xE7a."
  }),
  b({
    id: "long_bow",
    name: "arco longo",
    gender: "m",
    category: "launcher",
    color: "yellow",
    weight: 3,
    value: 120,
    depth: [6, 20],
    rarity: 3,
    damage: "1d2",
    ammoType: "arrow",
    multiplier: 3,
    range: 12,
    twoHanded: true,
    desc: "Um arco alto e poderoso."
  }),
  b({
    id: "crossbow",
    name: "besta",
    gender: "f",
    category: "launcher",
    color: "lightGray",
    weight: 6,
    value: 150,
    depth: [8, 20],
    rarity: 3,
    damage: "1d3",
    ammoType: "bolt",
    multiplier: 3,
    range: 10,
    twoHanded: true,
    desc: "Lenta para recarregar, mas perfurante."
  }),
  b({
    id: "arrow",
    name: "flecha",
    gender: "f",
    category: "ammo",
    color: "brown",
    weight: 0.1,
    value: 1,
    depth: [1, 20],
    rarity: 6,
    damage: "1d6",
    ammoKind: "arrow",
    stackable: true,
    desc: "Flechas com ponta de ferro."
  }),
  b({
    id: "bolt",
    name: "virote",
    gender: "m",
    category: "ammo",
    color: "lightGray",
    weight: 0.1,
    value: 2,
    depth: [6, 20],
    rarity: 3,
    damage: "1d8",
    ammoKind: "bolt",
    stackable: true,
    desc: "Virotes pesados de besta."
  }),
  b({
    id: "stone",
    name: "pedra de funda",
    plural: "pedras de funda",
    gender: "f",
    category: "ammo",
    color: "darkGray",
    weight: 0.2,
    value: 0,
    depth: [1, 5],
    rarity: 3,
    damage: "1d4",
    ammoKind: "stone",
    stackable: true,
    desc: "Pedras lisas e redondas."
  }),
  // ── Armaduras ───────────────────────────────────────────────────
  b({
    id: "robe",
    name: "manto",
    gender: "m",
    category: "armor",
    color: "blue",
    weight: 2,
    value: 5,
    depth: [1, 6],
    rarity: 4,
    armor: 1,
    desc: "Um manto de tecido grosso."
  }),
  b({
    id: "leather_armor",
    name: "armadura de couro",
    plural: "armaduras de couro",
    gender: "f",
    category: "armor",
    color: "brown",
    weight: 8,
    value: 20,
    depth: [1, 8],
    rarity: 7,
    armor: 2,
    desc: "Couro curtido e endurecido."
  }),
  b({
    id: "studded_leather",
    name: "couro batido",
    gender: "m",
    category: "armor",
    color: "brown",
    weight: 10,
    value: 45,
    depth: [2, 10],
    rarity: 5,
    armor: 3,
    desc: "Couro refor\xE7ado com rebites de metal."
  }),
  b({
    id: "scale_mail",
    name: "cota de escamas",
    plural: "cotas de escamas",
    gender: "f",
    category: "armor",
    color: "lightGray",
    weight: 18,
    value: 80,
    depth: [3, 12],
    rarity: 5,
    armor: 4,
    spellPenalty: 10,
    desc: "Escamas de metal sobrepostas."
  }),
  b({
    id: "chain_mail",
    name: "cota de malha",
    plural: "cotas de malha",
    gender: "f",
    category: "armor",
    color: "lightGray",
    weight: 20,
    value: 100,
    depth: [4, 14],
    rarity: 5,
    armor: 5,
    spellPenalty: 15,
    desc: "An\xE9is de a\xE7o entrela\xE7ados."
  }),
  b({
    id: "half_plate",
    name: "meia-armadura",
    gender: "f",
    category: "armor",
    color: "white",
    weight: 30,
    value: 250,
    depth: [9, 20],
    rarity: 3,
    armor: 6,
    spellPenalty: 25,
    desc: "Placas de a\xE7o sobre malha."
  }),
  b({
    id: "plate_mail",
    name: "armadura de placas",
    plural: "armaduras de placas",
    gender: "f",
    category: "armor",
    color: "white",
    weight: 40,
    value: 450,
    depth: [12, 20],
    rarity: 2,
    armor: 8,
    spellPenalty: 35,
    desc: "A melhor prote\xE7\xE3o que o a\xE7o pode comprar."
  }),
  b({
    id: "mithril_mail",
    name: "cota de mithril",
    plural: "cotas de mithril",
    gender: "f",
    category: "armor",
    color: "lightCyan",
    weight: 10,
    value: 1200,
    depth: [14, 20],
    rarity: 1,
    armor: 7,
    spellPenalty: 5,
    desc: "Leve e brilhante como prata."
  }),
  b({
    id: "small_shield",
    name: "escudo pequeno",
    gender: "m",
    category: "shield",
    color: "brown",
    weight: 5,
    value: 15,
    depth: [1, 10],
    rarity: 5,
    armor: 1,
    desc: "Um broquel de madeira e couro."
  }),
  b({
    id: "large_shield",
    name: "escudo grande",
    gender: "m",
    category: "shield",
    color: "lightGray",
    weight: 12,
    value: 60,
    depth: [5, 20],
    rarity: 3,
    armor: 2,
    spellPenalty: 5,
    desc: "Um escudo de a\xE7o que cobre quase todo o corpo."
  }),
  b({
    id: "leather_cap",
    name: "gorro de couro",
    gender: "m",
    category: "helm",
    color: "brown",
    weight: 1,
    value: 5,
    depth: [1, 8],
    rarity: 4,
    armor: 1,
    desc: "Melhor que nada."
  }),
  b({
    id: "iron_helm",
    name: "elmo de ferro",
    gender: "m",
    category: "helm",
    color: "lightGray",
    weight: 4,
    value: 30,
    depth: [4, 20],
    rarity: 3,
    armor: 2,
    desc: "Um elmo fechado."
  }),
  b({
    id: "leather_gloves",
    name: "luvas de couro",
    plural: "pares de luvas de couro",
    gender: "f",
    category: "gloves",
    color: "brown",
    weight: 1,
    value: 5,
    depth: [1, 12],
    rarity: 3,
    armor: 1,
    desc: "Luvas de couro macio."
  }),
  b({
    id: "leather_boots",
    name: "botas de couro",
    plural: "pares de botas de couro",
    gender: "f",
    category: "boots",
    color: "brown",
    weight: 2,
    value: 5,
    depth: [1, 12],
    rarity: 3,
    armor: 1,
    desc: "Botas resistentes."
  }),
  b({
    id: "cloak",
    name: "capa",
    gender: "f",
    category: "cloak",
    color: "green",
    weight: 1,
    value: 5,
    depth: [1, 15],
    rarity: 3,
    armor: 1,
    desc: "Uma capa de viagem com capuz."
  }),
  // ── Luz ─────────────────────────────────────────────────────────
  b({
    id: "torch",
    name: "tocha",
    gender: "f",
    category: "light",
    color: "orange",
    weight: 2,
    value: 1,
    depth: [1, 10],
    rarity: 4,
    light: 2,
    fuel: 3e3,
    stackable: true,
    desc: "Ilumina 2 casas ao redor. Queima com o tempo."
  }),
  b({
    id: "lantern",
    name: "lanterna",
    gender: "f",
    category: "light",
    color: "yellow",
    weight: 4,
    value: 100,
    depth: [4, 20],
    rarity: 2,
    light: 3,
    fuel: 8e3,
    desc: "Uma lanterna de lat\xE3o. Ilumina 3 casas."
  }),
  // ── Comida ──────────────────────────────────────────────────────
  b({
    id: "ration",
    name: "ra\xE7\xE3o de viagem",
    plural: "ra\xE7\xF5es de viagem",
    gender: "f",
    category: "food",
    color: "brown",
    weight: 1,
    value: 3,
    depth: [1, 20],
    rarity: 8,
    nutrition: 1500,
    stackable: true,
    desc: "Carne seca, p\xE3o duro e queijo."
  }),
  b({
    id: "apple",
    name: "ma\xE7\xE3",
    gender: "f",
    category: "food",
    color: "lightRed",
    weight: 0.3,
    value: 1,
    depth: [1, 10],
    rarity: 4,
    nutrition: 300,
    stackable: true,
    desc: "Uma ma\xE7\xE3 vermelha (e milagrosamente fresca)."
  }),
  b({
    id: "elven_bread",
    name: "p\xE3o \xE9lfico",
    plural: "p\xE3es \xE9lficos",
    gender: "m",
    category: "food",
    color: "yellow",
    weight: 0.3,
    value: 20,
    depth: [5, 20],
    rarity: 2,
    nutrition: 2500,
    stackable: true,
    desc: "Um peda\xE7o sacia por dias."
  }),
  // ── Poções (efeitos em core/consumables.ts) ─────────────────────
  b({
    id: "potion_heal",
    name: "po\xE7\xE3o de cura",
    plural: "po\xE7\xF5es de cura",
    gender: "f",
    category: "potion",
    color: "lightRed",
    weight: 0.5,
    value: 20,
    depth: [1, 20],
    rarity: 10,
    effect: "heal",
    stackable: true,
    desc: "Cura ferimentos."
  }),
  b({
    id: "potion_heal_major",
    name: "po\xE7\xE3o de cura maior",
    plural: "po\xE7\xF5es de cura maior",
    gender: "f",
    category: "potion",
    color: "lightRed",
    weight: 0.5,
    value: 80,
    depth: [8, 20],
    rarity: 4,
    effect: "heal_major",
    stackable: true,
    desc: "Cura quase todos os ferimentos."
  }),
  b({
    id: "potion_mana",
    name: "po\xE7\xE3o de mana",
    plural: "po\xE7\xF5es de mana",
    gender: "f",
    category: "potion",
    color: "lightBlue",
    weight: 0.5,
    value: 30,
    depth: [1, 20],
    rarity: 5,
    effect: "mana",
    stackable: true,
    desc: "Restaura a energia m\xE1gica."
  }),
  b({
    id: "potion_speed",
    name: "po\xE7\xE3o de velocidade",
    plural: "po\xE7\xF5es de velocidade",
    gender: "f",
    category: "potion",
    color: "yellow",
    weight: 0.5,
    value: 60,
    depth: [3, 20],
    rarity: 3,
    effect: "haste",
    stackable: true,
    desc: "Acelera seus movimentos por um tempo."
  }),
  b({
    id: "potion_strength",
    name: "po\xE7\xE3o de for\xE7a",
    plural: "po\xE7\xF5es de for\xE7a",
    gender: "f",
    category: "potion",
    color: "orange",
    weight: 0.5,
    value: 300,
    depth: [6, 20],
    rarity: 1,
    effect: "gain_str",
    stackable: true,
    desc: "Aumenta permanentemente a for\xE7a."
  }),
  b({
    id: "potion_experience",
    name: "po\xE7\xE3o de experi\xEAncia",
    plural: "po\xE7\xF5es de experi\xEAncia",
    gender: "f",
    category: "potion",
    color: "gold",
    weight: 0.5,
    value: 500,
    depth: [10, 20],
    rarity: 1,
    effect: "gain_level",
    stackable: true,
    desc: "Concede um n\xEDvel de experi\xEAncia."
  }),
  b({
    id: "potion_cure_poison",
    name: "po\xE7\xE3o de ant\xEDdoto",
    plural: "po\xE7\xF5es de ant\xEDdoto",
    gender: "f",
    category: "potion",
    color: "lightGreen",
    weight: 0.5,
    value: 15,
    depth: [2, 20],
    rarity: 4,
    effect: "cure",
    stackable: true,
    desc: "Cura veneno e confus\xE3o."
  }),
  b({
    id: "potion_invisibility",
    name: "po\xE7\xE3o de invisibilidade",
    plural: "po\xE7\xF5es de invisibilidade",
    gender: "f",
    category: "potion",
    color: "white",
    weight: 0.5,
    value: 60,
    depth: [5, 20],
    rarity: 2,
    effect: "invisible",
    stackable: true,
    desc: "Torna voc\xEA dif\xEDcil de ver."
  }),
  b({
    id: "potion_restore",
    name: "po\xE7\xE3o de restaura\xE7\xE3o",
    plural: "po\xE7\xF5es de restaura\xE7\xE3o",
    gender: "f",
    category: "potion",
    color: "lightCyan",
    weight: 0.5,
    value: 150,
    depth: [8, 20],
    rarity: 2,
    effect: "restore",
    stackable: true,
    desc: "Restaura n\xEDveis drenados."
  }),
  b({
    id: "potion_poison",
    name: "po\xE7\xE3o de veneno",
    plural: "po\xE7\xF5es de veneno",
    gender: "f",
    category: "potion",
    color: "green",
    weight: 0.5,
    value: 0,
    depth: [1, 15],
    rarity: 3,
    effect: "poison",
    stackable: true,
    desc: "Venenosa! Melhor arremessar em algu\xE9m."
  }),
  b({
    id: "potion_confusion",
    name: "po\xE7\xE3o de confus\xE3o",
    plural: "po\xE7\xF5es de confus\xE3o",
    gender: "f",
    category: "potion",
    color: "magenta",
    weight: 0.5,
    value: 0,
    depth: [1, 15],
    rarity: 3,
    effect: "confuse",
    stackable: true,
    desc: "Deixa a cabe\xE7a girando."
  }),
  b({
    id: "potion_blindness",
    name: "po\xE7\xE3o de cegueira",
    plural: "po\xE7\xF5es de cegueira",
    gender: "f",
    category: "potion",
    color: "darkGray",
    weight: 0.5,
    value: 0,
    depth: [1, 15],
    rarity: 2,
    effect: "blind",
    stackable: true,
    desc: "Escurece a vis\xE3o."
  }),
  // ── Pergaminhos ─────────────────────────────────────────────────
  b({
    id: "scroll_identify",
    name: "pergaminho de identifica\xE7\xE3o",
    plural: "pergaminhos de identifica\xE7\xE3o",
    gender: "m",
    category: "scroll",
    color: "white",
    weight: 0.2,
    value: 20,
    depth: [1, 20],
    rarity: 9,
    effect: "identify",
    stackable: true,
    desc: "Revela a natureza de um item."
  }),
  b({
    id: "scroll_teleport",
    name: "pergaminho de teleporte",
    plural: "pergaminhos de teleporte",
    gender: "m",
    category: "scroll",
    color: "white",
    weight: 0.2,
    value: 40,
    depth: [1, 20],
    rarity: 5,
    effect: "teleport",
    stackable: true,
    desc: "Leva voc\xEA a um lugar aleat\xF3rio do andar."
  }),
  b({
    id: "scroll_mapping",
    name: "pergaminho de mapeamento",
    plural: "pergaminhos de mapeamento",
    gender: "m",
    category: "scroll",
    color: "white",
    weight: 0.2,
    value: 50,
    depth: [2, 20],
    rarity: 4,
    effect: "mapping",
    stackable: true,
    desc: "Revela a planta do andar."
  }),
  b({
    id: "scroll_remove_curse",
    name: "pergaminho de remover maldi\xE7\xE3o",
    plural: "pergaminhos de remover maldi\xE7\xE3o",
    gender: "m",
    category: "scroll",
    color: "white",
    weight: 0.2,
    value: 60,
    depth: [3, 20],
    rarity: 3,
    effect: "uncurse",
    stackable: true,
    desc: "Quebra maldi\xE7\xF5es do equipamento."
  }),
  b({
    id: "scroll_enchant_weapon",
    name: "pergaminho de encantar arma",
    plural: "pergaminhos de encantar arma",
    gender: "m",
    category: "scroll",
    color: "white",
    weight: 0.2,
    value: 80,
    depth: [3, 20],
    rarity: 3,
    effect: "enchant_weapon",
    stackable: true,
    desc: "Aumenta o encantamento da arma."
  }),
  b({
    id: "scroll_enchant_armor",
    name: "pergaminho de encantar armadura",
    plural: "pergaminhos de encantar armadura",
    gender: "m",
    category: "scroll",
    color: "white",
    weight: 0.2,
    value: 80,
    depth: [3, 20],
    rarity: 3,
    effect: "enchant_armor",
    stackable: true,
    desc: "Aumenta o encantamento da armadura."
  }),
  b({
    id: "scroll_light",
    name: "pergaminho de luz",
    plural: "pergaminhos de luz",
    gender: "m",
    category: "scroll",
    color: "white",
    weight: 0.2,
    value: 10,
    depth: [1, 10],
    rarity: 4,
    effect: "light",
    stackable: true,
    desc: "Ilumina a \xE1rea ao redor."
  }),
  b({
    id: "scroll_fear",
    name: "pergaminho de medo",
    plural: "pergaminhos de medo",
    gender: "m",
    category: "scroll",
    color: "white",
    weight: 0.2,
    value: 30,
    depth: [2, 20],
    rarity: 3,
    effect: "scare",
    stackable: true,
    desc: "Monstros pr\xF3ximos fogem de pavor."
  }),
  b({
    id: "scroll_fire",
    name: "pergaminho de fogo",
    plural: "pergaminhos de fogo",
    gender: "m",
    category: "scroll",
    color: "white",
    weight: 0.2,
    value: 30,
    depth: [3, 20],
    rarity: 3,
    effect: "fireball_self",
    stackable: true,
    desc: "Uma explos\xE3o de chamas ao seu redor."
  }),
  b({
    id: "scroll_summon",
    name: "pergaminho de invoca\xE7\xE3o",
    plural: "pergaminhos de invoca\xE7\xE3o",
    gender: "m",
    category: "scroll",
    color: "white",
    weight: 0.2,
    value: 0,
    depth: [2, 20],
    rarity: 2,
    effect: "summon",
    stackable: true,
    desc: "Invoca monstros. Ops."
  }),
  b({
    id: "scroll_aggravate",
    name: "pergaminho de provoca\xE7\xE3o",
    plural: "pergaminhos de provoca\xE7\xE3o",
    gender: "m",
    category: "scroll",
    color: "white",
    weight: 0.2,
    value: 0,
    depth: [2, 20],
    rarity: 2,
    effect: "aggravate",
    stackable: true,
    desc: "Acorda tudo no andar."
  }),
  // ── Varinhas ────────────────────────────────────────────────────
  b({
    id: "wand_magic_missile",
    name: "varinha de m\xEDssil m\xE1gico",
    plural: "varinhas de m\xEDssil m\xE1gico",
    gender: "f",
    category: "wand",
    color: "lightMagenta",
    weight: 1,
    value: 100,
    depth: [1, 20],
    rarity: 4,
    effect: "magic_missile",
    charges: "1d6+4",
    desc: "Dispara m\xEDsseis m\xE1gicos."
  }),
  b({
    id: "wand_fire",
    name: "varinha de fogo",
    plural: "varinhas de fogo",
    gender: "f",
    category: "wand",
    color: "orange",
    weight: 1,
    value: 200,
    depth: [5, 20],
    rarity: 3,
    effect: "fire_bolt",
    charges: "1d4+3",
    desc: "Dispara um raio de fogo."
  }),
  b({
    id: "wand_cold",
    name: "varinha de gelo",
    plural: "varinhas de gelo",
    gender: "f",
    category: "wand",
    color: "lightCyan",
    weight: 1,
    value: 200,
    depth: [5, 20],
    rarity: 3,
    effect: "frost_bolt",
    charges: "1d4+3",
    desc: "Dispara um raio de gelo."
  }),
  b({
    id: "wand_lightning",
    name: "varinha de rel\xE2mpago",
    plural: "varinhas de rel\xE2mpago",
    gender: "f",
    category: "wand",
    color: "yellow",
    weight: 1,
    value: 220,
    depth: [7, 20],
    rarity: 2,
    effect: "lightning_beam",
    charges: "1d4+2",
    desc: "Um rel\xE2mpago que atravessa os inimigos."
  }),
  b({
    id: "wand_slow",
    name: "varinha de lentid\xE3o",
    plural: "varinhas de lentid\xE3o",
    gender: "f",
    category: "wand",
    color: "lightGray",
    weight: 1,
    value: 80,
    depth: [2, 20],
    rarity: 3,
    effect: "slow_monster",
    charges: "1d5+3",
    desc: "Deixa um monstro lento."
  }),
  b({
    id: "wand_sleep",
    name: "varinha do sono",
    plural: "varinhas do sono",
    gender: "f",
    category: "wand",
    color: "lightBlue",
    weight: 1,
    value: 80,
    depth: [2, 20],
    rarity: 3,
    effect: "sleep_monster",
    charges: "1d5+3",
    desc: "Faz um monstro adormecer."
  }),
  b({
    id: "wand_teleport_other",
    name: "varinha de banimento",
    plural: "varinhas de banimento",
    gender: "f",
    category: "wand",
    color: "lightGreen",
    weight: 1,
    value: 250,
    depth: [6, 20],
    rarity: 2,
    effect: "teleport_other",
    charges: "1d3+2",
    desc: "Teleporta um monstro para longe."
  }),
  b({
    id: "wand_digging",
    name: "varinha de escava\xE7\xE3o",
    plural: "varinhas de escava\xE7\xE3o",
    gender: "f",
    category: "wand",
    color: "brown",
    weight: 1,
    value: 150,
    depth: [4, 20],
    rarity: 2,
    effect: "dig",
    charges: "1d4+4",
    desc: "Abre t\xFAneis atrav\xE9s da rocha."
  }),
  // ── Anéis e amuletos (efeitos via afixos fixos) ─────────────────
  b({
    id: "ring_protection",
    name: "anel de prote\xE7\xE3o",
    plural: "an\xE9is de prote\xE7\xE3o",
    gender: "m",
    category: "ring",
    color: "lightGray",
    weight: 0,
    value: 150,
    depth: [2, 20],
    rarity: 3,
    effect: "protection",
    desc: "+defesa."
  }),
  b({
    id: "ring_strength",
    name: "anel de for\xE7a",
    plural: "an\xE9is de for\xE7a",
    gender: "m",
    category: "ring",
    color: "orange",
    weight: 0,
    value: 200,
    depth: [4, 20],
    rarity: 2,
    effect: "str",
    desc: "+for\xE7a."
  }),
  b({
    id: "ring_regeneration",
    name: "anel de regenera\xE7\xE3o",
    plural: "an\xE9is de regenera\xE7\xE3o",
    gender: "m",
    category: "ring",
    color: "lightGreen",
    weight: 0,
    value: 300,
    depth: [6, 20],
    rarity: 2,
    effect: "regen",
    desc: "Regenera HP mais r\xE1pido."
  }),
  b({
    id: "ring_see_invisible",
    name: "anel da vis\xE3o",
    plural: "an\xE9is da vis\xE3o",
    gender: "m",
    category: "ring",
    color: "white",
    weight: 0,
    value: 200,
    depth: [5, 20],
    rarity: 2,
    effect: "light",
    desc: "+1 de vis\xE3o."
  }),
  b({
    id: "ring_fire_resist",
    name: "anel da chama",
    plural: "an\xE9is da chama",
    gender: "m",
    category: "ring",
    color: "red",
    weight: 0,
    value: 180,
    depth: [5, 20],
    rarity: 2,
    effect: "resist_fire",
    desc: "Resist\xEAncia a fogo."
  }),
  b({
    id: "amulet_life",
    name: "amuleto da vida",
    plural: "amuletos da vida",
    gender: "m",
    category: "amulet",
    color: "lightRed",
    weight: 0,
    value: 400,
    depth: [6, 20],
    rarity: 2,
    effect: "life",
    desc: "+HP m\xE1ximo."
  }),
  b({
    id: "amulet_mind",
    name: "amuleto da mente",
    plural: "amuletos da mente",
    gender: "m",
    category: "amulet",
    color: "lightBlue",
    weight: 0,
    value: 400,
    depth: [6, 20],
    rarity: 2,
    effect: "mind",
    desc: "+MP m\xE1ximo e resist\xEAncia a confus\xE3o."
  }),
  // ── Tomos ───────────────────────────────────────────────────────
  b({
    id: "tome_arcane",
    name: "tomo arcano",
    plural: "tomos arcanos",
    gender: "m",
    category: "book",
    color: "lightMagenta",
    weight: 3,
    value: 150,
    depth: [1, 20],
    rarity: 3,
    effect: "learn_arcane",
    desc: "Cont\xE9m magias arcanas (Intelig\xEAncia)."
  }),
  b({
    id: "tome_divine",
    name: "livro de ora\xE7\xF5es",
    plural: "livros de ora\xE7\xF5es",
    gender: "m",
    category: "book",
    color: "white",
    weight: 3,
    value: 150,
    depth: [1, 20],
    rarity: 3,
    effect: "learn_divine",
    desc: "Cont\xE9m ora\xE7\xF5es divinas (Sabedoria)."
  }),
  // ── Especiais ───────────────────────────────────────────────────
  b({
    id: "gold",
    name: "pe\xE7a de ouro",
    plural: "pe\xE7as de ouro",
    gender: "f",
    category: "gold",
    color: "gold",
    weight: 0,
    value: 1,
    depth: [1, 20],
    rarity: 10,
    stackable: true,
    desc: "Ouro reluzente."
  }),
  b({
    id: "corpse",
    name: "cad\xE1ver",
    gender: "m",
    category: "corpse",
    color: "lightGray",
    weight: 20,
    value: 0,
    depth: [0, 0],
    rarity: 0,
    nutrition: 800,
    desc: "Os restos de uma criatura."
  }),
  b({
    id: "amulet_abyss",
    name: "Cora\xE7\xE3o do Abismo",
    gender: "m",
    category: "artifact",
    color: "lightMagenta",
    weight: 1,
    value: 1e4,
    depth: [0, 0],
    rarity: 0,
    desc: "Uma gema pulsante, quente como um cora\xE7\xE3o vivo. O motivo de toda a sua jornada."
  })
];
var BY_ID = new Map(ITEMS.map((i) => [i.id, i]));
function itemBase(id) {
  const b2 = BY_ID.get(id);
  if (!b2) throw new Error(`Item desconhecido: ${id}`);
  return b2;
}

// src/core/item.ts
function createItem(game, baseId, props = {}) {
  const base = itemBase(baseId);
  return {
    id: newId(game),
    baseId,
    x: 0,
    y: 0,
    quantity: 1,
    enchant: 0,
    affixes: [],
    rarity: "common",
    identified: true,
    cursed: false,
    fuel: base.fuel,
    ...props
  };
}
function createCorpse(game, monster) {
  return createItem(game, "corpse", { x: monster.x, y: monster.y, corpseOf: monster.templateId, corpseName: monster.name });
}
function canStack(a, b2) {
  if (a.baseId !== b2.baseId || !itemBase(a.baseId).stackable) return false;
  return a.enchant === b2.enchant && a.cursed === b2.cursed && a.identified === b2.identified && a.affixes.join() === b2.affixes.join() && a.rarity === b2.rarity && a.fuel === b2.fuel;
}
function addItem(level2, item) {
  const same = level2.items.find((i) => i.x === item.x && i.y === item.y && canStack(i, item));
  if (same) same.quantity += item.quantity;
  else level2.items.push(item);
}
function itemsAt(level2, x, y) {
  return level2.items.filter((i) => i.x === x && i.y === y);
}
function removeFloorItem(level2, item) {
  level2.items = level2.items.filter((i) => i !== item);
}
function itemWeight(item) {
  const base = itemBase(item.baseId);
  if (item.baseId === "corpse") return 10;
  return base.weight * item.quantity;
}

// src/data/bosses.ts
var BOSSES = [
  {
    id: "goblin_king",
    name: "Rei Goblin Grutch",
    gender: "m",
    glyph: "g",
    color: "yellow",
    level: 7,
    hp: "8d10",
    speed: 100,
    accuracy: 8,
    defense: 8,
    attacks: [{ verb: "golpeia", damage: "2d5" }, { verb: "golpeia", damage: "1d6" }],
    xp: 160,
    flags: ["unique", "boss", "opensDoors"],
    depth: [0, 0],
    rarity: 0,
    desc: "Gordo, cruel e coroado com uma panela amassada. Seus s\xFAditos morrem por ele.",
    bossDepth: 5,
    escort: [{ id: "goblin", count: [2, 3] }, { id: "goblin_shaman", count: [1, 1] }],
    intro: "Voc\xEA ouve tambores e risadas guturais. O Rei Goblin governa este andar!"
  },
  {
    id: "ancient_troll",
    name: "Troll Anci\xE3o Murgash",
    gender: "m",
    glyph: "T",
    color: "lightGreen",
    level: 13,
    hp: "18d10",
    speed: 100,
    accuracy: 14,
    defense: 12,
    attacks: [{ verb: "arranha", damage: "2d8" }, { verb: "arranha", damage: "2d8" }, { verb: "morde", damage: "2d10" }],
    xp: 600,
    flags: ["unique", "boss", "regenerates", "opensDoors"],
    depth: [0, 0],
    rarity: 0,
    desc: "Um troll gigantesco, coberto de musgo e cicatrizes que se fecham diante dos seus olhos.",
    bossDepth: 10,
    escort: [{ id: "troll", count: [1, 2] }, { id: "ogre", count: [1, 2] }],
    intro: "O ch\xE3o treme com passos pesados. Algo muito antigo e faminto vive aqui."
  },
  {
    id: "lesser_lich",
    name: "Lich Menor Vaeloth",
    gender: "m",
    glyph: "L",
    color: "magenta",
    level: 17,
    hp: "15d10",
    speed: 110,
    accuracy: 17,
    defense: 15,
    attacks: [{ verb: "toca", damage: "3d8", element: "cold" }, { verb: "toca", damage: "2d6", effect: { status: "drain", chance: 25 } }],
    xp: 1200,
    flags: ["unique", "boss", "undead", "caster", "opensDoors"],
    depth: [0, 0],
    rarity: 0,
    desc: "Um esqueleto em mantos podres; nas \xF3rbitas, duas brasas frias.",
    bossDepth: 15,
    escort: [{ id: "wraith", count: [2, 3] }, { id: "skeleton", count: [3, 4] }],
    intro: "O ar fica gelado. Uma voz seca sussurra seu nome..."
  },
  {
    id: "abyss_guardian",
    name: "Guardi\xE3o do Abismo",
    gender: "m",
    glyph: "&",
    color: "lightMagenta",
    level: 22,
    hp: "25d10",
    speed: 110,
    accuracy: 21,
    defense: 19,
    attacks: [{ verb: "esmaga", damage: "3d10" }, { verb: "queima", damage: "3d8", element: "fire" }, { verb: "arranha", damage: "2d10" }],
    xp: 3e3,
    flags: ["unique", "boss", "opensDoors"],
    depth: [0, 0],
    rarity: 0,
    desc: "Um colosso de obsidiana e fogo, preso a este lugar para guardar o Cora\xE7\xE3o do Abismo.",
    bossDepth: 20,
    escort: [{ id: "demon", count: [2, 2] }],
    intro: "Voc\xEA chegou ao fundo. O Cora\xE7\xE3o do Abismo pulsa em algum lugar... e algo o guarda."
  }
];
function bossForDepth(depth) {
  return BOSSES.find((b2) => b2.bossDepth === depth);
}

// src/data/monsters.ts
var m = (t) => t;
var MONSTERS = [
  // ── Andares 1–4 ──────────────────────────────────────────────
  m({
    id: "rat",
    name: "rato",
    gender: "m",
    glyph: "r",
    color: "brown",
    level: 1,
    hp: "1d4+1",
    speed: 100,
    accuracy: 1,
    defense: 1,
    attacks: [{ verb: "morde", damage: "1d3" }],
    xp: 2,
    flags: ["animal"],
    depth: [1, 4],
    rarity: 10,
    desc: "Um rato enorme e sarnento, de olhos vermelhos."
  }),
  m({
    id: "bat",
    name: "morcego",
    gender: "m",
    glyph: "b",
    color: "darkGray",
    level: 1,
    hp: "1d4",
    speed: 150,
    accuracy: 2,
    defense: 3,
    attacks: [{ verb: "morde", damage: "1d2" }],
    xp: 2,
    flags: ["animal", "erratic"],
    depth: [1, 5],
    rarity: 6,
    desc: "Um morcego que voa em ziguezague."
  }),
  m({
    id: "kobold",
    name: "kobold",
    gender: "m",
    glyph: "k",
    color: "lightGreen",
    level: 1,
    hp: "1d6+1",
    speed: 100,
    accuracy: 2,
    defense: 2,
    attacks: [{ verb: "golpeia", damage: "1d4" }],
    xp: 4,
    flags: ["opensDoors"],
    depth: [1, 5],
    rarity: 8,
    desc: "Um pequeno humanoide reptiliano, covarde e trai\xE7oeiro."
  }),
  m({
    id: "jackal",
    name: "chacal",
    gender: "m",
    glyph: "c",
    color: "yellow",
    level: 1,
    hp: "1d5",
    speed: 110,
    accuracy: 2,
    defense: 2,
    attacks: [{ verb: "morde", damage: "1d3" }],
    xp: 3,
    flags: ["animal"],
    depth: [1, 4],
    rarity: 6,
    group: [2, 4],
    desc: "Um c\xE3o selvagem que ca\xE7a em matilha."
  }),
  m({
    id: "green_jelly",
    name: "geleia verde",
    gender: "f",
    glyph: "j",
    color: "lightGreen",
    level: 2,
    hp: "3d6",
    speed: 100,
    accuracy: 1,
    defense: 0,
    attacks: [{ verb: "queima", damage: "1d4", element: "acid" }],
    xp: 6,
    flags: ["stationary"],
    depth: [1, 6],
    rarity: 4,
    desc: "Uma massa gelatinosa e \xE1cida que nunca sai do lugar."
  }),
  m({
    id: "goblin",
    name: "goblin",
    gender: "m",
    glyph: "g",
    color: "green",
    level: 2,
    hp: "2d5",
    speed: 100,
    accuracy: 3,
    defense: 3,
    attacks: [{ verb: "golpeia", damage: "1d6" }],
    xp: 6,
    flags: ["opensDoors"],
    depth: [1, 6],
    rarity: 8,
    desc: "Um goblin magricela armado com uma l\xE2mina enferrujada."
  }),
  m({
    id: "cave_spider",
    name: "aranha das cavernas",
    gender: "f",
    glyph: "s",
    color: "darkGray",
    level: 2,
    hp: "1d6",
    speed: 120,
    accuracy: 3,
    defense: 3,
    attacks: [{ verb: "pica", damage: "1d4" }],
    xp: 4,
    flags: ["animal"],
    depth: [2, 6],
    rarity: 5,
    group: [3, 6],
    desc: "Pequenas aranhas negras que surgem aos montes das frestas."
  }),
  m({
    id: "skeleton",
    name: "esqueleto",
    gender: "m",
    glyph: "z",
    color: "white",
    level: 3,
    hp: "2d8",
    speed: 100,
    accuracy: 4,
    defense: 4,
    attacks: [{ verb: "golpeia", damage: "1d6" }],
    xp: 9,
    flags: ["undead", "opensDoors"],
    depth: [2, 7],
    rarity: 6,
    desc: "Ossos animados por magia antiga, ainda segurando uma espada."
  }),
  // ── Andares 4–8 ──────────────────────────────────────────────
  m({
    id: "orc",
    name: "orc",
    gender: "m",
    glyph: "o",
    color: "lightRed",
    level: 4,
    hp: "3d8",
    speed: 100,
    accuracy: 5,
    defense: 5,
    attacks: [{ verb: "golpeia", damage: "1d8" }],
    xp: 14,
    flags: ["opensDoors"],
    depth: [3, 9],
    rarity: 8,
    group: [2, 4],
    desc: "Um orc brutal de pele acinzentada, sempre em bando."
  }),
  m({
    id: "giant_spider",
    name: "aranha gigante",
    gender: "f",
    glyph: "S",
    color: "magenta",
    level: 5,
    hp: "4d6",
    speed: 110,
    accuracy: 6,
    defense: 5,
    attacks: [{ verb: "pica", damage: "1d6", effect: { status: "poisoned", chance: 40, duration: "2d4" } }],
    xp: 20,
    flags: ["animal"],
    depth: [4, 9],
    rarity: 5,
    desc: "Uma aranha do tamanho de um c\xE3o, com presas que pingam veneno."
  }),
  m({
    id: "zombie",
    name: "zumbi",
    gender: "m",
    glyph: "z",
    color: "lightGray",
    level: 4,
    hp: "4d8",
    speed: 70,
    accuracy: 4,
    defense: 3,
    attacks: [{ verb: "arranha", damage: "1d8" }],
    xp: 14,
    flags: ["undead"],
    depth: [4, 10],
    rarity: 6,
    desc: "Um cad\xE1ver lento e persistente."
  }),
  m({
    id: "goblin_shaman",
    name: "xam\xE3 goblin",
    gender: "m",
    glyph: "g",
    color: "lightMagenta",
    level: 4,
    hp: "2d6",
    speed: 100,
    accuracy: 3,
    defense: 3,
    attacks: [{ verb: "golpeia", damage: "1d4" }],
    xp: 16,
    flags: ["opensDoors", "caster"],
    depth: [3, 8],
    rarity: 4,
    desc: "Um goblin coberto de ossos e penas, que murmura feiti\xE7os."
  }),
  m({
    id: "poison_fungus",
    name: "fungo venenoso",
    gender: "m",
    glyph: "F",
    color: "lightMagenta",
    level: 3,
    hp: "3d6",
    speed: 100,
    accuracy: 4,
    defense: 1,
    attacks: [{ verb: "solta esporos em", damage: "1d4", effect: { status: "poisoned", chance: 50, duration: "1d6" } }],
    xp: 8,
    flags: ["stationary"],
    depth: [3, 9],
    rarity: 4,
    desc: "Um fungo arroxeado que libera nuvens de esporos t\xF3xicos."
  }),
  m({
    id: "wolf",
    name: "lobo",
    gender: "m",
    glyph: "C",
    color: "lightGray",
    level: 5,
    hp: "3d8",
    speed: 120,
    accuracy: 6,
    defense: 5,
    attacks: [{ verb: "morde", damage: "1d6" }],
    xp: 18,
    flags: ["animal"],
    depth: [5, 10],
    rarity: 5,
    group: [3, 5],
    desc: "Um lobo cinzento de olhos amarelos."
  }),
  m({
    id: "dwarf",
    name: "an\xE3o renegado",
    gender: "m",
    glyph: "h",
    color: "red",
    level: 6,
    hp: "4d8",
    speed: 100,
    accuracy: 7,
    defense: 7,
    attacks: [{ verb: "golpeia", damage: "1d10" }],
    xp: 25,
    flags: ["opensDoors"],
    depth: [5, 10],
    rarity: 4,
    desc: "Um an\xE3o de barba tran\xE7ada, enlouquecido pela cobi\xE7a."
  }),
  m({
    id: "gnoll",
    name: "gnoll",
    gender: "m",
    glyph: "C",
    color: "brown",
    level: 6,
    hp: "4d8",
    speed: 100,
    accuracy: 7,
    defense: 6,
    attacks: [{ verb: "morde", damage: "1d8" }, { verb: "arranha", damage: "1d4" }],
    xp: 24,
    flags: ["opensDoors"],
    depth: [6, 11],
    rarity: 4,
    group: [2, 3],
    desc: "Um humanoide com cabe\xE7a de hiena que gargalha ao lutar."
  }),
  // ── Andares 8–12 ─────────────────────────────────────────────
  m({
    id: "ogre",
    name: "ogro",
    gender: "m",
    glyph: "O",
    color: "brown",
    level: 8,
    hp: "6d10",
    speed: 90,
    accuracy: 8,
    defense: 7,
    attacks: [{ verb: "esmaga", damage: "2d8" }],
    xp: 45,
    flags: ["opensDoors"],
    depth: [8, 14],
    rarity: 5,
    desc: "Um gigante est\xFApido com uma clava do tamanho de voc\xEA."
  }),
  m({
    id: "troll",
    name: "troll",
    gender: "m",
    glyph: "T",
    color: "green",
    level: 10,
    hp: "7d10",
    speed: 100,
    accuracy: 10,
    defense: 8,
    attacks: [{ verb: "arranha", damage: "1d8" }, { verb: "arranha", damage: "1d8" }, { verb: "morde", damage: "1d10" }],
    xp: 70,
    flags: ["regenerates", "opensDoors"],
    depth: [9, 16],
    rarity: 4,
    desc: "Um troll de pele verrugosa que se regenera rapidamente."
  }),
  m({
    id: "wraith",
    name: "espectro",
    gender: "m",
    glyph: "W",
    color: "white",
    level: 10,
    hp: "6d8",
    speed: 110,
    accuracy: 10,
    defense: 9,
    attacks: [{ verb: "toca", damage: "1d8", effect: { status: "drain", chance: 25 } }],
    xp: 75,
    flags: ["undead"],
    depth: [9, 15],
    rarity: 3,
    desc: "Uma sombra fria que suga a for\xE7a vital dos vivos."
  }),
  m({
    id: "serpent",
    name: "serpente",
    gender: "f",
    glyph: "S",
    color: "lightGreen",
    level: 9,
    hp: "5d8",
    speed: 100,
    accuracy: 9,
    defense: 8,
    attacks: [{ verb: "morde", damage: "2d6", effect: { status: "poisoned", chance: 50, duration: "2d6" } }],
    xp: 55,
    flags: ["animal"],
    depth: [8, 14],
    rarity: 4,
    desc: "Uma serpente enorme de escamas verdes."
  }),
  m({
    id: "nymph",
    name: "ninfa",
    gender: "f",
    glyph: "n",
    color: "lightCyan",
    level: 8,
    hp: "3d8",
    speed: 120,
    accuracy: 9,
    defense: 9,
    attacks: [{ verb: "seduz", damage: "1d2", effect: { status: "steal", chance: 60 } }],
    xp: 40,
    flags: ["opensDoors", "thief"],
    depth: [7, 13],
    rarity: 3,
    desc: "Uma bela criatura que adora objetos alheios."
  }),
  m({
    id: "dark_elf",
    name: "elfo negro",
    gender: "m",
    glyph: "h",
    color: "darkGray",
    level: 9,
    hp: "5d8",
    speed: 110,
    accuracy: 10,
    defense: 9,
    attacks: [{ verb: "golpeia", damage: "1d10" }],
    xp: 55,
    flags: ["opensDoors", "archer"],
    depth: [8, 14],
    rarity: 4,
    desc: "Um elfo de pele escura que dispara virotes envenenados."
  }),
  m({
    id: "hill_giant",
    name: "gigante das colinas",
    gender: "m",
    glyph: "H",
    color: "brown",
    level: 12,
    hp: "8d10",
    speed: 100,
    accuracy: 11,
    defense: 9,
    attacks: [{ verb: "esmaga", damage: "2d10" }],
    xp: 110,
    flags: ["opensDoors"],
    depth: [11, 17],
    rarity: 4,
    desc: "Um gigante de quatro metros que atira pedras."
  }),
  // ── Andares 13–16 ────────────────────────────────────────────
  m({
    id: "vampire",
    name: "vampiro",
    gender: "m",
    glyph: "V",
    color: "red",
    level: 14,
    hp: "8d10",
    speed: 110,
    accuracy: 14,
    defense: 12,
    attacks: [{ verb: "morde", damage: "2d6", effect: { status: "drain", chance: 30 } }, { verb: "arranha", damage: "1d8" }],
    xp: 200,
    flags: ["undead", "regenerates", "opensDoors"],
    depth: [13, 19],
    rarity: 3,
    desc: "Um nobre p\xE1lido de olhos vermelhos e sorriso afiado."
  }),
  m({
    id: "stone_golem",
    name: "golem de pedra",
    gender: "m",
    glyph: "G",
    color: "lightGray",
    level: 14,
    hp: "10d10",
    speed: 70,
    accuracy: 13,
    defense: 14,
    attacks: [{ verb: "esmaga", damage: "3d8" }],
    xp: 180,
    flags: [],
    depth: [13, 19],
    rarity: 3,
    desc: "Uma est\xE1tua animada, lenta mas quase indestrut\xEDvel."
  }),
  m({
    id: "naga",
    name: "naga",
    gender: "f",
    glyph: "N",
    color: "lightBlue",
    level: 13,
    hp: "8d8",
    speed: 100,
    accuracy: 13,
    defense: 11,
    attacks: [{ verb: "morde", damage: "2d8" }, { verb: "esmaga", damage: "1d10" }],
    xp: 160,
    flags: ["caster"],
    depth: [12, 18],
    rarity: 3,
    desc: "Uma serpente gigante com rosto humano."
  }),
  m({
    id: "fire_elemental",
    name: "elemental do fogo",
    gender: "m",
    glyph: "E",
    color: "orange",
    level: 14,
    hp: "7d8",
    speed: 120,
    accuracy: 14,
    defense: 12,
    attacks: [{ verb: "queima", damage: "3d6", element: "fire" }],
    xp: 190,
    flags: [],
    depth: [13, 19],
    rarity: 3,
    desc: "Uma coluna viva de chamas."
  }),
  m({
    id: "frost_elemental",
    name: "elemental do gelo",
    gender: "m",
    glyph: "E",
    color: "lightCyan",
    level: 14,
    hp: "7d8",
    speed: 100,
    accuracy: 14,
    defense: 13,
    attacks: [{ verb: "congela", damage: "3d6", element: "cold" }],
    xp: 190,
    flags: [],
    depth: [13, 19],
    rarity: 3,
    desc: "Uma silhueta de gelo que estala a cada passo."
  }),
  m({
    id: "mind_flayer",
    name: "devorador de mentes",
    gender: "m",
    glyph: "h",
    color: "magenta",
    level: 15,
    hp: "7d8",
    speed: 110,
    accuracy: 15,
    defense: 13,
    attacks: [{ verb: "agarra", damage: "2d6", effect: { status: "confused", chance: 40, duration: "1d4+1" } }],
    xp: 230,
    flags: ["opensDoors", "caster"],
    depth: [14, 20],
    rarity: 2,
    desc: "Uma criatura de cabe\xE7a de polvo que se alimenta de c\xE9rebros."
  }),
  // ── Andares 17–20 ────────────────────────────────────────────
  m({
    id: "lich",
    name: "lich",
    gender: "m",
    glyph: "L",
    color: "lightMagenta",
    level: 18,
    hp: "10d8",
    speed: 100,
    accuracy: 17,
    defense: 15,
    attacks: [{ verb: "toca", damage: "3d6", element: "cold" }],
    xp: 400,
    flags: ["undead", "caster", "opensDoors"],
    depth: [17, 20],
    rarity: 2,
    desc: "Um feiticeiro que trocou a vida pela imortalidade."
  }),
  m({
    id: "red_dragon",
    name: "drag\xE3o vermelho",
    gender: "m",
    glyph: "D",
    color: "red",
    level: 19,
    hp: "14d10",
    speed: 100,
    accuracy: 18,
    defense: 17,
    attacks: [{ verb: "morde", damage: "3d10" }, { verb: "arranha", damage: "2d8" }],
    xp: 600,
    flags: ["breathFire"],
    depth: [17, 20],
    rarity: 2,
    desc: "Um drag\xE3o de escamas rubras que cospe fogo."
  }),
  m({
    id: "blue_dragon",
    name: "drag\xE3o azul",
    gender: "m",
    glyph: "D",
    color: "lightBlue",
    level: 18,
    hp: "13d10",
    speed: 100,
    accuracy: 17,
    defense: 16,
    attacks: [{ verb: "morde", damage: "3d8" }, { verb: "arranha", damage: "2d8" }],
    xp: 520,
    flags: ["breathLightning"],
    depth: [16, 20],
    rarity: 2,
    desc: "Um drag\xE3o azul cercado de fa\xEDscas."
  }),
  m({
    id: "demon",
    name: "dem\xF4nio",
    gender: "m",
    glyph: "&",
    color: "lightRed",
    level: 18,
    hp: "12d10",
    speed: 110,
    accuracy: 18,
    defense: 16,
    attacks: [{ verb: "arranha", damage: "2d10" }, { verb: "arranha", damage: "2d10" }],
    xp: 500,
    flags: ["opensDoors"],
    depth: [17, 20],
    rarity: 2,
    desc: "Uma criatura do Abismo, chifruda e envolta em fuma\xE7a."
  }),
  m({
    id: "abyssal_horror",
    name: "horror abissal",
    gender: "m",
    glyph: "U",
    color: "magenta",
    level: 20,
    hp: "15d10",
    speed: 100,
    accuracy: 19,
    defense: 17,
    attacks: [{ verb: "esmaga", damage: "3d10" }, { verb: "agarra", damage: "2d8", effect: { status: "confused", chance: 30, duration: "1d4" } }],
    xp: 750,
    flags: [],
    depth: [18, 20],
    rarity: 2,
    desc: "Uma massa de tent\xE1culos e olhos que n\xE3o deveria existir."
  })
];
function monsterTemplate(id) {
  const t = MONSTERS.find((x) => x.id === id) ?? BOSSES.find((x) => x.id === id);
  if (!t) throw new Error(`Monstro desconhecido: ${id}`);
  return t;
}

// src/data/affixes.ts
var W = ["weapon"];
var A = ["armor"];
var ANY = ["weapon", "armor", "jewelry", "launcher"];
var WEAR = ["armor", "jewelry"];
var AFFIXES = [
  // ── Prefixos de arma ────────────────────────────────────────────
  { id: "sharp", kind: "prefix", name: ["Afiado", "Afiada"], applies: W, minLevel: 1, weight: 10, bonus: { damage: 2 }, desc: "+2 de dano" },
  { id: "keen", kind: "prefix", name: ["Preciso", "Precisa"], applies: [...W, "launcher"], minLevel: 1, weight: 10, bonus: { accuracy: 3 }, desc: "+3 de precis\xE3o" },
  { id: "brutal", kind: "prefix", name: ["Brutal", "Brutal"], applies: W, minLevel: 6, weight: 5, bonus: { damage: 4, accuracy: -1 }, desc: "+4 de dano, -1 de precis\xE3o" },
  { id: "flaming", kind: "prefix", name: ["Flamejante", "Flamejante"], applies: W, minLevel: 3, weight: 6, bonus: { brand: "fire", brandDamage: "1d6" }, desc: "causa +1d6 de dano de fogo" },
  { id: "frost", kind: "prefix", name: ["G\xE9lido", "G\xE9lida"], applies: W, minLevel: 3, weight: 6, bonus: { brand: "cold", brandDamage: "1d6" }, desc: "causa +1d6 de dano de gelo" },
  { id: "shocking", kind: "prefix", name: ["El\xE9trico", "El\xE9trica"], applies: W, minLevel: 5, weight: 5, bonus: { brand: "lightning", brandDamage: "1d8" }, desc: "causa +1d8 de dano el\xE9trico" },
  { id: "venomous", kind: "prefix", name: ["Venenoso", "Venenosa"], applies: W, minLevel: 4, weight: 5, bonus: { brand: "poison", brandDamage: "1d6" }, desc: "causa +1d6 de dano de veneno" },
  { id: "holy", kind: "prefix", name: ["Sagrado", "Sagrada"], applies: W, minLevel: 7, weight: 3, bonus: { brand: "holy", brandDamage: "2d6" }, desc: "+2d6 de dano sagrado (mortos-vivos sofrem o dobro)" },
  { id: "vampiric", kind: "prefix", name: ["Vamp\xEDrico", "Vamp\xEDrica"], applies: W, minLevel: 8, weight: 3, bonus: { lifeSteal: 15 }, desc: "rouba 15% do dano causado como vida" },
  { id: "quick", kind: "prefix", name: ["Veloz", "Veloz"], applies: ANY, minLevel: 10, weight: 2, bonus: { speed: 10 }, desc: "+10 de velocidade" },
  // ── Prefixos de armadura ────────────────────────────────────────
  { id: "reinforced", kind: "prefix", name: ["Refor\xE7ado", "Refor\xE7ada"], applies: A, minLevel: 1, weight: 10, bonus: { defense: 2 }, desc: "+2 de defesa" },
  { id: "warded", kind: "prefix", name: ["Encantado", "Encantada"], applies: A, minLevel: 6, weight: 5, bonus: { defense: 4 }, desc: "+4 de defesa" },
  { id: "glowing", kind: "prefix", name: ["Luminoso", "Luminosa"], applies: ANY, minLevel: 2, weight: 4, bonus: { light: 1 }, desc: "+1 de luz" },
  // ── Sufixos ─────────────────────────────────────────────────────
  { id: "of_bear", kind: "suffix", name: ["do Urso", "do Urso"], applies: ANY, minLevel: 1, weight: 8, bonus: { stat: "str", statAmount: 2 }, desc: "+2 de For\xE7a" },
  { id: "of_fox", kind: "suffix", name: ["da Raposa", "da Raposa"], applies: ANY, minLevel: 1, weight: 8, bonus: { stat: "dex", statAmount: 2 }, desc: "+2 de Destreza" },
  { id: "of_ox", kind: "suffix", name: ["do Boi", "do Boi"], applies: ANY, minLevel: 1, weight: 8, bonus: { stat: "con", statAmount: 2 }, desc: "+2 de Constitui\xE7\xE3o" },
  { id: "of_sage", kind: "suffix", name: ["do S\xE1bio", "do S\xE1bio"], applies: ANY, minLevel: 1, weight: 6, bonus: { stat: "int", statAmount: 2 }, desc: "+2 de Intelig\xEAncia" },
  { id: "of_oracle", kind: "suffix", name: ["do Or\xE1culo", "do Or\xE1culo"], applies: ANY, minLevel: 1, weight: 6, bonus: { stat: "wis", statAmount: 2 }, desc: "+2 de Sabedoria" },
  { id: "of_vitality", kind: "suffix", name: ["da Vitalidade", "da Vitalidade"], applies: WEAR, minLevel: 3, weight: 6, bonus: { hpPct: 15 }, desc: "+15% de HP m\xE1ximo" },
  { id: "of_arcana", kind: "suffix", name: ["do Arcano", "do Arcano"], applies: ANY, minLevel: 3, weight: 5, bonus: { mp: 6 }, desc: "+6 de MP m\xE1ximo" },
  { id: "of_sight", kind: "suffix", name: ["da Vis\xE3o", "da Vis\xE3o"], applies: WEAR, minLevel: 2, weight: 4, bonus: { light: 1 }, desc: "+1 de luz" },
  { id: "of_flame", kind: "suffix", name: ["da Chama", "da Chama"], applies: WEAR, minLevel: 4, weight: 5, bonus: { resist: "fire", resistPct: 50 }, desc: "resist\xEAncia a fogo" },
  { id: "of_frost", kind: "suffix", name: ["do Inverno", "do Inverno"], applies: WEAR, minLevel: 4, weight: 5, bonus: { resist: "cold", resistPct: 50 }, desc: "resist\xEAncia a gelo" },
  { id: "of_storm", kind: "suffix", name: ["da Tempestade", "da Tempestade"], applies: WEAR, minLevel: 6, weight: 4, bonus: { resist: "lightning", resistPct: 50 }, desc: "resist\xEAncia a eletricidade" },
  { id: "of_antidote", kind: "suffix", name: ["do Ant\xEDdoto", "do Ant\xEDdoto"], applies: WEAR, minLevel: 3, weight: 4, bonus: { resist: "poison", resistPct: 50 }, desc: "resist\xEAncia a veneno" },
  { id: "of_regen", kind: "suffix", name: ["da Regenera\xE7\xE3o", "da Regenera\xE7\xE3o"], applies: WEAR, minLevel: 7, weight: 3, bonus: { flag: "regen" }, desc: "regenera HP mais r\xE1pido" },
  { id: "of_shadows", kind: "suffix", name: ["das Sombras", "das Sombras"], applies: WEAR, minLevel: 5, weight: 3, bonus: { flag: "stealthy" }, desc: "furtividade (monstros demoram a acordar)" },
  { id: "of_protection", kind: "suffix", name: ["da Prote\xE7\xE3o", "da Prote\xE7\xE3o"], applies: ANY, minLevel: 2, weight: 7, bonus: { defense: 2 }, desc: "+2 de defesa" },
  { id: "of_slaying", kind: "suffix", name: ["da Matan\xE7a", "da Matan\xE7a"], applies: [...W, "launcher"], minLevel: 8, weight: 3, bonus: { damage: 3, accuracy: 3 }, desc: "+3 de dano e precis\xE3o" },
  // ── Afixos ruins (amaldiçoados) ─────────────────────────────────
  { id: "rusty", kind: "prefix", name: ["Enferrujado", "Enferrujada"], applies: W, minLevel: 1, weight: 5, bad: true, bonus: { damage: -2 }, desc: "-2 de dano" },
  { id: "of_weakness", kind: "suffix", name: ["da Fraqueza", "da Fraqueza"], applies: ANY, minLevel: 1, weight: 5, bad: true, bonus: { stat: "str", statAmount: -2 }, desc: "-2 de For\xE7a" },
  { id: "of_clumsiness", kind: "suffix", name: ["da In\xE9pcia", "da In\xE9pcia"], applies: ANY, minLevel: 1, weight: 5, bad: true, bonus: { stat: "dex", statAmount: -2 }, desc: "-2 de Destreza" },
  { id: "of_slowness", kind: "suffix", name: ["da Lentid\xE3o", "da Lentid\xE3o"], applies: ANY, minLevel: 3, weight: 3, bad: true, bonus: { speed: -10 }, desc: "-10 de velocidade" },
  { id: "of_darkness", kind: "suffix", name: ["da Escurid\xE3o", "da Escurid\xE3o"], applies: WEAR, minLevel: 1, weight: 3, bad: true, bonus: { light: -1 }, desc: "-1 de luz" },
  // ── Exclusivos de artefatos ─────────────────────────────────────
  { id: "art_fury", kind: "suffix", name: ["", ""], applies: [], minLevel: 0, weight: 0, artifact: true, bonus: { lifeSteal: 10, stat: "str", statAmount: 3 }, desc: "+3 de For\xE7a, rouba 10% do dano" },
  { id: "art_whisper", kind: "suffix", name: ["", ""], applies: [], minLevel: 0, weight: 0, artifact: true, bonus: { stat: "dex", statAmount: 4, flag: "stealthy" }, desc: "+4 de Destreza, furtividade" },
  { id: "art_aegis", kind: "suffix", name: ["", ""], applies: [], minLevel: 0, weight: 0, artifact: true, bonus: { hpPct: 20, resist: "fire", resistPct: 50 }, desc: "+20% de HP, resist\xEAncia a fogo" },
  { id: "art_aegis2", kind: "suffix", name: ["", ""], applies: [], minLevel: 0, weight: 0, artifact: true, bonus: { resist: "cold", resistPct: 50 }, desc: "resist\xEAncia a gelo" },
  { id: "art_north", kind: "suffix", name: ["", ""], applies: [], minLevel: 0, weight: 0, artifact: true, bonus: { speed: 10, accuracy: 5 }, desc: "+10 de velocidade, +5 de precis\xE3o" },
  { id: "art_crown", kind: "suffix", name: ["", ""], applies: [], minLevel: 0, weight: 0, artifact: true, bonus: { stat: "wis", statAmount: 3, flag: "regen" }, desc: "+3 de Sabedoria, regenera\xE7\xE3o" },
  { id: "art_crown2", kind: "suffix", name: ["", ""], applies: [], minLevel: 0, weight: 0, artifact: true, bonus: { stat: "int", statAmount: 3, mp: 10 }, desc: "+3 de Intelig\xEAncia, +10 MP" },
  { id: "art_star", kind: "suffix", name: ["", ""], applies: [], minLevel: 0, weight: 0, artifact: true, bonus: { light: 2, mp: 15 }, desc: "+2 de luz, +15 MP" }
];
var ARTIFACTS = [
  { id: "kragg", name: "F\xFAria de Kragg", baseId: "greatsword", enchant: 3, affixes: ["flaming", "art_fury"], minDepth: 8 },
  { id: "whisper", name: "Sussurro da Noite", baseId: "dagger", enchant: 4, affixes: ["venomous", "art_whisper"], minDepth: 5 },
  { id: "aegis", name: "\xC9gide de Val\xF3ria", baseId: "large_shield", enchant: 3, affixes: ["art_aegis", "art_aegis2"], minDepth: 8 },
  { id: "north_wind", name: "Arco do Vento Norte", baseId: "long_bow", enchant: 3, affixes: ["art_north", "shocking"], minDepth: 8 },
  { id: "dead_crown", name: "Coroa do Rei Morto", baseId: "iron_helm", enchant: 3, affixes: ["art_crown", "art_crown2"], minDepth: 10 },
  { id: "ystar_eye", name: "Olho de Ystar", baseId: "amulet_mind", enchant: 2, affixes: ["art_star"], minDepth: 10 },
  { id: "dawnbringer", name: "Portadora da Aurora", baseId: "long_sword", enchant: 4, affixes: ["holy", "glowing", "of_vitality"], minDepth: 6 },
  { id: "mithril_coat", name: "Manto de Prata Viva", baseId: "mithril_mail", enchant: 4, affixes: ["of_regen", "of_storm"], minDepth: 14 }
];
function affixById(id) {
  return AFFIXES.find((a) => a.id === id);
}

// src/core/affixText.ts
function affixName(affixId, name, gender) {
  const a = affixById(affixId);
  if (!a || a.artifact) return name;
  return `${name} ${a.name[gender === "f" ? 1 : 0]}`;
}

// src/data/appearances.ts
var POTION_LOOKS = [
  "borbulhante violeta",
  "turva marrom",
  "cintilante dourada",
  "espessa verde",
  "fumegante cinza",
  "leitosa branca",
  "efervescente rosa",
  "oleosa negra",
  "brilhante azul",
  "viscosa amarela",
  "gelada prateada",
  "morna vermelha",
  "fosforescente esmeralda",
  "perolada",
  "\xE2mbar",
  "cor de vinho",
  "enevoada",
  "cristalina"
];
var SCROLL_SYLLABLES = ["xu", "qa", "zab", "mor", "tel", "fi", "gra", "nok", "ul", "veth", "sar", "kor", "ix", "pla", "dun", "eth", "yol", "ram"];
var WAND_LOOKS = ["de \xE9bano", "de carvalho", "de osso", "de cristal", "de cobre", "de prata", "de marfim", "de ferro", "de vidro", "de jade", "retorcida", "de bambu"];
var RING_LOOKS = ["de jade", "de rubi", "de safira", "de \xF4nix", "de ferro", "de ouro", "de prata", "de osso", "de opala", "de \xE2mbar", "de esmeralda"];
var AMULET_LOOKS = ["de ossos", "de prata tran\xE7ada", "com um olho", "de obsidiana", "em espiral"];
var LOOK_COLORS = {
  potion: {
    "borbulhante violeta": "magenta",
    "turva marrom": "brown",
    "cintilante dourada": "gold",
    "espessa verde": "green",
    "fumegante cinza": "darkGray",
    "leitosa branca": "white",
    "efervescente rosa": "lightMagenta",
    "oleosa negra": "black",
    "brilhante azul": "lightBlue",
    "viscosa amarela": "yellow",
    "gelada prateada": "lightGray",
    "morna vermelha": "red",
    "fosforescente esmeralda": "lightGreen",
    perolada: "white",
    "\xE2mbar": "orange",
    "cor de vinho": "darkRed",
    enevoada: "lightGray",
    cristalina: "lightCyan"
  },
  wand: {
    "de \xE9bano": "darkGray",
    "de carvalho": "brown",
    "de osso": "white",
    "de cristal": "lightCyan",
    "de cobre": "orange",
    "de prata": "lightGray",
    "de marfim": "white",
    "de ferro": "darkGray",
    "de vidro": "cyan",
    "de jade": "green",
    retorcida: "brown",
    "de bambu": "yellow"
  },
  ring: {
    "de jade": "green",
    "de rubi": "red",
    "de safira": "blue",
    "de \xF4nix": "black",
    "de ferro": "darkGray",
    "de ouro": "gold",
    "de prata": "lightGray",
    "de osso": "white",
    "de opala": "lightCyan",
    "de \xE2mbar": "orange",
    "de esmeralda": "lightGreen"
  },
  amulet: {
    "de ossos": "white",
    "de prata tran\xE7ada": "lightGray",
    "com um olho": "lightBlue",
    "de obsidiana": "darkGray",
    "em espiral": "cyan"
  }
};
function isLookCategory(c) {
  return c === "potion" || c === "wand" || c === "ring" || c === "amulet";
}

// src/core/identify.ts
var LOOK_CATEGORIES = ["potion", "scroll", "wand", "ring", "amulet"];
function createIdState(seed) {
  const rng = new RNG(seed).fork("identify");
  const appearances = {};
  const assign = (cat, looks) => {
    const bases = ITEMS.filter((b2) => b2.category === cat);
    const pool = rng.shuffle(looks);
    bases.forEach((b2, i) => {
      appearances[b2.id] = pool[i % pool.length];
    });
  };
  assign("potion", POTION_LOOKS);
  assign("wand", WAND_LOOKS);
  assign("ring", RING_LOOKS);
  assign("amulet", AMULET_LOOKS);
  const usedLabels = /* @__PURE__ */ new Set();
  for (const b2 of ITEMS.filter((x) => x.category === "scroll")) {
    let label = "";
    do {
      const n = rng.int(2, 3);
      label = Array.from({ length: n }, () => rng.pick(SCROLL_SYLLABLES)).join(" ").toUpperCase();
    } while (usedLabels.has(label));
    usedLabels.add(label);
    appearances[b2.id] = label;
  }
  return { appearances, known: [] };
}
function needsIdentification(baseId) {
  return LOOK_CATEGORIES.includes(itemBase(baseId).category);
}
function isKnown(game, baseId) {
  return !needsIdentification(baseId) || game.idState.known.includes(baseId);
}
function learn(game, baseId) {
  if (isKnown(game, baseId)) return false;
  game.idState.known.push(baseId);
  return true;
}
function identifyItem(game, item) {
  learn(game, item.baseId);
  item.identified = true;
}
function unknownName(game, baseId, plural) {
  if (isKnown(game, baseId)) return void 0;
  const look = game.idState.appearances[baseId] ?? "???";
  switch (itemBase(baseId).category) {
    case "potion":
      return { name: plural ? `po\xE7\xF5es (${look})` : `po\xE7\xE3o ${look}`, gender: "f" };
    case "scroll":
      return { name: `${plural ? "pergaminhos" : "pergaminho"} "${look}"`, gender: "m" };
    case "wand":
      return { name: `${plural ? "varinhas" : "varinha"} ${look}`, gender: "f" };
    case "ring":
      return { name: `${plural ? "an\xE9is" : "anel"} ${look}`, gender: "m" };
    case "amulet":
      return { name: `${plural ? "amuletos" : "amuleto"} ${look}`, gender: "m" };
  }
  return void 0;
}
function lookOf(game, baseId) {
  const cat = itemBase(baseId).category;
  if (!isLookCategory(cat)) return void 0;
  const look = game.idState?.appearances[baseId];
  return look ? { cat, look } : void 0;
}

// src/core/itemText.ts
var RARITY_COLOR = { common: "white", magic: "lightBlue", rare: "yellow", legendary: "orange" };
function baseName(game, item, plural) {
  const base = itemBase(item.baseId);
  const unknown = game ? unknownName(game, item.baseId, plural) : void 0;
  if (unknown) return unknown;
  if (item.baseId === "corpse") return { name: plural ? "cad\xE1veres" : `cad\xE1ver de ${item.corpseName ?? "criatura"}`, gender: "m" };
  const name = plural ? base.plural ?? pluralize(base.name) : base.name;
  return { name, gender: base.gender };
}
function pluralize(name) {
  const [first, ...rest] = name.split(" ");
  let p;
  if (first.endsWith("\xE3o")) p = `${first.slice(0, -2)}\xF5es`;
  else if (first.endsWith("l")) p = `${first.slice(0, -1)}is`;
  else if (/[rsz]$/.test(first)) p = `${first}es`;
  else if (first.endsWith("m")) p = `${first.slice(0, -1)}ns`;
  else p = `${first}s`;
  return [p, ...rest].join(" ");
}
function itemName(game, item, article = "a") {
  const plural = item.quantity > 1;
  const { name, gender } = baseName(game, item, plural);
  let full = name;
  if (item.identified) {
    if (item.enchant !== 0) full += ` ${item.enchant > 0 ? "+" : ""}${item.enchant}`;
    for (const a of item.affixes) full = affixName(a, full, gender);
    if (item.properName) return `${item.properName} (${full})`;
  } else if (item.rarity !== "common" || item.enchant !== 0 || item.cursed) {
    const word = item.rarity === "legendary" ? "lend\xE1ri" : item.rarity === "rare" ? "rar" : "m\xE1gic";
    full += ` (${word}${gender === "f" ? "a" : "o"}?)`;
  }
  const base = itemBase(item.baseId);
  if (base.category === "wand" && item.identified && item.charges !== void 0) full += ` (${item.charges})`;
  if (base.category === "light" && item.fuel !== void 0 && item.fuel <= 200) full += " (quase apagando)";
  if (item.cursed && item.identified) full += " {amaldi\xE7oad" + (gender === "f" ? "a" : "o") + "}";
  if (plural) return `${item.quantity} ${full}`;
  if (article === "none") return full;
  if (article === "the") return `${gender === "f" ? "a" : "o"} ${full}`;
  return `${gender === "f" ? "uma" : "um"} ${full}`;
}
function itemColor(item, game) {
  const base = itemBase(item.baseId);
  if (item.baseId === "corpse" && item.corpseOf) return monsterTemplate(item.corpseOf).color;
  if (item.rarity !== "common" && item.identified) return RARITY_COLOR[item.rarity];
  const look = game ? lookOf(game, item.baseId) : void 0;
  if (look) return LOOK_COLORS[look.cat][look.look] ?? base.color;
  return base.color;
}

// src/core/text.ts
function theName(a) {
  if (a.isPlayer) return "voc\xEA";
  if (a.properName) return a.name;
  return `${a.gender === "f" ? "a" : "o"} ${a.name}`;
}
function aName(a) {
  if (a.isPlayer) return "voc\xEA";
  if (a.properName) return a.name;
  return `${a.gender === "f" ? "uma" : "um"} ${a.name}`;
}
function capitalize(s) {
  return s.charAt(0).toUpperCase() + s.slice(1);
}
function adj(masc, g) {
  if (g === "m") return masc;
  return masc.endsWith("o") ? `${masc.slice(0, -1)}a` : masc;
}

// src/core/inventory.ts
var MAX_INVENTORY = 26 + 26;
var LETTERS = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
function inventory(game) {
  return game.hero.inventory;
}
function carryCapacity(game) {
  return Math.round((30 + 6 * game.hero.stats.str) * raceById(game.hero.raceId).carry);
}
function totalWeight(game) {
  return inventory(game).reduce((s, i) => s + itemWeight(i), 0);
}
function burden(game) {
  const w = totalWeight(game);
  const cap = carryCapacity(game);
  if (w > cap * 1.5) return 2;
  if (w > cap) return 1;
  return 0;
}
function addToInventory(game, item) {
  const inv = inventory(game);
  const same = inv.find((i) => canStack(i, item));
  if (same) {
    same.quantity += item.quantity;
    return same;
  }
  if (inv.length >= MAX_INVENTORY) return null;
  const used = new Set(inv.map((i) => i.letter));
  item.letter = [...LETTERS].find((l) => !used.has(l));
  inv.push(item);
  sortInventory(game);
  return item;
}
function takeFromInventory(game, item, qty = item.quantity) {
  const inv = inventory(game);
  if (qty >= item.quantity) {
    unequipItem(game, item);
    game.hero.inventory = inv.filter((i) => i !== item);
    return item;
  }
  item.quantity -= qty;
  return { ...item, id: game.nextId++, quantity: qty, letter: void 0 };
}
var CATEGORY_ORDER = ["weapon", "launcher", "ammo", "armor", "shield", "helm", "gloves", "boots", "cloak", "ring", "amulet", "light", "potion", "scroll", "wand", "book", "food", "corpse", "artifact"];
function sortInventory(game) {
  game.hero.inventory.sort((a, b2) => {
    const ca = CATEGORY_ORDER.indexOf(itemBase(a.baseId).category);
    const cb = CATEGORY_ORDER.indexOf(itemBase(b2.baseId).category);
    return ca - cb || (a.letter ?? "").localeCompare(b2.letter ?? "");
  });
}
function equippedId(game, slot) {
  return game.hero.equipment[slot];
}
function equipped(game, slot) {
  const id = game.hero.equipment[slot];
  return id === void 0 ? void 0 : inventory(game).find((i) => i.id === id);
}
function slotOf(game, item) {
  return Object.keys(game.hero.equipment).find((s) => game.hero.equipment[s] === item.id);
}
function isEquipped(game, item) {
  return slotOf(game, item) !== void 0;
}
function allEquipped(game) {
  return Object.keys(game.hero.equipment).map((s) => equipped(game, s)).filter((i) => !!i);
}
function unequipItem(game, item) {
  const slot = slotOf(game, item);
  if (slot) delete game.hero.equipment[slot];
}
function equip(game, item, quiet = false) {
  const base = itemBase(item.baseId);
  let slot = CATEGORY_SLOT[base.category];
  if (!slot) return false;
  if (isEquipped(game, item)) {
    if (!quiet) message(game, "Voc\xEA j\xE1 est\xE1 usando isso.", "darkGray");
    return false;
  }
  if (slot === "ring1" && equippedId(game, "ring1") !== void 0 && equippedId(game, "ring2") === void 0) slot = "ring2";
  if (slot === "weapon" && base.twoHanded && equipped(game, "offhand")) {
    if (!unequip(game, "offhand", quiet)) return false;
  }
  if (slot === "offhand") {
    const w = equipped(game, "weapon");
    if (w && itemBase(w.baseId).twoHanded) {
      if (!quiet) message(game, "Voc\xEA precisa das duas m\xE3os para a sua arma.", "lightGray");
      return false;
    }
  }
  if (equipped(game, slot) && !unequip(game, slot, quiet)) return false;
  if (item.quantity > 1 && slot !== "quiver" && slot !== "light") {
    const one = takeFromInventory(game, item, 1);
    const added = addToInventoryUnstacked(game, one);
    game.hero.equipment[slot] = added.id;
    item = added;
  } else {
    game.hero.equipment[slot] = item.id;
  }
  const wasUnknown = !item.identified;
  item.identified = true;
  if (!quiet) {
    if (wasUnknown) message(game, `Voc\xEA descobre: \xE9 ${itemName(game, item)}!`, item.cursed ? "lightRed" : "lightCyan");
    const verb = slot === "weapon" ? "empunha" : slot === "quiver" ? "p\xF5e na aljava" : slot === "light" ? "acende" : "veste";
    message(game, `Voc\xEA ${verb} ${itemName(game, item)}.`, "white");
    if (item.cursed) {
      item.identified = true;
      message(game, `${capitalize(itemName(game, item, "the"))} gruda em voc\xEA! Est\xE1 amaldi\xE7oad${itemBase(item.baseId).gender === "f" ? "a" : "o"}.`, "lightRed");
    }
  }
  return true;
}
function addToInventoryUnstacked(game, item) {
  const used = new Set(inventory(game).map((i) => i.letter));
  item.letter = [...LETTERS].find((l) => !used.has(l));
  inventory(game).push(item);
  sortInventory(game);
  return item;
}
function unequip(game, slot, quiet = false) {
  const item = equipped(game, slot);
  if (!item) return false;
  if (item.cursed) {
    if (!quiet) message(game, `Voc\xEA n\xE3o consegue remover ${itemName(game, item, "the")}: est\xE1 amaldi\xE7oad${itemBase(item.baseId).gender === "f" ? "a" : "o"}!`, "lightRed");
    return false;
  }
  delete game.hero.equipment[slot];
  if (!quiet) message(game, `Voc\xEA tira ${itemName(game, item, "the")}.`, "lightGray");
  const inv = inventory(game);
  const same = inv.find((i) => i !== item && canStack(i, item) && !isEquipped(game, i));
  if (same) {
    same.quantity += item.quantity;
    game.hero.inventory = inv.filter((i) => i !== item);
  }
  return true;
}
function pickUp(game, item) {
  const lvl = level(game);
  if (item.baseId === "gold") {
    game.hero.gold += item.quantity;
    removeFloorItem(lvl, item);
    message(game, `Voc\xEA pega ${item.quantity} pe\xE7as de ouro.`, "gold");
    return true;
  }
  if (item.baseId === "amulet_abyss") {
    game.hasAmulet = true;
    message(game, "Voc\xEA ergue o Cora\xE7\xE3o do Abismo. Ele pulsa em sua m\xE3o como um cora\xE7\xE3o vivo!", "lightMagenta");
    message(game, "Agora escape: volte ao andar 1 e suba a escada \u2014 ou invoque o Cora\xE7\xE3o (tecla &) para voltar num instante.", "gold");
  }
  const added = addToInventory(game, item);
  if (!added) {
    message(game, "Voc\xEA n\xE3o tem espa\xE7o na mochila.", "lightGray");
    return false;
  }
  removeFloorItem(lvl, item);
  emit(game, { type: "pickup" });
  message(game, `${added.letter} - ${itemName(game, added)}.`, "white");
  if (burden(game) > 0) message(game, burden(game) === 2 ? "Voc\xEA mal consegue se mexer com tanto peso!" : "Voc\xEA est\xE1 sobrecarregado.", "orange");
  return true;
}
function dropItem(game, item, qty = item.quantity) {
  const slot = slotOf(game, item);
  if (slot && !unequip(game, slot)) return false;
  const out = takeFromInventory(game, item, qty);
  out.x = game.player.x;
  out.y = game.player.y;
  out.letter = void 0;
  addItem(level(game), out);
  message(game, `Voc\xEA larga ${itemName(game, out)}.`, "lightGray");
  const map = level(game).map;
  if (map.tiles[game.player.y * map.width + game.player.x] === Tile.Altar && itemBase(out.baseId).category !== "gold") {
    message(game, out.cursed ? "Um brilho negro envolve o item: est\xE1 amaldi\xE7oado!" : "Um brilho \xE2mbar envolve o item: n\xE3o est\xE1 amaldi\xE7oado.", out.cursed ? "lightRed" : "yellow");
  }
  return true;
}
function describeFloor(game) {
  const items = itemsAt(level(game), game.player.x, game.player.y);
  if (!items.length) return;
  if (items.length === 1) message(game, `Voc\xEA v\xEA aqui ${itemName(game, items[0])}.`, "lightGray");
  else message(game, `H\xE1 ${items.length} itens aqui (g para pegar).`, "lightGray");
}

// src/core/bonuses.ts
function emptyBonuses() {
  return {
    stats: { str: 0, dex: 0, con: 0, int: 0, wis: 0 },
    accuracy: 0,
    damage: 0,
    defense: 0,
    light: 0,
    speed: 0,
    hpPct: 0,
    mp: 0,
    resist: {},
    brands: [],
    lifeSteal: 0,
    flags: /* @__PURE__ */ new Set(),
    spellPenalty: 0
  };
}
function addResist(b2, el, pct) {
  b2.resist[el] = Math.min(100, (b2.resist[el] ?? 0) + pct);
}
function collectBonuses(game) {
  const b2 = emptyBonuses();
  for (const item of allEquipped(game)) {
    const base = itemBase(item.baseId);
    const ench = item.enchant;
    if (base.spellPenalty) b2.spellPenalty += base.spellPenalty;
    switch (base.effect) {
      case "protection":
        b2.defense += 2 + ench;
        break;
      case "str":
        b2.stats.str += 1 + Math.max(0, ench);
        break;
      case "regen":
        b2.flags.add("regen");
        break;
      case "light":
        b2.light += 1;
        break;
      case "resist_fire":
        addResist(b2, "fire", 50);
        break;
      case "life":
        b2.hpPct += 15 + 5 * ench;
        break;
      case "mind":
        b2.mp += 5 + 2 * ench;
        b2.flags.add("confuseResist");
        break;
    }
    if (base.armor !== void 0) b2.defense += ench;
    for (const id of item.affixes) {
      const a = affixById(id);
      if (!a) continue;
      const bo = a.bonus;
      if (bo.accuracy) b2.accuracy += bo.accuracy;
      if (bo.damage) b2.damage += bo.damage;
      if (bo.defense) b2.defense += bo.defense;
      if (bo.light) b2.light += bo.light;
      if (bo.speed) b2.speed += bo.speed;
      if (bo.hpPct) b2.hpPct += bo.hpPct;
      if (bo.mp) b2.mp += bo.mp;
      if (bo.lifeSteal) b2.lifeSteal += bo.lifeSteal;
      if (bo.stat) b2.stats[bo.stat] += bo.statAmount ?? 1;
      if (bo.resist) addResist(b2, bo.resist, bo.resistPct ?? 50);
      if (bo.brand) b2.brands.push({ element: bo.brand, damage: bo.brandDamage ?? "1d6" });
      if (bo.flag) b2.flags.add(bo.flag);
    }
  }
  if (game.hero.nutrition < 150) b2.stats.str -= 2;
  const light = equipped(game, "light");
  if (light && (light.fuel === void 0 || light.fuel > 0)) b2.light += itemBase(light.baseId).light ?? 0;
  return b2;
}

// src/core/hero.ts
var STAT_NAME = { str: "For\xE7a", dex: "Destreza", con: "Constitui\xE7\xE3o", int: "Intelig\xEAncia", wis: "Sabedoria" };
var MAX_LEVEL = 30;
var BASE_LIGHT = 1;
function statMod(value) {
  return Math.floor((value - 10) / 2);
}
function xpForLevel(L) {
  if (L <= 1) return 0;
  return Math.round(10 * Math.pow(L - 1, 2.2));
}
function createHero(name, raceId, classId, rng) {
  const cls = classById(classId);
  const race = raceById(raceId);
  const stats = {};
  for (const s of [...Object.keys(cls.stats)]) {
    const variance = rng ? rng.int(-1, 2) : 0;
    stats[s] = Math.max(3, cls.stats[s] + race.mods[s] + variance);
  }
  return {
    name,
    raceId,
    classId,
    stats,
    level: 1,
    xp: 0,
    hpRolls: [],
    statPoints: 0,
    gold: 0,
    kills: 0,
    cooldowns: {},
    spells: [...STARTING_SPELLS[classId] ?? []],
    inventory: [],
    nutrition: 3e3,
    drainedXp: 0,
    equipment: {}
  };
}
function recalcPlayer(game) {
  const hero = game.hero;
  const p = game.player;
  const cls = classById(hero.classId);
  const race = raceById(hero.raceId);
  const L = hero.level;
  const bon = collectBonuses(game);
  const m2 = (s) => statMod(hero.stats[s] + bon.stats[s]);
  const hp = (cls.hpBase + hero.hpRolls.reduce((a, b2) => a + b2, 0) + m2("con") * L) * race.hpMult * (1 + bon.hpPct / 100);
  const oldMax = p.maxHp;
  p.maxHp = Math.max(L, Math.round(hp));
  if (p.maxHp > oldMax && oldMax > 0) p.hp += p.maxHp - oldMax;
  p.hp = Math.min(p.hp, p.maxHp);
  const oldMp = p.maxMp;
  p.maxMp = cls.castStat ? Math.max(0, cls.mpBase + (cls.mpPerLevel + Math.max(0, m2(cls.castStat))) * L) + bon.mp : bon.mp;
  if (p.maxMp > oldMp && oldMp > 0) p.mp += p.maxMp - oldMp;
  p.mp = Math.min(p.mp, p.maxMp);
  const weapon = equipped(game, "weapon");
  const wbase = weapon ? itemBase(weapon.baseId) : void 0;
  const finesse = !!wbase?.finesse && m2("dex") > m2("str");
  const statBonus = finesse ? m2("dex") : m2("str");
  const ench = weapon?.enchant ?? 0;
  let dice = parseDice(wbase && wbase.category === "weapon" ? wbase.damage ?? "1d2" : wbase ? "1d2" : "1d3");
  dice = { ...dice, bonus: dice.bonus + statBonus + ench + bon.damage };
  p.accuracy = Math.floor(L * cls.accuracyPerLevel) + statBonus + ench + bon.accuracy;
  let armor = 0;
  for (const slot of ["body", "offhand", "head", "hands", "feet", "cloak"]) {
    const it = equipped(game, slot);
    if (it) armor += itemBase(it.baseId).armor ?? 0;
  }
  p.defense = 2 + m2("dex") + armor + bon.defense + (hero.classId === "rogue" && L >= 10 ? 3 : 0);
  p.attacks = [{ verb: wbase && wbase.category === "weapon" ? "acerta" : "soca", damage: diceToString(dice) }];
  const load = burden(game);
  p.speed = race.speed + bon.speed - (load >= 1 ? 25 : 0);
  p.light = BASE_LIGHT + race.light + bon.light;
  p.level = L;
  p.flags = [...bon.flags, ...race.traits];
  p.resist = { ...bon.resist };
  if (race.traits.includes("poisonResist")) p.resist.poison = Math.max(p.resist.poison ?? 0, 50);
}
function gainXp(game, amount) {
  const hero = game.hero;
  const gain = Math.max(1, Math.round(amount * raceById(hero.raceId).xpMult));
  hero.xp += gain;
  while (hero.level < MAX_LEVEL && hero.xp >= xpForLevel(hero.level + 1)) levelUp(game);
}
function killXp(monsterXp, monsterLevel, heroLevel) {
  const ratio = Math.max(0.25, Math.min(2, monsterLevel / heroLevel));
  return Math.max(1, Math.round(monsterXp * ratio));
}
function levelUp(game) {
  const hero = game.hero;
  const cls = classById(hero.classId);
  hero.level++;
  const roll = Math.max(Math.ceil(cls.hitDie / 2), game.rng.combat.int(1, cls.hitDie));
  hero.hpRolls.push(roll);
  if (hero.level % 4 === 0) hero.statPoints++;
  recalcPlayer(game);
  message(game, `Voc\xEA chegou ao n\xEDvel ${hero.level}!`, "gold");
  emit(game, { type: "levelUp", x: game.player.x, y: game.player.y });
  if (hero.level % 4 === 0) message(game, "Voc\xEA pode aumentar um atributo (tecla C).", "gold");
  for (const ab of cls.abilities.filter((a) => a.level === hero.level)) {
    message(game, `Nova habilidade: ${ab.name} \u2014 ${ab.desc}`, "lightCyan");
  }
  learnLevelSpells(game);
}
function learnLevelSpells(game) {
  const hero = game.hero;
  const prog = CLASS_SPELL_PROGRESSION[hero.classId];
  if (!prog) return;
  for (const s of SPELLS) {
    if (s.generated || s.school !== prog.school || s.level > hero.level || s.level > prog.maxSpellLevel) continue;
    if (hero.spells.includes(s.id)) continue;
    if (hero.level % prog.every !== 0) continue;
    hero.spells.push(s.id);
    message(game, `Voc\xEA aprende uma nova magia: ${s.name}!`, "lightMagenta");
  }
}
function raiseStat(game, stat) {
  if (game.hero.statPoints <= 0) return false;
  game.hero.statPoints--;
  game.hero.stats[stat]++;
  recalcPlayer(game);
  message(game, `Sua ${STAT_NAME[stat].toLowerCase()} aumenta!`, "gold");
  return true;
}

// src/core/status.ts
var STATUS = {
  poisoned: { name: "Envenenado", start: "Voc\xEA est\xE1 envenenado!", end: "O veneno sai do seu corpo.", monster: "parece envenenado", good: false },
  burning: { name: "Em chamas", start: "Voc\xEA pega fogo!", end: "As chamas se apagam.", monster: "pega fogo", good: false },
  confused: { name: "Confuso", start: "Sua cabe\xE7a gira... voc\xEA est\xE1 confuso!", end: "Voc\xEA volta a pensar com clareza.", monster: "parece confuso", good: false },
  blind: { name: "Cego", start: "Voc\xEA n\xE3o enxerga nada!", end: "Sua vis\xE3o volta.", monster: "parece cego", good: false },
  hasted: { name: "Acelerado", start: "Voc\xEA se sente muito r\xE1pido!", end: "Voc\xEA volta \xE0 velocidade normal.", monster: "acelera", good: true },
  slowed: { name: "Lento", start: "Voc\xEA se sente lento.", end: "Voc\xEA volta \xE0 velocidade normal.", monster: "fica mais lento", good: false },
  asleep: { name: "Dormindo", start: "Voc\xEA cai no sono!", end: "Voc\xEA acorda.", monster: "cai no sono", good: false },
  paralyzed: { name: "Paralisado", start: "Voc\xEA n\xE3o consegue se mexer!", end: "Voc\xEA volta a se mexer.", monster: "fica paralisado", good: false },
  afraid: { name: "Com medo", start: "Voc\xEA est\xE1 apavorado!", end: "Voc\xEA recupera a coragem.", monster: "foge apavorado", good: false },
  invisible: { name: "Invis\xEDvel", start: "Seu corpo some diante dos seus olhos!", end: "Voc\xEA volta a ser vis\xEDvel.", monster: "some", good: true },
  regenerating: { name: "Regenerando", start: "Voc\xEA sente seu corpo se regenerar.", end: "A regenera\xE7\xE3o para.", monster: "se regenera", good: true },
  shielded: { name: "Escudo", start: "Um escudo m\xE1gico envolve voc\xEA.", end: "O escudo m\xE1gico se dissipa.", monster: "\xE9 envolvido por um escudo", good: true }
};
function effects(a) {
  if (!a.effects) a.effects = [];
  return a.effects;
}
function hasStatus(a, id) {
  return (a.effects ?? []).some((e) => e.id === id && e.turns > 0);
}
function statusPower(a, id) {
  return (a.effects ?? []).find((e) => e.id === id)?.power ?? 0;
}
function resists(a, id) {
  const f = a.flags;
  if ((id === "asleep" || id === "paralyzed") && f.includes("sleepResist")) return true;
  if (id === "confused" && f.includes("confuseResist")) return true;
  if (id === "poisoned" && (a.resist?.poison ?? 0) >= 100) return true;
  if (id === "burning" && (a.resist?.fire ?? 0) >= 100) return true;
  if ((id === "afraid" || id === "confused") && f.includes("unshakable")) return true;
  if ((id === "asleep" || id === "afraid" || id === "confused") && f.includes("undead") && !a.isPlayer) return id === "asleep";
  return false;
}
function addStatus(game, a, id, turns, power = 1) {
  if (resists(a, id)) {
    if (a.isPlayer) message(game, "Voc\xEA resiste!", "lightCyan");
    return false;
  }
  if (id === "poisoned" && (a.resist?.poison ?? 0) >= 50) turns = Math.ceil(turns / 2);
  const list = effects(a);
  const cur = list.find((e) => e.id === id);
  if (cur) {
    cur.turns = Math.max(cur.turns, turns) + (id === "poisoned" ? Math.floor(turns / 2) : 0);
    cur.power = Math.max(cur.power, power);
    return true;
  }
  list.push({ id, turns, power });
  const def = STATUS[id];
  if (a.isPlayer) message(game, def.start, def.good ? "lightCyan" : "orange");
  else if (isSeen(game, a)) message(game, `${capitalize(theName(a))} ${genderize(def.monster, a)}.`, "lightGray");
  if (id === "asleep" && !a.isPlayer) a.ai.state = "sleeping";
  if (id === "afraid" && !a.isPlayer) {
    a.ai.state = "fleeing";
    a.ai.fleeUntil = game.turn + turns;
  }
  return true;
}
function genderize(text, a) {
  return text.replace(/(envenenado|confuso|cego|lento|paralisado|apavorado|envolvido)/, (w) => adj(w, a.gender));
}
function removeStatus(game, a, id, quiet = false) {
  const list = effects(a);
  const had = list.some((e) => e.id === id);
  a.effects = list.filter((e) => e.id !== id);
  if (had && !quiet && a.isPlayer) message(game, STATUS[id].end, "lightGray");
}
function isSeen(game, a) {
  const map = level(game).map;
  return map.visible[a.y * map.width + a.x] === 1;
}
function effectiveSpeed(a) {
  let s = a.speed;
  if (hasStatus(a, "hasted")) s = Math.round(s * 1.5);
  if (hasStatus(a, "slowed")) s = Math.round(s * 0.5);
  return Math.max(10, s);
}
function statusDefense(a) {
  return hasStatus(a, "shielded") ? statusPower(a, "shielded") : 0;
}
function isIncapacitated(a) {
  return hasStatus(a, "asleep") || hasStatus(a, "paralyzed");
}
function tickStatuses(game, a) {
  let damage2 = 0;
  let cause;
  for (const e of effects(a)) {
    if (e.id === "poisoned") {
      damage2 += e.power;
      cause = "envenenado";
    } else if (e.id === "burning") {
      damage2 += e.power + game.rng.combat.int(0, 2);
      cause = "queimado vivo";
    } else if (e.id === "regenerating" && a.hp < a.maxHp) {
      a.hp = Math.min(a.maxHp, a.hp + e.power);
    }
    e.turns--;
  }
  for (const e of effects(a).filter((x) => x.turns <= 0)) {
    removeStatus(game, a, e.id);
    if (e.id === "asleep" && !a.isPlayer && a.ai.state === "sleeping") a.ai.state = "wandering";
  }
  if (damage2 > 0) emit(game, { type: "damage", x: a.x, y: a.y, amount: damage2, toPlayer: a.isPlayer });
  return { damage: damage2, cause };
}

// src/core/spells.ts
function spellFailChance(game, spell) {
  const hero = game.hero;
  const cls = classById(hero.classId);
  const stat = spell.school === "arcane" ? "int" : "wis";
  const castStat = cls.castStat === stat ? stat : cls.castStat ?? stat;
  let fail = spell.fail - 3 * statMod(hero.stats[castStat]) - 2 * (hero.level - spell.level);
  if (cls.castStat !== stat) fail += 15;
  if (hero.raceId === "gnome") fail -= 5;
  fail += Math.round(collectBonuses(game).spellPenalty / 2);
  return Math.max(5, Math.min(95, fail));
}
function spellPower(game, caster, spell) {
  const base = spell.power ? game.rng.combat.roll(spell.power) : 0;
  return base + (spell.perLevel ? Math.floor(caster.level / spell.perLevel) : 0);
}
function trace(game, from, to, range, pierce) {
  const map = level(game).map;
  const path = [];
  const hits = [];
  const dx = to.x - from.x;
  const dy = to.y - from.y;
  const scale = Math.max(Math.abs(dx), Math.abs(dy));
  const far = scale > 0 ? { x: from.x + Math.round(dx * range / scale), y: from.y + Math.round(dy * range / scale) } : to;
  for (const p of bresenham(from.x, from.y, far.x, far.y).slice(1, range + 1)) {
    if (!isTransparent(map, p.x, p.y)) break;
    path.push(p);
    const a = actorAt(game, p.x, p.y);
    if (a) {
      hits.push(a);
      if (!pierce) break;
    }
  }
  return { path, hits };
}
function castSpell(game, caster, spellId, target) {
  const spell = spellById(spellId) ?? game.customSpells?.find((s) => s.id === spellId);
  if (!spell) return 0;
  if (caster.isPlayer) {
    if (caster.mp < spell.cost) {
      message(game, "Voc\xEA n\xE3o tem mana suficiente.", "lightBlue");
      return 0;
    }
    if (game.rng.combat.chance(spellFailChance(game, spell))) {
      caster.mp -= Math.ceil(spell.cost / 2);
      message(game, "Voc\xEA perde a concentra\xE7\xE3o e a magia falha!", "lightBlue");
      return ACTION_COST;
    }
    caster.mp -= spell.cost;
  }
  if (spell.shape !== "self" && !target) return 0;
  const who = caster.isPlayer ? "Voc\xEA conjura" : `${capitalize(theName(caster))} conjura`;
  message(game, `${who} ${spell.name}${caster.isPlayer ? "." : "!"}`, spell.color);
  invokeEffect(game, caster, spell, target);
  return ACTION_COST;
}
function invokeEffect(game, caster, spell, target) {
  emit(game, { type: "spell", color: spell.color, x: caster.x, y: caster.y, element: spellElement(spell) });
  const affected = [];
  switch (spell.shape) {
    case "self":
      affected.push(caster);
      applyToTarget(game, caster, caster, spell);
      break;
    case "bolt":
    case "beam": {
      if (!target) break;
      if (spell.effect === "dig") {
        dig(game, caster, target, spell.range ?? 8);
        break;
      }
      const { path, hits } = trace(game, caster, target, spell.range ?? 10, spell.shape === "beam");
      const from = { x: caster.x, y: caster.y };
      const element = spellElement(spell);
      emit(game, spell.shape === "bolt" ? { type: "projectile", path, glyph: "*", color: spell.color, from, element } : { type: "bolt", path, color: spell.color, from, element });
      for (const h of hits) {
        affected.push(h);
        applyToTarget(game, caster, h, spell);
      }
      break;
    }
    case "ball": {
      if (!target) break;
      const { path, hits } = trace(game, caster, target, spell.range ?? 10, false);
      const center = hits[0] ? { x: hits[0].x, y: hits[0].y } : path[path.length - 1] ?? { x: caster.x, y: caster.y };
      emit(game, { type: "projectile", path, glyph: "*", color: spell.color, from: { x: caster.x, y: caster.y }, element: spellElement(spell) });
      const r = spell.radius ?? 1;
      emit(game, { type: "explosion", x: center.x, y: center.y, radius: r, color: spell.color, element: spellElement(spell) });
      const victims = [game.player, ...level(game).actors].filter((a) => Math.max(Math.abs(a.x - center.x), Math.abs(a.y - center.y)) <= r && a !== caster);
      for (const v of victims) {
        affected.push(v);
        applyToTarget(game, caster, v, spell);
      }
      break;
    }
  }
  return affected;
}
function turnsOf(game, spell, fallback) {
  return game.rng.combat.roll(spell.duration ?? fallback);
}
function spellElement(spell) {
  return spell.effect === "damage" ? spell.element ?? "arcane" : spell.effect;
}
function teleportActor(game, a, maxDist) {
  const map = level(game).map;
  const rng = game.rng.loot;
  for (let tries = 0; tries < 300; tries++) {
    const x = rng.int(1, map.width - 2);
    const y = rng.int(1, map.height - 2);
    if (!isWalkable(map, x, y) || actorAt(game, x, y)) continue;
    const d = Math.max(Math.abs(x - a.x), Math.abs(y - a.y));
    if (maxDist !== void 0 ? d > maxDist || d < 2 : d < 10 && tries < 200) continue;
    const from = { x: a.x, y: a.y };
    a.x = x;
    a.y = y;
    if (a.isPlayer) refreshFov(game);
    if (a.isPlayer || map.visible[idx(map, from.x, from.y)] || map.visible[idx(map, x, y)]) {
      emit(game, { type: "teleport", x: from.x, y: from.y, tx: x, ty: y });
    }
    return;
  }
}
function applyToTarget(game, caster, target, spell) {
  const name = capitalize(theName(target));
  const hostile = !target.isPlayer && caster.isPlayer;
  if (spell.effect !== "teleport" && spell.effect !== "blink" && spell.effect !== "detect" && spell.effect !== "mapping" && spell.effect !== "heal") {
    emit(game, { type: "spellHit", x: target.x, y: target.y, effect: spell.effect, element: spell.element, color: spell.color });
  }
  switch (spell.effect) {
    case "damage": {
      const holyBonus = spell.element === "holy" && target.flags.includes("undead") ? 2 : 1;
      const dmg = Math.round(spellPower(game, caster, spell) * resistMult(target, spell.element) * holyBonus);
      message(game, `${name} ${target.isPlayer ? "\xE9 atingido" : `\xE9 ${adj("atingido", target.gender)}`} (${dmg}).`, target.isPlayer ? "lightRed" : "white");
      damage(game, target, dmg, caster);
      if (spell.element === "fire" && target.hp > 0 && game.rng.combat.chance(25)) addStatus(game, target, "burning", 3, 2);
      break;
    }
    case "heal": {
      const amount = spellPower(game, caster, spell);
      target.hp = Math.min(target.maxHp, target.hp + amount);
      emit(game, { type: "heal", x: target.x, y: target.y });
      message(game, target.isPlayer ? `Voc\xEA se sente melhor (+${amount}).` : `${name} parece melhor.`, "lightGreen");
      break;
    }
    case "slow":
      addStatus(game, target, "slowed", turnsOf(game, spell, "2d6+8"));
      break;
    case "sleep":
      addStatus(game, target, "asleep", turnsOf(game, spell, "2d6+6"));
      break;
    case "fear":
      addStatus(game, target, "afraid", turnsOf(game, spell, "2d6+6"));
      break;
    case "haste":
      addStatus(game, target, "hasted", turnsOf(game, spell, "2d10+10"));
      break;
    case "shield":
      addStatus(game, target, "shielded", turnsOf(game, spell, "3d10+20"), 4 + Math.floor(caster.level / 4));
      break;
    case "cure":
      for (const s of ["poisoned", "confused", "blind", "burning"]) removeStatus(game, target, s);
      message(game, target.isPlayer ? "Voc\xEA se sente purificado." : `${name} parece melhor.`, "lightGreen");
      break;
    case "teleport":
      teleportActor(game, target);
      message(game, target.isPlayer ? "O mundo gira e voc\xEA aparece em outro lugar!" : `${name} desaparece!`, "lightMagenta");
      break;
    case "blink":
      teleportActor(game, target, 7);
      message(game, target.isPlayer ? "Voc\xEA pisca e reaparece alguns passos adiante." : `${name} pisca para outro lugar.`, "lightMagenta");
      break;
    case "detect":
      game.hero.cooldowns.tracking = game.turn + 30;
      message(game, `Voc\xEA sente a presen\xE7a de ${level(game).actors.length} criatura(s) neste andar.`, "lightGreen");
      break;
    case "mapping":
      magicMap(game);
      break;
  }
  if (hostile && target.hp > 0 && target.ai.state !== "sleeping" && target.ai.state !== "fleeing") {
    target.ai.state = "hunting";
    target.ai.lastSeen = { x: caster.x, y: caster.y };
  }
}
function magicMap(game) {
  const map = level(game).map;
  for (let y = 0; y < map.height; y++) {
    for (let x = 0; x < map.width; x++) {
      const t = getTile(map, x, y);
      if (t === Tile.Wall) {
        let near = false;
        for (let dy = -1; dy <= 1 && !near; dy++) for (let dx = -1; dx <= 1 && !near; dx++) if (getTile(map, x + dx, y + dy) !== Tile.Wall) near = true;
        if (!near) continue;
      }
      if (t === Tile.SecretDoor) continue;
      map.explored[idx(map, x, y)] = 1;
    }
  }
  message(game, "Uma imagem do andar se forma em sua mente!", "lightCyan");
}
function dig(game, caster, target, range) {
  const map = level(game).map;
  const path = [];
  for (const p of bresenham(caster.x, caster.y, target.x, target.y).slice(1, range + 1)) {
    if (p.x <= 0 || p.y <= 0 || p.x >= map.width - 1 || p.y >= map.height - 1) break;
    const t = getTile(map, p.x, p.y);
    if (t === Tile.Wall || t === Tile.SecretDoor || t === Tile.Fungus || t === Tile.DoorLocked || t === Tile.DoorClosed) setTile(map, p.x, p.y, Tile.Corridor);
    path.push(p);
  }
  emit(game, { type: "bolt", path, color: "brown", from: { x: caster.x, y: caster.y }, element: "earth" });
  message(game, "A rocha se desfaz diante de voc\xEA!", "brown");
  refreshFov(game);
}

// src/core/monster.ts
var RESISTS = {
  fire_elemental: { fire: 100 },
  frost_elemental: { cold: 100 },
  red_dragon: { fire: 75 },
  blue_dragon: { lightning: 75 },
  demon: { fire: 75 },
  abyss_guardian: { fire: 75, cold: 50 },
  green_jelly: { acid: 100, poison: 100 },
  poison_fungus: { poison: 100 },
  stone_golem: { poison: 100, lightning: 50 }
};
function createMonster(game, t, x, y, rng) {
  const hp = Math.max(1, rng.roll(t.hp));
  return createActor(newId(game), {
    templateId: t.id,
    name: t.name,
    gender: t.gender,
    glyph: t.glyph,
    color: t.color,
    x,
    y,
    speed: t.speed,
    hp,
    maxHp: hp,
    accuracy: t.accuracy,
    defense: t.defense,
    attacks: t.attacks.map((a) => ({ ...a })),
    xpValue: t.xp,
    level: t.level,
    flags: [...t.flags],
    resist: { ...t.flags.includes("undead") ? { poison: 100, cold: 50 } : {}, ...RESISTS[t.id] },
    // A maioria dos monstros começa dormindo.
    ai: { state: rng.chance(70) ? "sleeping" : "wandering", lostTurns: 0 }
  });
}

// src/gen/dungeon/common.ts
function roomCenter(r) {
  return { x: r.x + Math.floor(r.w / 2), y: r.y + Math.floor(r.h / 2) };
}
function randomPointInRoom(rng, r) {
  return { x: rng.int(r.x, r.x + r.w - 1), y: rng.int(r.y, r.y + r.h - 1) };
}
function carveRoom(map, r) {
  for (let y = r.y; y < r.y + r.h; y++) {
    for (let x = r.x; x < r.x + r.w; x++) {
      setTile(map, x, y, Tile.Floor);
      if (r.lit) map.lit[idx(map, x, y)] = 1;
    }
  }
  if (r.lit) {
    for (let y = r.y - 1; y <= r.y + r.h; y++) {
      for (let x = r.x - 1; x <= r.x + r.w; x++) if (inBounds(map, x, y)) map.lit[idx(map, x, y)] = 1;
    }
  }
}
function carveCorridorCell(map, x, y) {
  if (!inBounds(map, x, y)) return;
  if (getTile(map, x, y) === Tile.Wall) setTile(map, x, y, Tile.Corridor);
}
function carveHLine(map, x1, x2, y) {
  for (let x = Math.min(x1, x2); x <= Math.max(x1, x2); x++) carveCorridorCell(map, x, y);
}
function carveVLine(map, y1, y2, x) {
  for (let y = Math.min(y1, y2); y <= Math.max(y1, y2); y++) carveCorridorCell(map, x, y);
}
function carveLCorridor(map, rng, a, b2) {
  if (rng.chance(50)) {
    carveHLine(map, a.x, b2.x, a.y);
    carveVLine(map, a.y, b2.y, b2.x);
  } else {
    carveVLine(map, a.y, b2.y, a.x);
    carveHLine(map, a.x, b2.x, b2.y);
  }
}
function isPassableForGen(t) {
  return tileDef(t).walkable || t === Tile.DoorClosed || t === Tile.SecretDoor || t === Tile.DoorLocked;
}
function bfsDistances(map, start) {
  const dist = new Array(map.width * map.height).fill(-1);
  const queue = [start];
  dist[idx(map, start.x, start.y)] = 0;
  for (let head = 0; head < queue.length; head++) {
    const p = queue[head];
    const d = dist[idx(map, p.x, p.y)];
    for (const dir of DIRS8) {
      const nx = p.x + dir.x;
      const ny = p.y + dir.y;
      if (!inBounds(map, nx, ny)) continue;
      const i = idx(map, nx, ny);
      if (dist[i] !== -1 || !isPassableForGen(map.tiles[i])) continue;
      dist[i] = d + 1;
      queue.push({ x: nx, y: ny });
    }
  }
  return dist;
}
function isFullyConnected(map, start) {
  const dist = bfsDistances(map, start);
  for (let i = 0; i < map.tiles.length; i++) if (isPassableForGen(map.tiles[i]) && dist[i] === -1) return false;
  return true;
}
function placeDoors(map, rng, rooms, depth) {
  for (const r of rooms) {
    if (r.gone) continue;
    for (let y = r.y - 1; y <= r.y + r.h; y++) {
      for (let x = r.x - 1; x <= r.x + r.w; x++) {
        const onRing = x === r.x - 1 || x === r.x + r.w || y === r.y - 1 || y === r.y + r.h;
        if (!onRing || getTile(map, x, y) !== Tile.Corridor) continue;
        const horizWalls = getTile(map, x - 1, y) === Tile.Wall && getTile(map, x + 1, y) === Tile.Wall;
        const vertWalls = getTile(map, x, y - 1) === Tile.Wall && getTile(map, x, y + 1) === Tile.Wall;
        if (!horizWalls && !vertWalls) {
          setTile(map, x, y, Tile.Floor);
          continue;
        }
        const roll = rng.int(1, 100);
        const secretChance = Math.min(15, 2 + depth);
        if (roll <= secretChance) setTile(map, x, y, Tile.SecretDoor);
        else if (roll <= 45) setTile(map, x, y, Tile.DoorClosed);
        else if (roll <= 60) setTile(map, x, y, Tile.DoorOpen);
        else setTile(map, x, y, Tile.Floor);
      }
    }
  }
}
function placeStairs(map, rng, rooms) {
  const real = rooms.filter((r) => !r.gone);
  const upRoom = rng.pick(real);
  const up = randomPointInRoom(rng, upRoom);
  const dist = bfsDistances(map, up);
  let best = real[0];
  let bestD = -1;
  for (const r of real) {
    if (r === upRoom && real.length > 1) continue;
    const c = roomCenter(r);
    const d = dist[idx(map, c.x, c.y)];
    if (d > bestD) {
      bestD = d;
      best = r;
    }
  }
  let down = randomPointInRoom(rng, best);
  for (let tries = 0; tries < 20 && down.x === up.x && down.y === up.y; tries++) down = randomPointInRoom(rng, best);
  setTile(map, up.x, up.y, Tile.StairsUp);
  setTile(map, down.x, down.y, Tile.StairsDown);
  return { up, down };
}
function sealEdges(map) {
  for (let x = 0; x < map.width; x++) {
    setTile(map, x, 0, Tile.Wall);
    setTile(map, x, map.height - 1, Tile.Wall);
  }
  for (let y = 0; y < map.height; y++) {
    setTile(map, 0, y, Tile.Wall);
    setTile(map, map.width - 1, y, Tile.Wall);
  }
}

// src/gen/names.ts
var SYLLABLES = {
  human: { start: ["Al", "Bre", "Cor", "Da", "Ed", "Gar", "Hel", "Ma", "Ro", "Se", "Tor", "Vi"], mid: ["an", "ri", "el", "or", "a", "mi"], end: ["ric", "na", "do", "win", "ra", "mon", "lia", "go"] },
  elf: { start: ["Ae", "Ca", "El", "Fae", "Gal", "Il", "Lae", "Sil", "Tha", "Ya"], mid: ["la", "ri", "the", "va", "lin", "nu"], end: ["dir", "wen", "riel", "las", "thil", "ndra", "mir"] },
  dwarf: { start: ["Bal", "Bor", "Dur", "Gim", "Grom", "Kaz", "Thor", "Brun", "Dvar"], mid: ["in", "a", "ur", "om", "ri"], end: ["in", "dur", "grim", "li", "bek", "rak", "mund"] },
  halfling: { start: ["Bil", "Fro", "Mer", "Pip", "Sam", "Ros", "Tob", "Dai", "Lob"], mid: ["bo", "a", "ri", "li", "o"], end: ["bo", "do", "ry", "pin", "sy", "kins", "wise"] },
  half_orc: { start: ["Gro", "Kru", "Mog", "Thrak", "Ug", "Zug", "Gor", "Rak", "Nar"], mid: ["ash", "u", "ra", "go", "a"], end: ["ash", "nak", "gul", "mok", "tar", "dush", "uk"] },
  gnome: { start: ["Bim", "Fiz", "Nim", "Pod", "Tink", "Zan", "Wob", "Quil", "Gli"], mid: ["ble", "i", "wi", "o", "pe"], end: ["wick", "bik", "fen", "nock", "zle", "pip", "ble"] },
  monster: { start: ["Gr", "Kz", "Mor", "Ul", "Vash", "Zar", "Xo", "Thul", "Skor"], mid: ["ak", "og", "ul", "ix", "ar", "eth"], end: ["nak", "goth", "rax", "mul", "zug", "thar", "vex"] }
};
function randomName(rng, raceId) {
  const s = SYLLABLES[raceId] ?? SYLLABLES.human;
  const parts = [rng.pick(s.start)];
  if (rng.chance(45)) parts.push(rng.pick(s.mid));
  parts.push(rng.pick(s.end));
  return parts.join("");
}
var EPITHETS = [
  "o Devorador de Tochas",
  "o Impiedoso",
  "a Sombra Faminta",
  "o Quebra-Ossos",
  "o Sussurrante",
  "o Antigo",
  "Olho-Rubro",
  "o Profanador",
  "a F\xFAria do Abismo",
  "o Carniceiro",
  "Garra-de-Ferro",
  "o Insone"
];
function epithetName(rng) {
  return `${randomName(rng, "monster")}, ${rng.pick(EPITHETS)}`;
}

// src/gen/monsterMods.ts
function addDamage(m2, extra) {
  m2.attacks = m2.attacks.map((a) => {
    const d = parseDice(a.damage);
    return { ...a, damage: diceToString({ ...d, bonus: d.bonus + extra }) };
  });
}
function elemental(el, color) {
  return (m2) => {
    m2.attacks = m2.attacks.map((a) => ({ ...a, element: el }));
    addDamage(m2, 2);
    m2.resist = { ...m2.resist, [el]: 100 };
    m2.color = color;
  };
}
var MONSTER_MODS = [
  { id: "swift", adj: "veloz", minDepth: 1, weight: 10, apply: (m2) => {
    m2.speed = Math.round(m2.speed * 1.5);
  } },
  { id: "giant", adj: "gigante", minDepth: 2, weight: 8, apply: (m2) => {
    m2.maxHp *= 2;
    m2.hp = m2.maxHp;
    addDamage(m2, Math.max(1, Math.round(m2.level / 2)));
    m2.speed = Math.round(m2.speed * 0.9);
  } },
  { id: "venomous", adj: "venenoso", minDepth: 2, weight: 7, color: "lightGreen", apply: (m2) => {
    m2.attacks = m2.attacks.map((a) => ({ ...a, effect: a.effect ?? { status: "poisoned", chance: 40, duration: "2d4" } }));
  } },
  { id: "flaming", adj: "flamejante", minDepth: 4, weight: 5, apply: elemental("fire", "orange") },
  { id: "frozen", adj: "g\xE9lido", minDepth: 4, weight: 5, apply: elemental("cold", "lightCyan") },
  { id: "shocking", adj: "el\xE9trico", minDepth: 6, weight: 4, apply: elemental("lightning", "yellow") },
  { id: "vampiric", adj: "vamp\xEDrico", minDepth: 7, weight: 3, color: "red", apply: (m2) => {
    m2.flags.push("lifeSteal");
  } },
  { id: "armored", adj: "blindado", minDepth: 3, weight: 6, color: "white", apply: (m2) => {
    m2.defense += 4;
  } },
  { id: "shaman", adj: "m\xEDstico", minDepth: 3, weight: 4, color: "lightMagenta", apply: (m2) => {
    if (!m2.flags.includes("caster")) m2.flags.push("caster");
  } },
  { id: "invisible", adj: "invis\xEDvel", minDepth: 8, weight: 2, apply: (m2) => {
    m2.flags.push("invisible");
  } },
  { id: "ancient", adj: "ancestral", minDepth: 10, weight: 3, color: "gold", apply: (m2) => {
    m2.level += 3;
    m2.maxHp = Math.round(m2.maxHp * 1.5);
    m2.hp = m2.maxHp;
    m2.accuracy += 3;
    m2.defense += 3;
  } }
];
function applyMod(m2, mod) {
  mod.apply(m2);
  if (mod.color) m2.color = mod.color;
  m2.mods = [...m2.mods ?? [], mod.id];
  m2.name = `${m2.name} ${adj(mod.adj, m2.gender)}`;
  m2.xpValue = Math.round(m2.xpValue * 1.4);
}
function rollMonsterMods(rng, m2, depth) {
  if (m2.flags.includes("unique")) return;
  const chance = Math.min(35, 3 + depth * 1.5);
  if (!rng.chance(chance)) return;
  const pool = MONSTER_MODS.filter((x) => x.minDepth <= depth);
  applyMod(m2, rng.weighted(pool.map((x) => ({ item: x, weight: x.weight }))));
}
function makeChampion(rng, m2, depth) {
  const pool = MONSTER_MODS.filter((x) => x.minDepth <= depth + 2);
  const n = rng.int(2, 3);
  const chosen = rng.shuffle(pool).slice(0, n);
  for (const mod of chosen) applyMod(m2, mod);
  const title = epithetName(rng);
  m2.name = `${title} (${m2.name})`;
  m2.properName = true;
  m2.flags.push("champion");
  m2.maxHp = Math.round(m2.maxHp * 1.5);
  m2.hp = m2.maxHp;
  m2.xpValue *= 2;
}

// src/gen/populate.ts
function spawnPoints(level2, minDistFromUp) {
  const { map } = level2;
  const dist = bfsDistances(map, level2.up);
  const pts = [];
  for (let y = 0; y < map.height; y++) {
    for (let x = 0; x < map.width; x++) {
      const t = map.tiles[idx(map, x, y)];
      if ((t === Tile.Floor || t === Tile.Corridor || t === Tile.Rubble) && dist[idx(map, x, y)] >= minDistFromUp) pts.push({ x, y });
    }
  }
  return pts;
}
function monstersForDepth(depth) {
  const list = MONSTERS.filter((t) => !t.flags.includes("unique") && depth >= t.depth[0] && depth <= t.depth[1]);
  if (list.length) return list;
  return MONSTERS.filter((t) => !t.flags.includes("unique") && t.depth[0] <= depth);
}
function spawnMonsters(game, level2, rng, depth) {
  let budget = 4 + depth * 3;
  const points = rng.shuffle(spawnPoints(level2, 8));
  const occupied = /* @__PURE__ */ new Set();
  const free = (p) => isWalkable(level2.map, p.x, p.y) && !occupied.has(idx(level2.map, p.x, p.y));
  let pi = 0;
  for (let attempts = 0; budget > 0 && attempts < 60 && pi < points.length; attempts++) {
    const outOfDepth = depth >= 2 && rng.chance(8);
    const effDepth = outOfDepth ? depth + rng.int(2, 3) : depth;
    const t = rng.weighted(monstersForDepth(effDepth).map((m2) => ({ item: m2, weight: m2.rarity })));
    const count = t.group && !outOfDepth ? rng.int(t.group[0], t.group[1]) : 1;
    const origin = points[pi++];
    if (!free(origin)) continue;
    const spots = [origin];
    for (const d of rng.shuffle(DIRS8)) {
      if (spots.length >= count) break;
      const p = { x: origin.x + d.x, y: origin.y + d.y };
      if (free(p)) spots.push(p);
    }
    for (const p of spots) {
      occupied.add(idx(level2.map, p.x, p.y));
      const mon = createMonster(game, t, p.x, p.y, rng);
      rollMonsterMods(rng, mon, depth);
      level2.actors.push(mon);
    }
    budget -= Math.max(1, t.level) * spots.length;
  }
  if (depth >= 3 && rng.chance(20) && level2.actors.length) {
    const candidates = level2.actors.filter((a) => !a.flags.includes("unique") && !a.flags.includes("stationary"));
    if (candidates.length) makeChampion(rng, rng.pick(candidates), depth);
  }
}

// src/core/consumables.ts
var IMPLEMENTED = /* @__PURE__ */ new Set([
  // poções
  "heal",
  "heal_major",
  "mana",
  "haste",
  "gain_str",
  "gain_level",
  "cure",
  "invisible",
  "restore",
  "poison",
  "confuse",
  "blind",
  // pergaminhos
  "identify",
  "teleport",
  "mapping",
  "uncurse",
  "enchant_weapon",
  "enchant_armor",
  "light",
  "scare",
  "fireball_self",
  "summon",
  "aggravate",
  // varinhas
  "magic_missile",
  "fire_bolt",
  "frost_bolt",
  "lightning_beam",
  "slow_monster",
  "sleep_monster",
  "teleport_other",
  "dig",
  // anéis/amuletos (via bônus)
  "protection",
  "str",
  "regen",
  "resist_fire",
  "life",
  "mind",
  // tomos
  "learn_arcane",
  "learn_divine"
]);
function isImplemented(effect) {
  return effect === void 0 || IMPLEMENTED.has(effect);
}
var MAX_NUTRITION = 4e3;
function quaff(game, item) {
  const base = itemBase(item.baseId);
  if (base.category !== "potion") {
    message(game, "Isso n\xE3o se bebe.", "darkGray");
    return 0;
  }
  const wasKnown = isKnown(game, item.baseId);
  takeFromInventory(game, item, 1);
  emit(game, { type: "quaff" });
  message(game, `Voc\xEA bebe ${itemName(game, { ...item, quantity: 1 })}.`, "lightGray");
  const obvious = potionEffect(game, game.player, base.effect ?? "");
  if (obvious && !wasKnown) {
    learn(game, item.baseId);
    message(game, `(Era ${itemName(game, { ...item, quantity: 1 })}.)`, "lightCyan");
  }
  return ACTION_COST;
}
function potionEffect(game, target, effect) {
  const p = target;
  const you = target.isPlayer;
  switch (effect) {
    case "heal": {
      const amount = game.rng.loot.roll("4d6") + Math.floor(p.maxHp * 0.2);
      p.hp = Math.min(p.maxHp, p.hp + amount);
      removeStatus(game, p, "blind");
      emit(game, { type: "heal", x: p.x, y: p.y });
      message(game, you ? "Voc\xEA se sente muito melhor." : `${capitalize(theName(p))} parece melhor.`, "lightGreen");
      return true;
    }
    case "heal_major":
      p.hp = p.maxHp;
      for (const s of ["blind", "confused", "poisoned"]) removeStatus(game, p, s, true);
      emit(game, { type: "heal", x: p.x, y: p.y });
      message(game, you ? "Seus ferimentos se fecham por completo!" : `${capitalize(theName(p))} est\xE1 curado!`, "lightGreen");
      return true;
    case "mana":
      if (!you) return false;
      p.mp = p.maxMp;
      message(game, p.maxMp > 0 ? "Sua mente se enche de energia m\xE1gica." : "Voc\xEA sente um formigamento estranho.", "lightBlue");
      return p.maxMp > 0;
    case "haste":
      return addStatus(game, p, "hasted", game.rng.loot.roll("2d10+15"));
    case "gain_str":
      if (!you) return false;
      game.hero.stats.str++;
      recalcPlayer(game);
      message(game, "Voc\xEA se sente forte como um touro!", "gold");
      return true;
    case "gain_level":
      if (!you) return false;
      gainXp(game, Math.ceil(xpForLevel(game.hero.level + 1) - game.hero.xp) + 1);
      return true;
    case "cure":
      for (const s of ["poisoned", "confused", "blind", "burning"]) removeStatus(game, p, s);
      message(game, you ? "Voc\xEA se sente limpo e l\xFAcido." : `${capitalize(theName(p))} parece melhor.`, "lightGreen");
      return true;
    case "invisible":
      return addStatus(game, p, "invisible", game.rng.loot.roll("3d10+20"));
    case "restore":
      if (!you) return false;
      if (game.hero.drainedXp > 0) {
        const xp = game.hero.drainedXp;
        game.hero.drainedXp = 0;
        message(game, "Voc\xEA sente sua for\xE7a vital retornar!", "lightCyan");
        gainXp(game, xp / 1.15);
      } else message(game, "Voc\xEA se sente revigorado.", "lightCyan");
      return true;
    case "poison":
      addStatus(game, p, "poisoned", game.rng.loot.roll("2d4+4"), 2);
      if (you) damage(game, p, game.rng.loot.roll("1d4"));
      return true;
    case "confuse":
      return addStatus(game, p, "confused", game.rng.loot.roll("2d4+4"));
    case "blind":
      return addStatus(game, p, "blind", game.rng.loot.roll("3d6+6"));
  }
  message(game, "Nada parece acontecer.", "darkGray");
  return false;
}
function eat(game, item) {
  const base = itemBase(item.baseId);
  if (base.category !== "food" && base.category !== "corpse") {
    message(game, "Isso n\xE3o se come.", "darkGray");
    return 0;
  }
  const name = itemName(game, { ...item, quantity: 1 }, "the");
  takeFromInventory(game, item, 1);
  game.hero.nutrition = Math.min(MAX_NUTRITION, game.hero.nutrition + (base.nutrition ?? 200));
  if (base.category === "corpse") {
    message(game, `Voc\xEA come ${name}. Argh.`, "lightGray");
    if (item.corpseOf && ["giant_spider", "poison_fungus", "serpent", "green_jelly"].includes(item.corpseOf)) {
      addStatus(game, game.player, "poisoned", 8, 1);
    } else if (item.corpseOf && ["zombie", "skeleton", "wraith", "vampire"].includes(item.corpseOf)) {
      message(game, "Carne podre! Voc\xEA passa mal.", "orange");
      addStatus(game, game.player, "confused", 5);
    }
  } else message(game, `Voc\xEA come ${name}. Delicioso!`, "lightGray");
  recalcPlayer(game);
  return ACTION_COST;
}
function readItem(game, item, targetId) {
  const base = itemBase(item.baseId);
  if (base.category === "book") return readBook(game, item);
  if (base.category !== "scroll") {
    message(game, "N\xE3o h\xE1 nada escrito a\xED.", "darkGray");
    return 0;
  }
  if (hasBlind(game)) {
    message(game, "Voc\xEA n\xE3o consegue ler: est\xE1 cego!", "orange");
    return 0;
  }
  const wasKnown = isKnown(game, item.baseId);
  takeFromInventory(game, item, 1);
  emit(game, { type: "read" });
  message(game, `Voc\xEA l\xEA ${itemName(game, { ...item, quantity: 1 })}.`, "lightGray");
  const obvious = scrollEffect(game, base.effect ?? "", targetId);
  const arcane = game.hero.classId === "mage" && game.hero.level >= 5;
  if ((obvious || arcane) && !wasKnown) {
    learn(game, item.baseId);
    message(game, `(Era ${itemName(game, { ...item, quantity: 1 })}.)`, "lightCyan");
  }
  return ACTION_COST;
}
function hasBlind(game) {
  return (game.player.effects ?? []).some((e) => e.id === "blind");
}
function scrollEffect(game, effect, targetId) {
  const p = game.player;
  const lvl = level(game);
  switch (effect) {
    case "identify": {
      const unknown = game.hero.inventory.filter((i) => !i.identified || !isKnown(game, i.baseId));
      const target = unknown.find((i) => i.id === targetId) ?? (unknown.length ? game.rng.loot.pick(unknown) : void 0);
      if (!target) {
        message(game, "Voc\xEA j\xE1 conhece tudo o que carrega.", "lightGray");
        return true;
      }
      identifyItem(game, target);
      message(game, `${target.letter} - ${itemName(game, target)}.`, "lightCyan");
      return true;
    }
    case "teleport":
      teleportActor(game, p);
      message(game, "O mundo gira e voc\xEA aparece em outro lugar!", "lightMagenta");
      return true;
    case "mapping":
      magicMap(game);
      return true;
    case "uncurse": {
      let n = 0;
      for (const it of allEquipped(game)) if (it.cursed) {
        it.cursed = false;
        n++;
      }
      message(game, n ? "Voc\xEA sente como se algu\xE9m estivesse cuidando de voc\xEA." : "Voc\xEA sente uma leve sensa\xE7\xE3o de al\xEDvio.", "lightCyan");
      return n > 0;
    }
    case "enchant_weapon":
    case "enchant_armor": {
      const slots = effect === "enchant_weapon" ? ["weapon"] : ["body", "offhand", "head", "hands", "feet", "cloak"];
      const items = slots.map((s) => equipped(game, s)).filter((i) => !!i);
      if (!items.length) {
        message(game, "Suas m\xE3os brilham por um instante.", "lightCyan");
        return false;
      }
      const it = game.rng.loot.pick(items);
      if (it.enchant >= 9 && game.rng.loot.chance(60)) {
        message(game, `${capitalize(itemName(game, it, "the"))} vibra violentamente e se desintegra!`, "lightRed");
        takeFromInventory(game, it);
      } else {
        it.enchant++;
        it.cursed = false;
        it.identified = true;
        message(game, `${capitalize(itemName(game, it, "the"))} brilha com uma luz azul!`, "lightBlue");
      }
      recalcPlayer(game);
      return true;
    }
    case "light": {
      const map = lvl.map;
      for (let y = p.y - 6; y <= p.y + 6; y++) for (let x = p.x - 6; x <= p.x + 6; x++) if (inBounds(map, x, y)) map.lit[idx(map, x, y)] = 1;
      message(game, "Uma luz intensa ilumina a \xE1rea!", "yellow");
      for (const m2 of lvl.actors) if (distance(m2, p) <= 6 && m2.flags.includes("undead")) damage(game, m2, game.rng.loot.roll("2d6"), p);
      return true;
    }
    case "scare": {
      const near = lvl.actors.filter((m2) => distance(m2, p) <= 8);
      for (const m2 of near) addStatus(game, m2, "afraid", game.rng.loot.roll("2d6+10"));
      message(game, near.length ? "Voc\xEA ouve gritos de pavor!" : "Voc\xEA ouve uma risada man\xEDaca ao longe.", "lightGray");
      return true;
    }
    case "fireball_self": {
      emit(game, { type: "explosion", x: p.x, y: p.y, radius: 2, color: "orange", element: "fire" });
      message(game, "O pergaminho explode numa bola de fogo!", "orange");
      for (const m2 of [...lvl.actors]) if (distance(m2, p) <= 2) damage(game, m2, game.rng.loot.roll("4d6"), p);
      damage(game, p, Math.round(game.rng.loot.roll("1d6") * (1 - (p.resist?.fire ?? 0) / 100)));
      return true;
    }
    case "summon": {
      const pool = monstersForDepth(game.depth);
      let n = 0;
      for (const d of game.rng.loot.shuffle(DIRS8)) {
        if (n >= game.rng.loot.int(2, 3)) break;
        const x = p.x + d.x;
        const y = p.y + d.y;
        if (!isWalkable(lvl.map, x, y) || actorAt(game, x, y)) continue;
        const m2 = createMonster(game, game.rng.loot.pick(pool), x, y, game.rng.loot);
        m2.ai.state = "hunting";
        lvl.actors.push(m2);
        n++;
      }
      message(game, "Monstros surgem do nada ao seu redor!", "lightRed");
      return true;
    }
    case "aggravate":
      for (const m2 of lvl.actors) {
        m2.ai.state = "hunting";
        m2.ai.lastSeen = { x: p.x, y: p.y };
      }
      message(game, "Um som agudo ecoa por todo o andar!", "orange");
      return true;
  }
  message(game, "Voc\xEA n\xE3o entende as runas.", "darkGray");
  return false;
}
function readBook(game, item) {
  const base = itemBase(item.baseId);
  const school = base.effect === "learn_divine" ? "divine" : "arcane";
  const cls = classById(game.hero.classId);
  if (!cls.castStat) {
    message(game, "As palavras n\xE3o fazem sentido para voc\xEA. (Sua classe n\xE3o conjura magias.)", "darkGray");
    return 0;
  }
  learn(game, item.baseId);
  const special2 = item.spellId ? game.customSpells?.find((s) => s.id === item.spellId) : void 0;
  if (special2) {
    if (special2.level > game.hero.level + 3) {
      message(game, `As f\xF3rmulas s\xE3o avan\xE7adas demais para voc\xEA (magia de n\xEDvel ${special2.level}). Tente mais tarde.`, "lightGray");
      return 0;
    }
    takeFromInventory(game, item, 1);
    if (game.hero.spells.includes(special2.id)) {
      message(game, "Voc\xEA j\xE1 conhece esta magia.", "lightGray");
      return ACTION_COST;
    }
    game.hero.spells.push(special2.id);
    message(game, `Voc\xEA decifra o tomo e aprende uma magia rara: ${special2.name}!`, "lightMagenta");
    return ACTION_COST * 3;
  }
  const pool = SPELLS.filter((s) => !s.generated && s.school === school && s.level <= game.hero.level + 3 && !game.hero.spells.includes(s.id));
  takeFromInventory(game, item, 1);
  if (!pool.length) {
    message(game, "Voc\xEA j\xE1 conhece todas as magias deste tomo que consegue entender.", "lightGray");
    return ACTION_COST;
  }
  const chosen = game.rng.loot.pick(pool);
  game.hero.spells.push(chosen.id);
  message(game, `Voc\xEA estuda o tomo e aprende: ${chosen.name}!`, "lightMagenta");
  return ACTION_COST * 3;
}
var WAND_SPELLS = {
  magic_missile: { id: "w_mm", name: "m\xEDssil m\xE1gico", school: "arcane", level: 1, cost: 0, shape: "bolt", effect: "damage", element: "arcane", power: "3d4", range: 10, fail: 0, color: "lightMagenta", desc: "" },
  fire_bolt: { id: "w_fire", name: "raio de fogo", school: "arcane", level: 1, cost: 0, shape: "bolt", effect: "damage", element: "fire", power: "6d6", range: 10, fail: 0, color: "orange", desc: "" },
  frost_bolt: { id: "w_cold", name: "raio de gelo", school: "arcane", level: 1, cost: 0, shape: "bolt", effect: "damage", element: "cold", power: "6d6", range: 10, fail: 0, color: "lightCyan", desc: "" },
  lightning_beam: { id: "w_bolt", name: "rel\xE2mpago", school: "arcane", level: 1, cost: 0, shape: "beam", effect: "damage", element: "lightning", power: "5d8", range: 12, fail: 0, color: "yellow", desc: "" },
  slow_monster: { id: "w_slow", name: "lentid\xE3o", school: "arcane", level: 1, cost: 0, shape: "bolt", effect: "slow", range: 10, fail: 0, color: "lightGray", desc: "" },
  sleep_monster: { id: "w_sleep", name: "sono", school: "arcane", level: 1, cost: 0, shape: "bolt", effect: "sleep", range: 10, fail: 0, color: "lightBlue", desc: "" },
  teleport_other: { id: "w_tele", name: "banimento", school: "arcane", level: 1, cost: 0, shape: "bolt", effect: "teleport", range: 10, fail: 0, color: "lightGreen", desc: "" },
  dig: { id: "w_dig", name: "escava\xE7\xE3o", school: "arcane", level: 1, cost: 0, shape: "bolt", effect: "dig", range: 8, fail: 0, color: "brown", desc: "" }
};
function zapWand(game, item, target) {
  const base = itemBase(item.baseId);
  if (base.category !== "wand") {
    message(game, "Voc\xEA agita isso no ar. Nada acontece.", "darkGray");
    return 0;
  }
  if ((item.charges ?? 0) <= 0) {
    message(game, "Voc\xEA agita a varinha, mas nada acontece. (Sem cargas.)", "darkGray");
    return ACTION_COST;
  }
  item.charges = (item.charges ?? 1) - 1;
  const spell = WAND_SPELLS[base.effect ?? ""];
  if (!spell) return ACTION_COST;
  const wasKnown = isKnown(game, item.baseId);
  const affected = invokeEffect(game, game.player, spell, target);
  if (!wasKnown && (affected.length > 0 || spell.effect === "dig" || game.hero.raceId === "gnome")) {
    learn(game, item.baseId);
    item.identified = true;
    message(game, `(Era ${itemName(game, item)}.)`, "lightCyan");
  } else if (!wasKnown) message(game, "Voc\xEA n\xE3o percebe nenhum efeito.", "darkGray");
  return ACTION_COST;
}

// src/gen/spells.ts
var SHAPES = {
  bolt: { nouns: [["Dardo", "m"], ["Seta", "f"], ["Lan\xE7a", "f"], ["Proj\xE9til", "m"]], cost: 1, power: 1 },
  beam: { nouns: [["Raio", "m"], ["Feixe", "m"], ["Torrente", "f"]], cost: 1.3, power: 0.85 },
  ball: { nouns: [["Esfera", "f"], ["Nuvem", "f"], ["Explos\xE3o", "f"], ["Orbe", "m"]], cost: 1.6, power: 0.75 }
};
var ELEMENTS = {
  arcane: [
    { el: "fire", adj: ["Flamejante", "Flamejante"], color: "orange" },
    { el: "cold", adj: ["G\xE9lido", "G\xE9lida"], color: "lightCyan" },
    { el: "lightning", adj: ["Trovejante", "Trovejante"], color: "yellow" },
    { el: "acid", adj: ["\xC1cido", "\xC1cida"], color: "lightGreen" },
    { el: "poison", adj: ["Pestilento", "Pestilenta"], color: "green" },
    { el: "arcane", adj: ["Arcano", "Arcana"], color: "lightMagenta" },
    { el: "shadow", adj: ["Sombrio", "Sombria"], color: "magenta" }
  ],
  divine: [
    { el: "holy", adj: ["Sagrado", "Sagrada"], color: "white" },
    { el: "fire", adj: ["Purificador", "Purificadora"], color: "yellow" },
    { el: "lightning", adj: ["Celestial", "Celestial"], color: "lightCyan" }
  ]
};
var MODIFIERS = [
  { id: "potent", adj: ["Potente", "Potente"], cost: 1.4, power: 1.5, range: 0 },
  { id: "frugal", adj: ["Econ\xF4mico", "Econ\xF4mica"], cost: 0.7, power: 0.8, range: 0 },
  { id: "far", adj: ["Distante", "Distante"], cost: 1.1, power: 1, range: 5 }
];
var STATUS_EFFECTS = [
  { effect: "slow", noun: ["Grilh\xE3o", "m"], color: "lightGray", weight: 3 },
  { effect: "sleep", noun: ["Can\xE7\xE3o de Ninar", "f"], color: "lightBlue", weight: 2 },
  { effect: "fear", noun: ["Vis\xE3o Aterradora", "f"], color: "darkGray", weight: 2 }
];
function generateSpell(rng, depth, school) {
  const level2 = Math.max(1, Math.min(20, depth + rng.int(-1, 3)));
  const owner = randomName(rng, "monster");
  const id = `gen_${school}_${level2}_${owner.toLowerCase()}_${rng.int(0, 999999)}`;
  if (rng.chance(25)) {
    const st = rng.weighted(STATUS_EFFECTS.map((s) => ({ item: s, weight: s.weight })));
    return {
      id,
      name: `${st.noun[0]} de ${owner}`,
      school,
      level: level2,
      cost: Math.max(2, Math.round(2 + level2 * 0.6)),
      shape: "bolt",
      effect: st.effect,
      range: 10,
      fail: Math.min(60, 18 + level2 * 2),
      color: st.color,
      desc: `Magia ${school === "arcane" ? "arcana" : "divina"} procedural (${st.effect === "slow" ? "lentid\xE3o" : st.effect === "sleep" ? "sono" : "medo"}).`,
      generated: true,
      duration: `2d6+${4 + Math.floor(level2 / 2)}`
    };
  }
  const shapeId = rng.weighted([{ item: "bolt", weight: 45 }, { item: "beam", weight: 25 }, { item: "ball", weight: 30 }]);
  const shape = SHAPES[shapeId];
  const [noun, gender] = rng.pick(shape.nouns);
  const el = rng.pick(ELEMENTS[school]);
  const mod = rng.chance(40) ? rng.pick(MODIFIERS) : void 0;
  const powerMult = shape.power * (mod?.power ?? 1);
  const dice = Math.max(2, Math.round((2 + level2 / 2) * powerMult));
  const cost = Math.max(2, Math.round((3 + level2 * 1.1) * shape.cost * (mod?.cost ?? 1)));
  const g = gender === "f" ? 1 : 0;
  const name = `${noun} ${el.adj[g]}${mod ? ` ${mod.adj[g]}` : ""} de ${owner}`;
  const shapeWord = shapeId === "bolt" ? "proj\xE9til" : shapeId === "beam" ? "raio que atravessa" : "explos\xE3o em \xE1rea";
  return {
    id,
    name,
    school,
    level: level2,
    cost,
    shape: shapeId,
    effect: "damage",
    element: el.el,
    power: `${dice}d6`,
    perLevel: 2,
    radius: shapeId === "ball" ? level2 >= 10 ? 2 : 1 : void 0,
    range: 10 + (mod?.range ?? 0),
    fail: Math.min(60, 18 + level2 * 2),
    color: el.color,
    desc: `${capitalizeFirst(shapeWord)} de ${ELEMENT_NAMES[el.el]} (${dice}d6).`,
    generated: true
  };
}
var ELEMENT_NAMES = {
  fire: "fogo",
  cold: "gelo",
  lightning: "eletricidade",
  acid: "\xE1cido",
  poison: "veneno",
  arcane: "energia arcana",
  shadow: "sombras",
  holy: "luz sagrada"
};
function capitalizeFirst(s) {
  return s.charAt(0).toUpperCase() + s.slice(1);
}

// src/gen/items.ts
var CATEGORY_WEIGHTS = [
  { item: ["weapon"], weight: 12 },
  { item: ["launcher", "ammo"], weight: 5 },
  { item: ["armor", "shield", "helm", "gloves", "boots", "cloak"], weight: 13 },
  { item: ["potion"], weight: 20 },
  { item: ["scroll"], weight: 14 },
  { item: ["wand"], weight: 5 },
  { item: ["ring", "amulet"], weight: 4 },
  { item: ["food"], weight: 10 },
  { item: ["light"], weight: 4 },
  { item: ["book"], weight: 3 }
];
function basesFor(depth, categories) {
  return ITEMS.filter(
    (b2) => b2.rarity > 0 && depth >= b2.depth[0] && depth <= b2.depth[1] && (!categories || categories.includes(b2.category)) && b2.category !== "gold" && isImplemented(b2.effect)
  );
}
function generateItem(game, rng, depth, categories) {
  let pool = [];
  for (let tries = 0; tries < 10 && pool.length === 0; tries++) {
    const cats = categories ?? rng.weighted(CATEGORY_WEIGHTS);
    pool = basesFor(depth, cats);
  }
  if (!pool.length) return null;
  const base = rng.weighted(pool.map((b2) => ({ item: b2, weight: b2.rarity })));
  return rollItem(game, rng, base.id, depth);
}
function rollItem(game, rng, baseId, depth) {
  const base = itemBase(baseId);
  const item = createItem(game, baseId);
  if (base.category === "ammo") item.quantity = rng.int(8, 20);
  else if (base.id === "dart" || base.id === "dagger") item.quantity = base.id === "dart" ? rng.int(4, 10) : rng.int(1, 3);
  else if (base.category === "potion" || base.category === "scroll") item.quantity = rng.chance(15) ? 2 : 1;
  if (base.charges) item.charges = rng.roll(base.charges);
  if (base.category === "book" && rng.chance(50)) {
    const spell = generateSpell(rng, depth, base.effect === "learn_divine" ? "divine" : "arcane");
    game.customSpells = [...game.customSpells ?? [], spell];
    item.spellId = spell.id;
  }
  applyRarity(game, rng, item, depth);
  return item;
}
function affixGroup(baseId) {
  const c = itemBase(baseId).category;
  if (c === "weapon") return "weapon";
  if (c === "launcher") return "launcher";
  if (["armor", "shield", "helm", "gloves", "boots", "cloak"].includes(c)) return "armor";
  if (c === "ring" || c === "amulet") return "jewelry";
  return null;
}
function pickAffixes(rng, group, depth, count, bad) {
  const chosen = [];
  for (let i = 0; i < count; i++) {
    const pool = AFFIXES.filter((a) => !a.artifact && !!a.bad === bad && a.applies.includes(group) && a.minLevel <= depth && !chosen.some((c) => c.id === a.id || c.kind === "prefix" && a.kind === "prefix" && chosen.filter((x) => x.kind === "prefix").length >= 2));
    if (!pool.length) break;
    chosen.push(rng.weighted(pool.map((a) => ({ item: a, weight: a.weight }))));
  }
  chosen.sort((a, b2) => a.kind === b2.kind ? 0 : a.kind === "prefix" ? -1 : 1);
  return chosen.map((a) => a.id);
}
var RARE_NOUNS = ["F\xFAria", "Ru\xEDna", "Sussurro", "Lamento", "Juramento", "Presa", "Sombra", "Gl\xF3ria", "Can\xE7\xE3o", "Promessa", "Ira", "Vig\xEDlia"];
function applyRarity(game, rng, item, depth) {
  const group = affixGroup(item.baseId);
  if (!group) return;
  const base = itemBase(item.baseId);
  if (depth >= 5 && rng.chance(1 + depth / 10)) {
    const options = ARTIFACTS.filter((a) => a.minDepth <= depth && !game.artifactsFound.includes(a.id));
    if (options.length) {
      const art = rng.pick(options);
      game.artifactsFound.push(art.id);
      Object.assign(item, { baseId: art.baseId, enchant: art.enchant, affixes: [...art.affixes], rarity: "legendary", properName: art.name, identified: false, quantity: 1 });
      return;
    }
  }
  if (rng.chance(8)) {
    item.cursed = true;
    item.enchant = -rng.int(1, 3);
    item.affixes = rng.chance(60) ? pickAffixes(rng, group, depth, 1, true) : [];
    item.rarity = "magic";
    item.identified = false;
    return;
  }
  const roll = rng.next() * 100;
  if (roll < 5 + depth / 2) {
    item.rarity = "rare";
    item.affixes = pickAffixes(rng, group, depth, rng.int(3, 4), false);
    item.enchant = rng.int(1, 2 + Math.floor(depth / 5));
    item.properName = `${rng.pick(RARE_NOUNS)} de ${randomName(rng, "monster")}`;
  } else if (roll < 25 + depth) {
    item.rarity = "magic";
    item.affixes = pickAffixes(rng, group, depth, rng.chance(35) ? 2 : 1, false);
    if (rng.chance(40)) item.enchant = rng.int(1, 1 + Math.floor(depth / 6));
  } else if ((base.damage !== void 0 || base.armor !== void 0) && rng.chance(15 + depth)) {
    item.enchant = rng.int(1, 1 + Math.floor(depth / 5));
  }
  if (item.rarity !== "common" || item.enchant !== 0) item.identified = false;
}
function spawnItems(game, level2, rng, depth) {
  const points = rng.shuffle(spawnPoints(level2, 0));
  let pi = 0;
  const count = 3 + rng.int(0, 3) + Math.floor(depth / 5);
  for (let i = 0; i < count && pi < points.length; i++) {
    const item = generateItem(game, rng, depth);
    if (!item) continue;
    const p = points[pi++];
    item.x = p.x;
    item.y = p.y;
    addItem(level2, item);
  }
  const piles = rng.int(2, 4);
  for (let i = 0; i < piles && pi < points.length; i++) {
    const p = points[pi++];
    addItem(level2, createItem(game, "gold", { x: p.x, y: p.y, quantity: rng.roll(`${depth}d8+${3 + depth}`) }));
  }
}

// src/core/combat.ts
function hitChance(attacker, defender) {
  let def = defender.defense + statusDefense(defender);
  if (isIncapacitated(defender)) def -= 5;
  let acc = attacker.accuracy;
  if (hasStatus(attacker, "blind")) acc -= 4;
  if (hasStatus(defender, "invisible") && !attacker.isPlayer) def += 4;
  return Math.max(5, Math.min(95, 65 + (acc - def) * 5));
}
function meleeAttack(game, attacker, defender, opts = {}) {
  const sneak = attacker.isPlayer && game.hero.classId === "rogue" && !defender.isPlayer && defender.ai.state !== "hunting";
  emit(game, {
    type: "melee",
    x: attacker.x,
    y: attacker.y,
    tx: defender.x,
    ty: defender.y,
    style: meleeStyle(game, attacker),
    element: attacker.attacks[0]?.element,
    heavy: (opts.damageMult ?? 1) > 1 || sneak
  });
  for (const atk of attacker.attacks) {
    if (defender.hp <= 0) break;
    resolveAttack(game, attacker, defender, atk, (opts.damageMult ?? 1) * (sneak ? 3 : 1), sneak);
  }
  if (!defender.isPlayer && defender.hp > 0) {
    defender.ai.state = "hunting";
    defender.ai.lastSeen = { x: attacker.x, y: attacker.y };
  }
}
var VERB_STYLE = {
  morde: "bite",
  arranha: "claw",
  pica: "pierce",
  esmaga: "blunt",
  golpeia: "slash",
  acerta: "slash",
  soca: "fist"
};
var BLUNT_WEAPONS = /* @__PURE__ */ new Set(["club", "mace", "flail", "quarterstaff"]);
var PIERCE_WEAPONS = /* @__PURE__ */ new Set(["dagger", "rapier", "spear", "dart"]);
function meleeStyle(game, a) {
  if (a.isPlayer) {
    const w = equipped(game, "weapon");
    if (!w) return "fist";
    const b2 = itemBase(w.baseId);
    if (b2.category === "launcher" || BLUNT_WEAPONS.has(b2.id)) return "blunt";
    if (PIERCE_WEAPONS.has(b2.id)) return "pierce";
    return "slash";
  }
  const verb = a.attacks[0]?.verb ?? "";
  return VERB_STYLE[verb] ?? "touch";
}
function rangedAttack(game, attacker, defender, atk, missileName) {
  const rng = game.rng.combat;
  if (!rng.chance(hitChance(attacker, defender))) {
    emit(game, { type: "miss", x: defender.x, y: defender.y });
    message(game, `${capitalize(missileName)} erra ${theName(defender)}.`, "lightGray");
  } else {
    message(game, `${capitalize(missileName)} ${atk.verb} ${theName(defender)}.`, defender.isPlayer ? "lightRed" : "white");
    damage(game, defender, Math.max(1, rng.roll(atk.damage)), attacker);
  }
  if (!defender.isPlayer && defender.hp > 0) {
    defender.ai.state = "hunting";
    defender.ai.lastSeen = { x: attacker.x, y: attacker.y };
  }
}
function resolveAttack(game, attacker, defender, atk, mult = 1, sneak = false) {
  const rng = game.rng.combat;
  const a = theName(attacker);
  const d = theName(defender);
  if (!rng.chance(hitChance(attacker, defender))) {
    emit(game, { type: "miss", x: defender.x, y: defender.y });
    if (attacker.isPlayer) message(game, `Voc\xEA erra ${d}.`, "lightGray");
    else message(game, `${capitalize(a)} erra voc\xEA.`, "darkGray");
    return;
  }
  let dmg = Math.max(1, Math.round(rng.roll(atk.damage) * mult * resistMult(defender, atk.element)));
  const critChance = attacker.isPlayer ? game.hero.raceId === "halfling" ? 10 : 5 : 3;
  const crit = rng.chance(critChance);
  if (crit) {
    dmg *= 2;
    emit(game, { type: "crit", x: defender.x, y: defender.y });
    message(game, attacker.isPlayer ? "Golpe cr\xEDtico!" : "Um golpe cr\xEDtico!", attacker.isPlayer ? "gold" : "red");
  }
  let extra = "";
  let lifeSteal = 0;
  if (attacker.isPlayer) {
    const bon = collectBonuses(game);
    for (const br of bon.brands) {
      let bd = rng.roll(br.damage) * resistMult(defender, br.element);
      if (br.element === "holy" && hasFlag(defender, "undead")) bd *= 2;
      if (bd > 0) {
        dmg += Math.round(bd);
        extra = ` ${ELEMENT_WORD[br.element] ?? ""}`;
      }
    }
    lifeSteal = bon.lifeSteal;
  }
  if (attacker.isPlayer && sneak) message(game, `Ataque furtivo! Voc\xEA acerta ${d} em cheio.`, "yellow");
  else if (attacker.isPlayer) message(game, `Voc\xEA acerta ${d}${extra}.`, "white");
  else if (defender.isPlayer) message(game, `${capitalize(a)} ${atk.verb} voc\xEA.`, "lightRed");
  damage(game, defender, dmg, attacker);
  if (atk.effect && defender.hp > 0 && rng.chance(atk.effect.chance)) applyAttackEffect(game, attacker, defender, atk);
  if (attacker.flags.includes("lifeSteal")) lifeSteal = 30;
  if (lifeSteal > 0) {
    const heal = Math.max(1, Math.round(dmg * lifeSteal / 100));
    attacker.hp = Math.min(attacker.maxHp, attacker.hp + heal);
  }
}
function applyAttackEffect(game, attacker, defender, atk) {
  const eff = atk.effect;
  const rng = game.rng.combat;
  switch (eff.status) {
    case "drain":
      if (defender.isPlayer) drainLevel(game);
      return;
    case "steal":
      if (defender.isPlayer) stealFrom(game, attacker);
      return;
    default:
      addStatus(game, defender, eff.status, rng.roll(eff.duration ?? "1d4+2"), eff.status === "poisoned" ? Math.max(1, Math.floor(attacker.level / 5)) : 1);
  }
}
function drainLevel(game) {
  const h = game.hero;
  if (h.level <= 1) return;
  const lost = h.xp - xpForLevel(h.level - 1) + 1;
  h.drainedXp += lost;
  h.xp = xpForLevel(h.level - 1);
  h.level--;
  h.hpRolls.pop();
  recalcPlayer(game);
  message(game, `Voc\xEA sente sua for\xE7a vital se esvair... (n\xEDvel ${h.level})`, "lightRed");
}
function stealFrom(game, thief) {
  const loose = game.hero.inventory.filter((i) => !isEquipped(game, i));
  if (!loose.length && game.hero.gold <= 0) return;
  if (loose.length) {
    const it = game.rng.combat.pick(loose);
    const taken = takeFromInventory(game, it, it.quantity);
    message(game, `${capitalize(theName(thief))} rouba ${itemName(game, taken)}!`, "lightRed");
    thief.loot = [...thief.loot ?? [], taken];
  } else {
    const gold = Math.min(game.hero.gold, game.rng.combat.int(10, 50) * game.depth);
    game.hero.gold -= gold;
    message(game, `${capitalize(theName(thief))} rouba ${gold} pe\xE7as de ouro!`, "lightRed");
  }
  teleportActor(game, thief);
  thief.ai.state = "fleeing";
  thief.ai.fleeUntil = game.turn + 40;
  recalcPlayer(game);
}
var ELEMENT_WORD = {
  fire: "(queima!)",
  cold: "(congela!)",
  lightning: "(eletrocuta!)",
  poison: "(envenena!)",
  holy: "(luz sagrada!)",
  acid: "(corr\xF3i!)"
};
function resistMult(target, element) {
  if (!element || element === "physical") return 1;
  const r = target.resist?.[element] ?? 0;
  return Math.max(0, 1 - r / 100);
}
function damage(game, target, amount, source) {
  target.hp -= amount;
  if (amount > 0 && hasStatus(target, "asleep")) removeStatus(game, target, "asleep");
  if (amount > 0 && !target.isPlayer && target.ai.state === "sleeping") target.ai.state = "hunting";
  emit(game, { type: "damage", x: target.x, y: target.y, amount, toPlayer: target.isPlayer });
  if (target.hp > 0) return;
  target.hp = 0;
  emit(game, { type: "death", x: target.x, y: target.y, isPlayer: target.isPlayer });
  if (target.isPlayer) {
    const cause = source ? `morto por ${aName(source)}` : "morto";
    if (game.party && memberFalls(game, target, cause)) return;
    game.over = { won: false, cause };
    message(game, "Voc\xEA morre...", "red");
    return;
  }
  killMonster(game, target, source);
}
function killMonster(game, monster, killer) {
  const lvl = level(game);
  lvl.actors = lvl.actors.filter((m2) => m2 !== monster);
  addItem(lvl, createCorpse(game, monster));
  if (monster.flags.includes("champion") || monster.flags.includes("boss")) {
    const loot = generateItem(game, game.rng.loot, game.depth + 2, ["weapon", "armor", "shield", "helm", "ring", "amulet", "launcher", "cloak", "boots"]);
    if (loot) {
      if (loot.rarity === "common") {
        loot.rarity = "magic";
        loot.identified = false;
      }
      addItem(lvl, { ...loot, x: monster.x, y: monster.y });
    }
  }
  for (const it of monster.loot ?? []) addItem(lvl, { ...it, x: monster.x, y: monster.y });
  if (monster.flags.includes("unique")) {
    emit(game, { type: "bossDeath", x: monster.x, y: monster.y });
    game.uniquesKilled.push(monster.templateId);
    message(game, `${monster.name} foi derrotado!`, "gold");
  }
  if (killer?.isPlayer) {
    message(game, `Voc\xEA mata ${theName(monster)}!`, "yellow");
    game.hero.kills++;
    gainXp(game, killXp(monster.xpValue, monster.level, game.hero.level));
  } else {
    message(game, `${capitalize(theName(monster))} morre.`, "lightGray");
  }
}

// src/gen/dungeon/rogue.ts
var COLS = 3;
var ROWS = 3;
function generateRogueLevel(rng, depth, width = MAP_W, height = MAP_H) {
  const map = createMap(width, height);
  const cells = [];
  for (let r = 0; r < ROWS; r++) {
    for (let c = 0; c < COLS; c++) {
      const x0 = 1 + Math.floor(c * (width - 2) / COLS);
      const x1 = 1 + Math.floor((c + 1) * (width - 2) / COLS);
      const y0 = 1 + Math.floor(r * (height - 2) / ROWS);
      const y1 = 1 + Math.floor((r + 1) * (height - 2) / ROWS);
      cells.push({ x0, y0, w: x1 - x0, h: y1 - y0 });
    }
  }
  const goneCount = rng.int(0, 2);
  const gone = new Set(rng.shuffle(cells.map((_, i) => i)).slice(0, goneCount));
  const litChance = Math.max(15, 90 - depth * 6);
  const rooms = cells.map((cell, i) => {
    if (gone.has(i)) {
      const p = { x: rng.int(cell.x0 + 2, cell.x0 + cell.w - 3), y: rng.int(cell.y0 + 1, cell.y0 + cell.h - 2) };
      return { x: p.x, y: p.y, w: 1, h: 1, lit: false, gone: true };
    }
    const w = rng.int(4, cell.w - 4);
    const h = rng.int(2, cell.h - 3);
    const x = rng.int(cell.x0 + 2, cell.x0 + cell.w - 2 - w);
    const y = rng.int(cell.y0 + 1, cell.y0 + cell.h - 2 - h);
    return { x, y, w, h, lit: rng.chance(litChance) };
  });
  for (const r of rooms) {
    if (r.gone) carveCorridorCell(map, r.x, r.y);
    else carveRoom(map, r);
  }
  const neighbors = (i) => {
    const c = i % COLS;
    const r = Math.floor(i / COLS);
    const out = [];
    if (c > 0) out.push(i - 1);
    if (c < COLS - 1) out.push(i + 1);
    if (r > 0) out.push(i - COLS);
    if (r < ROWS - 1) out.push(i + COLS);
    return out;
  };
  const connected = /* @__PURE__ */ new Set([rng.int(0, cells.length - 1)]);
  const edges = /* @__PURE__ */ new Set();
  const key = (a, b2) => a < b2 ? `${a}-${b2}` : `${b2}-${a}`;
  while (connected.size < cells.length) {
    const frontier = [];
    for (const a2 of connected) for (const b3 of neighbors(a2)) if (!connected.has(b3)) frontier.push([a2, b3]);
    const [a, b2] = rng.pick(frontier);
    connected.add(b2);
    edges.add(key(a, b2));
  }
  const extra = rng.int(1, 3);
  for (let n = 0; n < extra; n++) {
    const a = rng.int(0, cells.length - 1);
    const b2 = rng.pick(neighbors(a));
    edges.add(key(a, b2));
  }
  for (const e of edges) {
    const [a, b2] = e.split("-").map(Number);
    connectRooms(map, rng, rooms[a], rooms[b2], b2 - a === 1);
  }
  placeDoors(map, rng, rooms, depth);
  const { up, down } = placeStairs(map, rng, rooms);
  sealEdges(map);
  return { map, rooms, up, down };
}
function connectRooms(map, rng, a, b2, horizontal) {
  if (horizontal) {
    const da = a.gone ? { x: a.x, y: a.y } : { x: a.x + a.w, y: rng.int(a.y, a.y + a.h - 1) };
    const db = b2.gone ? { x: b2.x, y: b2.y } : { x: b2.x - 1, y: rng.int(b2.y, b2.y + b2.h - 1) };
    const midX = da.x + 1 <= db.x - 1 ? rng.int(da.x + 1, db.x - 1) : da.x;
    carveHLine(map, da.x, midX, da.y);
    carveVLine(map, da.y, db.y, midX);
    carveHLine(map, midX, db.x, db.y);
  } else {
    const da = a.gone ? { x: a.x, y: a.y } : { x: rng.int(a.x, a.x + a.w - 1), y: a.y + a.h };
    const db = b2.gone ? { x: b2.x, y: b2.y } : { x: rng.int(b2.x, b2.x + b2.w - 1), y: b2.y - 1 };
    const midY = da.y + 1 <= db.y - 1 ? rng.int(da.y + 1, db.y - 1) : da.y;
    carveVLine(map, da.y, midY, da.x);
    carveHLine(map, da.x, db.x, midY);
    carveVLine(map, midY, db.y, db.x);
  }
}

// src/gen/dungeon/bsp.ts
var MIN_W = 10;
var MIN_H = 7;
function generateBspLevel(rng, depth, width = MAP_W, height = MAP_H) {
  const map = createMap(width, height);
  const root = { rect: { x: 1, y: 1, w: width - 2, h: height - 2 } };
  split(rng, root, 0);
  const rooms = [];
  const litChance = Math.max(10, 75 - depth * 4);
  placeRooms(rng, root, rooms, litChance);
  for (const r of rooms) carveRoom(map, r);
  connect(rng, root, map);
  for (let i = 0; i < rng.int(0, 2); i++) {
    const a = rng.pick(rooms);
    const b2 = rng.pick(rooms);
    if (a !== b2) carveLCorridor(map, rng, randomPointInRoom(rng, a), randomPointInRoom(rng, b2));
  }
  placeDoors(map, rng, rooms, depth);
  const { up, down } = placeStairs(map, rng, rooms);
  sealEdges(map);
  return { map, rooms, up, down };
}
function split(rng, node, level2) {
  const { x, y, w, h } = node.rect;
  const canH = w >= MIN_W * 2;
  const canV = h >= MIN_H * 2;
  if (!canH && !canV || level2 > 2 && rng.chance(20)) return;
  const vertical = canH && canV ? w / h > 1.6 ? true : h / w > 1.2 ? false : rng.chance(50) : canH;
  if (vertical) {
    const cut = rng.int(MIN_W, w - MIN_W);
    node.left = { rect: { x, y, w: cut, h } };
    node.right = { rect: { x: x + cut, y, w: w - cut, h } };
  } else {
    const cut = rng.int(MIN_H, h - MIN_H);
    node.left = { rect: { x, y, w, h: cut } };
    node.right = { rect: { x, y: y + cut, w, h: h - cut } };
  }
  split(rng, node.left, level2 + 1);
  split(rng, node.right, level2 + 1);
}
function placeRooms(rng, node, rooms, litChance) {
  if (node.left && node.right) {
    placeRooms(rng, node.left, rooms, litChance);
    placeRooms(rng, node.right, rooms, litChance);
    return;
  }
  const { x, y, w, h } = node.rect;
  const rw = rng.int(Math.min(4, w - 4), w - 4);
  const rh = rng.int(Math.min(3, h - 4), h - 4);
  const rx = rng.int(x + 2, x + w - 2 - rw);
  const ry = rng.int(y + 2, y + h - 2 - rh);
  node.room = { x: rx, y: ry, w: rw, h: rh, lit: rng.chance(litChance) };
  rooms.push(node.room);
}
function anyRoom(rng, node) {
  if (node.room) return node.room;
  return rng.chance(50) ? anyRoom(rng, node.left) : anyRoom(rng, node.right);
}
function connect(rng, node, map) {
  if (!node.left || !node.right) return;
  connect(rng, node.left, map);
  connect(rng, node.right, map);
  const a = anyRoom(rng, node.left);
  const b2 = anyRoom(rng, node.right);
  carveLCorridor(map, rng, randomPointInRoom(rng, a), randomPointInRoom(rng, b2));
}

// src/gen/dungeon/caves.ts
function generateCaveLevel(rng, _depth, width = MAP_W, height = MAP_H) {
  for (let attempt = 0; attempt < 30; attempt++) {
    const map = createMap(width, height);
    for (let y = 1; y < height - 1; y++) {
      for (let x = 1; x < width - 1; x++) setTile(map, x, y, rng.chance(45) ? Tile.Wall : Tile.Floor);
    }
    for (let it = 0; it < 5; it++) step(map, it < 2);
    sealEdges(map);
    const region = largestRegion(map);
    if (region.length < 450) continue;
    const keep = new Set(region.map((p) => idx(map, p.x, p.y)));
    for (let i = 0; i < map.tiles.length; i++) if (map.tiles[i] === Tile.Floor && !keep.has(i)) map.tiles[i] = Tile.Wall;
    const up = rng.pick(region);
    const dist = bfsDistances(map, up);
    let down = up;
    for (const p of region) if (dist[idx(map, p.x, p.y)] > dist[idx(map, down.x, down.y)]) down = p;
    setTile(map, up.x, up.y, Tile.StairsUp);
    setTile(map, down.x, down.y, Tile.StairsDown);
    for (let i = 0; i < 15; i++) {
      const p = rng.pick(region);
      if (getTile(map, p.x, p.y) === Tile.Floor) setTile(map, p.x, p.y, Tile.Rubble);
    }
    return { map, rooms: [], up, down };
  }
  throw new Error("Falha ao gerar caverna");
}
function step(map, fillOpen) {
  const next = map.tiles.slice();
  for (let y = 1; y < map.height - 1; y++) {
    for (let x = 1; x < map.width - 1; x++) {
      let walls = getTile(map, x, y) === Tile.Wall ? 1 : 0;
      for (const d of DIRS8) if (getTile(map, x + d.x, y + d.y) === Tile.Wall) walls++;
      let walls2 = 0;
      if (fillOpen) {
        for (let dy = -2; dy <= 2; dy++) for (let dx = -2; dx <= 2; dx++) if (getTile(map, x + dx, y + dy) === Tile.Wall) walls2++;
      }
      const wall = walls >= 5 || fillOpen && walls2 <= 2;
      next[idx(map, x, y)] = wall ? Tile.Wall : Tile.Floor;
    }
  }
  map.tiles = next;
}
function largestRegion(map) {
  const seen = new Uint8Array(map.tiles.length);
  let best = [];
  for (let y = 1; y < map.height - 1; y++) {
    for (let x = 1; x < map.width - 1; x++) {
      const i = idx(map, x, y);
      if (seen[i] || map.tiles[i] !== Tile.Floor) continue;
      const region = [];
      const stack = [{ x, y }];
      seen[i] = 1;
      while (stack.length) {
        const p = stack.pop();
        region.push(p);
        for (const d of DIRS4) {
          const nx = p.x + d.x;
          const ny = p.y + d.y;
          const j = idx(map, nx, ny);
          if (!seen[j] && map.tiles[j] === Tile.Floor) {
            seen[j] = 1;
            stack.push({ x: nx, y: ny });
          }
        }
      }
      if (region.length > best.length) best = region;
    }
  }
  return best;
}

// src/data/themes.ts
var THEMES = [
  {
    id: "crypt",
    name: "Cripta Superior",
    depths: [1, 4],
    wall: "lightGray",
    floor: "lightGray",
    generators: [{ item: "rogue", weight: 70 }, { item: "bsp", weight: 30 }]
  },
  {
    id: "mines",
    name: "Minas Abandonadas",
    depths: [5, 8],
    wall: "brown",
    floor: "lightGray",
    generators: [{ item: "bsp", weight: 45 }, { item: "rogue", weight: 20 }, { item: "caves", weight: 35 }]
  },
  {
    id: "fungal",
    name: "Cavernas F\xFAngicas",
    depths: [9, 12],
    wall: "green",
    floor: "green",
    generators: [{ item: "caves", weight: 60 }, { item: "bsp", weight: 40 }]
  },
  {
    id: "fortress",
    name: "Fortaleza Afundada",
    depths: [13, 16],
    wall: "lightBlue",
    floor: "lightGray",
    generators: [{ item: "bsp", weight: 70 }, { item: "rogue", weight: 30 }]
  },
  {
    id: "abyss",
    name: "O Abismo",
    depths: [17, 20],
    wall: "red",
    floor: "lightGray",
    generators: [{ item: "caves", weight: 50 }, { item: "bsp", weight: 50 }]
  }
];
function themeForDepth(depth) {
  return THEMES.find((t) => depth >= t.depths[0] && depth <= t.depths[1]) ?? THEMES[THEMES.length - 1];
}
function themeById(id) {
  return THEMES.find((t) => t.id === id) ?? THEMES[0];
}
var MAX_DEPTH = 20;

// src/gen/dungeon/index.ts
function ensureOpenPath(level2) {
  const { map } = level2;
  const secret = map.tiles.map((t, i) => t === Tile.SecretDoor ? i : -1).filter((i) => i >= 0);
  if (!secret.length) return;
  for (const i of secret) map.tiles[i] = Tile.Wall;
  const reachable = bfsDistances(map, level2.up)[idx(map, level2.down.x, level2.down.y)] >= 0;
  for (const i of secret) map.tiles[i] = reachable ? Tile.SecretDoor : Tile.DoorClosed;
}
var GENERATORS = {
  rogue: generateRogueLevel,
  bsp: generateBspLevel,
  caves: generateCaveLevel
};
function generateDungeon(rng, depth, forced) {
  const generator = forced ?? rng.weighted(themeForDepth(depth).generators);
  for (let attempt = 0; attempt < 20; attempt++) {
    const level2 = GENERATORS[generator](rng, depth);
    if (!isFullyConnected(level2.map, level2.up)) continue;
    ensureOpenPath(level2);
    return { ...level2, generator };
  }
  throw new Error(`N\xE3o foi poss\xEDvel gerar um andar conectado (${generator})`);
}

// src/gen/boss.ts
function freeCellsAround(level2, center, maxR) {
  const out = [];
  for (let r = 1; r <= maxR; r++) {
    for (let y = center.y - r; y <= center.y + r; y++) {
      for (let x = center.x - r; x <= center.x + r; x++) {
        if (distance({ x, y }, center) !== r) continue;
        if (!isWalkable(level2.map, x, y)) continue;
        if (level2.actors.some((a) => a.x === x && a.y === y)) continue;
        out.push({ x, y });
      }
    }
  }
  return out;
}
function placeBoss(game, level2, rng, depth) {
  const boss = bossForDepth(depth);
  if (!boss || game.uniquesKilled.includes(boss.id)) return;
  const home = level2.down;
  if (depth === MAX_DEPTH) {
    setTile(level2.map, home.x, home.y, Tile.Floor);
    addItem(level2, createItem(game, "amulet_abyss", { x: home.x, y: home.y }));
  }
  level2.actors = level2.actors.filter((a) => distance(a, home) > 4);
  const spots = freeCellsAround(level2, home, 4);
  if (!spots.length) return;
  const b2 = createMonster(game, boss, spots[0].x, spots[0].y, rng);
  b2.ai.state = "sleeping";
  level2.actors.push(b2);
  let i = 1;
  for (const e of boss.escort) {
    const n = rng.int(e.count[0], e.count[1]);
    for (let k = 0; k < n && i < spots.length; k++, i++) {
      const m2 = createMonster(game, monsterTemplate(e.id), spots[i].x, spots[i].y, rng);
      m2.ai.state = "sleeping";
      level2.actors.push(m2);
    }
  }
}

// src/core/traps.ts
var TRAP_INFO = {
  dart: { name: "armadilha de dardos", color: "lightGray", minDepth: 1, weight: 10 },
  pit: { name: "fosso", color: "brown", minDepth: 1, weight: 8 },
  alarm: { name: "armadilha de alarme", color: "yellow", minDepth: 1, weight: 5 },
  sleep: { name: "armadilha de g\xE1s son\xEDfero", color: "lightBlue", minDepth: 2, weight: 5 },
  teleport: { name: "runa de teleporte", color: "lightMagenta", minDepth: 3, weight: 5 },
  trapdoor: { name: "al\xE7ap\xE3o", color: "darkGray", minDepth: 2, weight: 4 },
  fire: { name: "runa de fogo", color: "orange", minDepth: 5, weight: 5 }
};
function trapAt(game, x, y) {
  return (level(game).traps ?? []).find((t) => t.x === x && t.y === y);
}
function triggerTrap(game, trap) {
  const p = game.player;
  const info = TRAP_INFO[trap.kind];
  const wasHidden = trap.hidden;
  trap.hidden = false;
  const dodge = (wasHidden ? 10 : 40) + statMod(game.hero.stats.dex) * 5 + (game.hero.raceId === "halfling" ? 15 : 0);
  if (game.rng.loot.chance(dodge)) {
    message(game, `Voc\xEA escapa de ${info.name}!`, "lightGray");
    return;
  }
  message(game, wasHidden ? `Uma armadilha! Voc\xEA ativa ${info.name}.` : `Voc\xEA ativa ${info.name}.`, "orange");
  switch (trap.kind) {
    case "dart":
      damage(game, p, game.rng.loot.roll("1d4+1"));
      if (game.rng.loot.chance(40)) addStatus(game, p, "poisoned", 6, 1);
      break;
    case "pit":
      message(game, "Voc\xEA cai num fosso!", "orange");
      damage(game, p, game.rng.loot.roll("2d4"));
      break;
    case "alarm":
      message(game, "Um sino ensurdecedor toca! Todos os monstros acordam.", "yellow");
      for (const m2 of level(game).actors) {
        m2.ai.state = "hunting";
        m2.ai.lastSeen = { x: p.x, y: p.y };
      }
      break;
    case "sleep":
      addStatus(game, p, "asleep", game.rng.loot.roll("1d4+2"));
      break;
    case "teleport":
      teleportActor(game, p);
      message(game, "O mundo gira ao seu redor!", "lightMagenta");
      break;
    case "trapdoor":
      if (game.depth >= MAX_DEPTH) break;
      message(game, "O ch\xE3o se abre sob seus p\xE9s e voc\xEA cai!", "orange");
      game.pendingFall = true;
      break;
    case "fire": {
      emit(game, { type: "explosion", x: p.x, y: p.y, radius: 1, color: "orange", element: "fire" });
      damage(game, p, Math.round(game.rng.loot.roll("3d6") * resistMult(p, "fire")));
      addStatus(game, p, "burning", 3, 1);
      break;
    }
  }
}
function searchTraps(game, chance) {
  const p = game.player;
  for (const d of [{ x: 0, y: 0 }, ...DIRS8]) {
    const t = trapAt(game, p.x + d.x, p.y + d.y);
    if (t && t.hidden && game.rng.loot.chance(chance)) {
      t.hidden = false;
      message(game, `Voc\xEA encontra ${TRAP_INFO[t.kind].name}!`, "yellow");
    }
  }
}
function disarm(game, dx, dy) {
  const p = game.player;
  const t = trapAt(game, p.x + dx, p.y + dy);
  if (!t || t.hidden) {
    message(game, "Voc\xEA n\xE3o v\xEA nenhuma armadilha ali.", "darkGray");
    return 0;
  }
  const rogue = game.hero.classId === "rogue" ? 30 : 0;
  const chance = 40 + rogue + statMod(game.hero.stats.dex) * 6 + game.hero.level * 2;
  if (game.rng.loot.chance(chance)) {
    level(game).traps = (level(game).traps ?? []).filter((x) => x !== t);
    message(game, `Voc\xEA desarma ${TRAP_INFO[t.kind].name}.`, "lightGreen");
  } else if (game.rng.loot.chance(30)) {
    message(game, "Ops! Voc\xEA ativa a armadilha.", "orange");
    triggerTrap(game, { ...t, hidden: false });
  } else message(game, "Voc\xEA n\xE3o consegue desarmar a armadilha.", "lightGray");
  return ACTION_COST;
}

// src/gen/features.ts
function placeFeatures(level2, rng, depth) {
  const points = rng.shuffle(spawnPoints(level2, 4).filter((p) => getTile(level2.map, p.x, p.y) === Tile.Floor));
  let pi = 0;
  const next = () => points[pi++];
  const traps = [];
  const nTraps = rng.int(0, 2 + Math.floor(depth / 4));
  const kinds = Object.keys(TRAP_INFO).filter((k) => TRAP_INFO[k].minDepth <= depth);
  for (let i = 0; i < nTraps; i++) {
    const p = next();
    if (!p || distance(p, level2.down) < 2) continue;
    traps.push({ x: p.x, y: p.y, kind: rng.weighted(kinds.map((k) => ({ item: k, weight: TRAP_INFO[k].weight }))), hidden: true });
  }
  level2.traps = traps;
  if (rng.chance(35)) {
    const p = next();
    if (p) setTile(level2.map, p.x, p.y, Tile.Fountain);
  }
  if (rng.chance(12)) {
    const p = next();
    if (p) setTile(level2.map, p.x, p.y, Tile.Altar);
  }
  const liquid = depth >= 17 && rng.chance(60) ? Tile.Lava : Tile.Water;
  if (rng.chance(depth >= 9 ? 55 : 25)) {
    const start = next();
    if (start) growPool(level2, rng, start, liquid, rng.int(5, 16));
  }
}
function growPool(level2, rng, start, tile, size) {
  const map = level2.map;
  const cells = [start];
  for (let n = 0; n < size && cells.length; n++) {
    const c = cells.splice(rng.int(0, cells.length - 1), 1)[0];
    if (getTile(map, c.x, c.y) !== Tile.Floor) continue;
    if (distance(c, level2.up) <= 1 || distance(c, level2.down) <= 1) continue;
    const i = idx(map, c.x, c.y);
    const before = map.tiles[i];
    map.tiles[i] = tile;
    if (tile === Tile.Lava) {
      const old = map.tiles.slice();
      for (let k = 0; k < map.tiles.length; k++) if (map.tiles[k] === Tile.Lava) map.tiles[k] = Tile.Wall;
      const ok = bfsDistances(map, level2.up)[idx(map, level2.down.x, level2.down.y)] >= 0;
      map.tiles = old;
      if (!ok) {
        map.tiles[i] = before;
        continue;
      }
    }
    for (const d of DIRS8) cells.push({ x: c.x + d.x, y: c.y + d.y });
  }
}

// src/gen/vaults.ts
var VAULTS = [
  { id: "treasury", name: "tesouraria", minDepth: 3, weight: 4, lines: [
    "#########",
    "#$*.M.*$#",
    "#.#####.#",
    "#*#$*$#*#",
    "#.##S##.#",
    "#...M...#",
    "####S####"
  ] },
  { id: "library", name: "biblioteca", minDepth: 2, weight: 4, lines: [
    "###########",
    "#B.B.B.B.B#",
    "#.........#",
    "#B.B.M.B.B#",
    "#####+#####"
  ] },
  { id: "shrine", name: "santu\xE1rio", minDepth: 1, weight: 4, lines: [
    "#########",
    "#~~...~~#",
    "#~..{..~#",
    "+..._...+",
    "#~.....~#",
    "#~~.*.~~#",
    "#########"
  ] },
  { id: "nest", name: "ninho de monstros", minDepth: 4, weight: 3, lines: [
    "###########",
    "#M.M.M.M.*#",
    "#.M.M.M.M.#",
    "#*.M.M.M.$#",
    "#####L#####"
  ] },
  { id: "garden", name: "jardim f\xFAngico", minDepth: 6, weight: 2, lines: [
    "#########",
    "#&.&!&.&#",
    "#.&.*.&.#",
    "+..&M&..+",
    "#.&.!.&.#",
    "#&.&.&.&#",
    "#########"
  ] },
  { id: "armory", name: "arsenal", minDepth: 5, weight: 3, lines: [
    "#########",
    "#*.*.*.*#",
    "#.......#",
    "#M.....M#",
    "####+####"
  ] }
];
function placeVault(game, level2, rng, depth) {
  const pool = VAULTS.filter((v2) => v2.minDepth <= depth);
  if (!pool.length) return null;
  const v = rng.weighted(pool.map((x) => ({ item: x, weight: x.weight })));
  const h = v.lines.length;
  const w = Math.max(...v.lines.map((l) => l.length));
  const map = level2.map;
  for (let attempt = 0; attempt < 80; attempt++) {
    const ox = rng.int(1, map.width - w - 2);
    const oy = rng.int(1, map.height - h - 2);
    let solid = true;
    for (let y = oy - 1; y <= oy + h && solid; y++) for (let x = ox - 1; x <= ox + w && solid; x++) if (!inBounds(map, x, y) || getTile(map, x, y) !== Tile.Wall) solid = false;
    if (!solid) continue;
    const doors = [];
    v.lines.forEach((line, y) => {
      [...line].forEach((ch, x) => {
        const px = ox + x;
        const py = oy + y;
        const tile = { "#": Tile.Wall, ".": Tile.Floor, "+": Tile.DoorClosed, S: Tile.SecretDoor, L: Tile.DoorLocked, "{": Tile.Fountain, _: Tile.Altar, "~": Tile.Water, "&": Tile.Fungus }[ch] ?? Tile.Floor;
        setTile(map, px, py, tile);
        if (ch === "+" || ch === "S" || ch === "L") doors.push({ x: px, y: py });
        const at = { x: px, y: py };
        if (ch === "$") addItem(level2, createItem(game, "gold", { ...at, quantity: rng.roll(`${depth + 2}d10`) }));
        if (ch === "*") {
          const it = generateItem(game, rng, depth + 2, ["weapon", "armor", "shield", "ring", "amulet", "wand", "launcher", "helm", "boots", "cloak"]);
          if (it) addItem(level2, { ...it, ...at });
        }
        if (ch === "B") {
          const it = generateItem(game, rng, depth + 1, rng.chance(40) ? ["book"] : ["scroll"]);
          if (it) addItem(level2, { ...it, ...at });
        }
        if (ch === "!") {
          const it = generateItem(game, rng, depth + 1, ["potion"]);
          if (it) addItem(level2, { ...it, ...at });
        }
        if (ch === "M") {
          const m2 = createMonster(game, rng.pick(monstersForDepth(depth + 1)), px, py, rng);
          m2.ai.state = "sleeping";
          level2.actors.push(m2);
        }
      });
    });
    for (const d of doors) connectToLevel(level2, d, { x: ox, y: oy, w, h });
    for (const d of doors) if (getTile(map, d.x, d.y) === Tile.DoorLocked) setTile(map, d.x, d.y, Tile.DoorClosed);
    return v.name;
  }
  return null;
}
function connectToLevel(level2, door, box) {
  const map = level2.map;
  const inside = (x, y) => x >= box.x && x < box.x + box.w && y >= box.y && y < box.y + box.h;
  const prev = /* @__PURE__ */ new Map();
  const start = idx(map, door.x, door.y);
  const queue = [start];
  prev.set(start, -1);
  let found = -1;
  for (let head = 0; head < queue.length && found < 0; head++) {
    const cur = queue[head];
    const cx = cur % map.width;
    const cy = Math.floor(cur / map.width);
    for (const d of DIRS4) {
      const nx = cx + d.x;
      const ny = cy + d.y;
      if (nx <= 0 || ny <= 0 || nx >= map.width - 1 || ny >= map.height - 1 || inside(nx, ny)) continue;
      const ni = idx(map, nx, ny);
      if (prev.has(ni)) continue;
      prev.set(ni, cur);
      if (isPassableForGen(map.tiles[ni])) {
        found = ni;
        break;
      }
      queue.push(ni);
    }
  }
  for (let c = prev.get(found) ?? -1; c >= 0 && c !== start; c = prev.get(c) ?? -1) {
    if (map.tiles[c] === Tile.Wall) map.tiles[c] = Tile.Corridor;
  }
}

// src/gen/level.ts
function levelRng(seed, depth) {
  return new RNG(seed).fork(`level-${depth}`);
}
function buildLevel(game, depth) {
  const rng = levelRng(game.seed, depth);
  const gen = generateDungeon(rng, depth);
  const level2 = {
    depth,
    map: gen.map,
    actors: [],
    items: [],
    up: gen.up,
    down: gen.down,
    rooms: gen.rooms,
    theme: themeForDepth(depth).id,
    generator: gen.generator,
    visited: false
  };
  spawnMonsters(game, level2, rng, depth);
  placeFeatures(level2, rng, depth);
  if (depth >= 2 && rng.chance(30)) level2.vault = placeVault(game, level2, rng, depth) ?? void 0;
  spawnItems(game, level2, rng, depth);
  placeBoss(game, level2, rng, depth);
  return level2;
}

// src/core/world.ts
var DEFAULT_HERO = { name: "Aventureiro", raceId: "human", classId: "warrior" };
function createGame(seed, spec = DEFAULT_HERO) {
  const game = {
    seed,
    turn: 0,
    depth: 1,
    maxDepth: 1,
    levels: {},
    player: createActor(1, { templateId: "player", name: "voc\xEA", glyph: "@", color: "white", isPlayer: true, energy: 100 }),
    hero: createHero(spec.name, spec.raceId, spec.classId, spec.rollSeed !== void 0 ? new RNG(spec.rollSeed) : void 0),
    log: [],
    events: [],
    uniquesKilled: [],
    artifactsFound: [],
    idState: createIdState(seed),
    hasAmulet: false,
    rng: createRngs(seed),
    nextId: 2
  };
  giveStartingKit(game);
  for (const it of game.hero.inventory) learn(game, it.baseId);
  recalcPlayer(game);
  game.player.hp = game.player.maxHp;
  game.player.mp = game.player.maxMp;
  enterLevel(game, 1, "up");
  game.events = [];
  message(game, "Voc\xEA desce para o Abismo. Encontre o caminho para baixo...", "yellow");
  return game;
}
function giveStartingKit(game) {
  const added = [];
  for (const id of classById(game.hero.classId).startingItems) {
    const base = itemBase(id);
    const item = addToInventory(game, createItem(game, id, { quantity: base.category === "ammo" ? 40 : 1 }));
    if (item && !added.includes(item)) added.push(item);
  }
  for (const item of added) {
    const slot = CATEGORY_SLOT[itemBase(item.baseId).category];
    if (slot && equipped(game, slot) === void 0) {
      if (slot === "offhand" && equipped(game, "weapon") && itemBase(equipped(game, "weapon").baseId).twoHanded) continue;
      equip(game, item, true);
    }
  }
}
function enterLevel(game, depth, arrive) {
  const previousTheme = game.levels[game.depth]?.theme;
  if (!game.levels[depth]) game.levels[depth] = buildLevel(game, depth);
  game.depth = depth;
  const lvl = level(game);
  const p = arrive === "up" ? lvl.up : lvl.down;
  let spot = p;
  if (lvl.actors.some((a) => a.x === p.x && a.y === p.y)) {
    const d = DIRS8.find((d2) => isWalkable(lvl.map, p.x + d2.x, p.y + d2.y) && !lvl.actors.some((a) => a.x === p.x + d2.x && a.y === p.y + d2.y));
    if (d) spot = { x: p.x + d.x, y: p.y + d.y };
  }
  game.player.x = spot.x;
  game.player.y = spot.y;
  const firstVisit = !lvl.visited;
  lvl.visited = true;
  const deeper = depth > game.maxDepth;
  if (deeper) game.maxDepth = depth;
  refreshFov(game);
  emit(game, { type: "stairs" });
  if (previousTheme !== void 0) {
    const theme = themeById(lvl.theme);
    message(game, `Voc\xEA ${arrive === "up" ? "desce" : "sobe"} para o andar ${depth}.`, "white");
    if (firstVisit && theme.id !== previousTheme) message(game, `\u2014 ${theme.name} \u2014`, themeForDepth(depth).wall);
    const boss = bossForDepth(depth);
    if (firstVisit && boss && !game.uniquesKilled.includes(boss.id)) message(game, boss.intro, "lightRed");
  }
  if (deeper) gainXp(game, 5 * depth);
  if (game.party) partyArrives(game, game.player);
}

// src/core/ranged.ts
var THROW_RANGE = 8;
function projectileGlyph(dx, dy) {
  const ax = Math.abs(dx);
  const ay = Math.abs(dy);
  if (ay * 2 < ax) return "-";
  if (ax * 2 < ay) return "|";
  return Math.sign(dx) === Math.sign(dy) ? "\\" : "/";
}
function traceProjectile(game, from, to, range) {
  const map = level(game).map;
  const path = [];
  for (const p of bresenham(from.x, from.y, to.x, to.y).slice(1, range + 1)) {
    if (!isTransparent(map, p.x, p.y)) break;
    path.push(p);
    const other = actorAt(game, p.x, p.y);
    if (other) return { path, hit: other };
  }
  return { path };
}
function resolveShot(game, actor, target, shot) {
  const { path, hit } = traceProjectile(game, actor, target, shot.range);
  const base = itemBase(shot.item.baseId);
  const glyph = base.category === "potion" ? "!" : projectileGlyph(target.x - actor.x, target.y - actor.y);
  emit(game, { type: "projectile", path, glyph, color: itemColor(shot.item, game), item: base.id, from: { x: actor.x, y: actor.y }, look: lookOf(game, base.id) });
  const missile = itemName(game, { ...shot.item, quantity: 1 }, "the");
  let broke = false;
  if (hit) {
    const chance = Math.max(5, Math.min(95, hitChance(actor, hit) + shot.accuracyBonus * 5));
    if (game.rng.combat.chance(chance)) {
      message(game, `${capitalize(missile)} acerta ${theName(hit)}.`, hit.isPlayer ? "lightRed" : "white");
      damage(game, hit, Math.max(1, shot.damage), actor);
      broke = game.rng.combat.chance(shot.breakChance);
    } else {
      emit(game, { type: "miss", x: hit.x, y: hit.y });
      message(game, `${capitalize(missile)} erra ${theName(hit)}.`, "lightGray");
    }
    if (!hit.isPlayer && hit.hp > 0) {
      hit.ai.state = "hunting";
      hit.ai.lastSeen = { x: actor.x, y: actor.y };
    }
  }
  if (base.category === "potion") {
    message(game, `${capitalize(missile)} se espatifa!`, "lightGray");
    const at = hit ?? path[path.length - 1] ?? { x: actor.x, y: actor.y };
    emit(game, { type: "shatter", x: at.x, y: at.y, color: itemColor(shot.item, game) });
    if (hit && hit.hp > 0 && base.effect) potionEffect(game, hit, base.effect);
    return;
  }
  if (broke) return;
  const land = path[path.length - 1] ?? { x: actor.x, y: actor.y };
  const spot = isWalkable(level(game).map, land.x, land.y) ? land : { x: actor.x, y: actor.y };
  addItem(level(game), { ...shot.item, quantity: 1, x: spot.x, y: spot.y, letter: void 0, id: game.nextId++ });
}
function throwItem(game, actor, item, target) {
  if (target.x === actor.x && target.y === actor.y) return 0;
  const base = itemBase(item.baseId);
  const one = takeFromInventory(game, item, 1);
  const strMod = statMod(game.hero.stats.str);
  const dmg = base.throwDamage ? game.rng.combat.roll(base.throwDamage) + one.enchant + Math.max(0, strMod) : game.rng.combat.roll("1d2");
  message(game, `Voc\xEA arremessa ${itemName(game, one)}.`, "lightGray");
  resolveShot(game, actor, target, { item: one, damage: dmg, accuracyBonus: base.throwDamage ? 1 + one.enchant : -2, range: THROW_RANGE, breakChance: 10 });
  return ACTION_COST;
}
function readyAmmo(game) {
  const launcher = equipped(game, "weapon");
  const lb = launcher ? itemBase(launcher.baseId) : void 0;
  if (!launcher || !lb || lb.category !== "launcher") return { problem: "Voc\xEA n\xE3o est\xE1 empunhando uma arma de disparo." };
  const ammo = equipped(game, "quiver");
  if (!ammo) return { launcher, problem: "Sua aljava est\xE1 vazia (Q escolhe a muni\xE7\xE3o)." };
  if (itemBase(ammo.baseId).ammoKind !== lb.ammoType) return { launcher, problem: "Essa muni\xE7\xE3o n\xE3o serve nesta arma." };
  return { launcher, ammo };
}
function fire(game, actor, target) {
  const { launcher, ammo, problem } = readyAmmo(game);
  if (problem || !launcher || !ammo) {
    message(game, problem ?? "Voc\xEA n\xE3o pode disparar.", "darkGray");
    return 0;
  }
  if (target.x === actor.x && target.y === actor.y) return 0;
  const lb = itemBase(launcher.baseId);
  const ab = itemBase(ammo.baseId);
  const one = takeFromInventory(game, ammo, 1);
  const mult = lb.multiplier ?? 2;
  const dmg = (game.rng.combat.roll(ab.damage ?? "1d4") + one.enchant + launcher.enchant) * mult;
  const archery = game.hero.classId === "ranger" ? 3 : 0;
  const dexMod = statMod(game.hero.stats.dex);
  resolveShot(game, actor, target, {
    item: one,
    damage: dmg,
    accuracyBonus: archery + dexMod - statMod(game.hero.stats.str) + launcher.enchant,
    range: lb.range ?? 10,
    breakChance: 30
  });
  return ACTION_COST;
}

// src/core/abilities.ts
var ABILITY_RULES = {
  power_strike: { cooldown: 0, needsDirection: true },
  whirlwind: { cooldown: 6 },
  second_wind: { cooldown: 200 },
  vanish: { cooldown: 60 },
  turn_undead: { cooldown: 15, mp: 2 },
  track: { cooldown: 80 },
  double_shot: { cooldown: 5, needsTarget: true }
};
function abilityReadyIn(game, id) {
  return Math.max(0, (game.hero.cooldowns[id] ?? 0) - game.turn);
}
function useAbility(game, id, dx = 0, dy = 0) {
  const rule = ABILITY_RULES[id];
  const p = game.player;
  if (!rule) return 0;
  const wait = abilityReadyIn(game, id);
  if (wait > 0) {
    message(game, `Ainda n\xE3o: faltam ${wait} turnos.`, "darkGray");
    return 0;
  }
  if (rule.mp && p.mp < rule.mp) {
    message(game, "Voc\xEA n\xE3o tem mana suficiente.", "lightBlue");
    return 0;
  }
  const cost = run(game, p, id, dx, dy);
  if (cost > 0) {
    if (rule.mp) p.mp -= rule.mp;
    if (rule.cooldown) game.hero.cooldowns[id] = game.turn + rule.cooldown;
  }
  return cost;
}
function run(game, p, id, dx, dy) {
  const lvl = level(game);
  switch (id) {
    case "power_strike": {
      const target = actorAt(game, p.x + dx, p.y + dy);
      if (!target || target === p) {
        message(game, "N\xE3o h\xE1 ningu\xE9m ali.", "darkGray");
        return 0;
      }
      message(game, "Voc\xEA desfere um golpe poderoso!", "orange");
      meleeAttack(game, p, target, { damageMult: 2 });
      return ACTION_COST * 2;
    }
    case "whirlwind": {
      const around = DIRS8.map((d) => actorAt(game, p.x + d.x, p.y + d.y)).filter((a) => !!a && !a.isPlayer);
      if (!around.length) {
        message(game, "N\xE3o h\xE1 inimigos ao seu redor.", "darkGray");
        return 0;
      }
      message(game, "Voc\xEA gira a arma num ataque girat\xF3rio!", "orange");
      emit(game, { type: "whirl", x: p.x, y: p.y });
      for (const a of around) meleeAttack(game, p, a);
      return ACTION_COST;
    }
    case "second_wind": {
      const heal = Math.round(p.maxHp * 0.3);
      p.hp = Math.min(p.maxHp, p.hp + heal);
      emit(game, { type: "heal", x: p.x, y: p.y });
      message(game, `Voc\xEA recupera o f\xF4lego (+${heal} HP).`, "lightGreen");
      return ACTION_COST;
    }
    case "vanish": {
      for (const m2 of lvl.actors) {
        if (m2.ai.state === "hunting") {
          m2.ai.state = "wandering";
          m2.ai.lastSeen = void 0;
        }
      }
      game.hero.cooldowns.hidden = game.turn + 8;
      emit(game, { type: "smoke", x: p.x, y: p.y });
      message(game, "Voc\xEA some nas sombras. Os inimigos perdem seu rastro.", "darkGray");
      return ACTION_COST;
    }
    case "turn_undead": {
      const undead = lvl.actors.filter((m2) => hasFlag(m2, "undead") && distance(m2, p) <= 6);
      message(game, "Voc\xEA ergue o s\xEDmbolo sagrado e invoca a luz divina!", "white");
      emit(game, { type: "explosion", x: p.x, y: p.y, radius: 3, color: "white", element: "holy" });
      if (!undead.length) message(game, "Nada acontece.", "darkGray");
      for (const m2 of undead) {
        const dmg = game.rng.combat.roll("2d6") + p.level;
        message(game, `${capitalize(theName(m2))} se contorce sob a luz!`, "yellow");
        damage(game, m2, dmg, p);
        if (m2.hp > 0) {
          m2.ai.state = "fleeing";
          m2.ai.fleeUntil = game.turn + 10 + p.level;
        }
      }
      return ACTION_COST;
    }
    case "double_shot": {
      const target = { x: dx, y: dy };
      if (readyAmmo(game).problem) {
        message(game, readyAmmo(game).problem, "darkGray");
        return 0;
      }
      message(game, "Voc\xEA dispara duas flechas de uma vez!", "yellow");
      fire(game, p, target);
      if (!readyAmmo(game).problem) fire(game, p, target);
      return ACTION_COST;
    }
    case "track": {
      game.hero.cooldowns.tracking = game.turn + 25;
      message(game, `Voc\xEA estuda rastros e sons... sente ${lvl.actors.length} criatura(s) neste andar.`, "lightGreen");
      return ACTION_COST;
    }
  }
  return 0;
}
function playerHidden(game) {
  return (game.hero.cooldowns.hidden ?? 0) > game.turn;
}

// src/core/monsterSpecial.ts
function chooseSpell(game, m2) {
  const rng = game.rng.ai;
  if (m2.hp < m2.maxHp / 2 && rng.chance(50)) return spellById("cure_light");
  if (rng.chance(20)) return spellById(m2.level >= 8 ? "word_of_fear" : "sleep") ?? spellById("sleep");
  if (m2.level >= 16) return spellById(rng.chance(50) ? "fireball" : "lightning");
  if (m2.level >= 9) return spellById("frost_bolt");
  return spellById("magic_missile");
}
function monsterSpecial(game, m2, kind) {
  const p = game.player;
  const who = capitalize(theName(m2));
  switch (kind) {
    case "breath": {
      const el = hasFlag(m2, "breathLightning") ? "lightning" : "fire";
      const map = level(game).map;
      const path = [];
      for (const pt of bresenham(m2.x, m2.y, p.x, p.y).slice(1)) {
        path.push(pt);
        if (!isTransparent(map, pt.x, pt.y) || pt.x === p.x && pt.y === p.y) break;
      }
      emit(game, { type: "breath", path, from: { x: m2.x, y: m2.y }, element: el });
      message(game, `${who} ${el === "fire" ? "cospe uma torrente de fogo" : "solta um rel\xE2mpago pela boca"}!`, "lightRed");
      const dmg = Math.round(Math.max(6, m2.hp / 4) * resistMult(p, el));
      message(game, `Voc\xEA \xE9 atingido pelo sopro (${dmg}).`, "lightRed");
      damage(game, p, dmg, m2);
      m2.specialReady = game.turn + 6;
      return ACTION_COST;
    }
    case "cast": {
      const spell = chooseSpell(game, m2);
      if (!spell) return 0;
      message(game, `${who} conjura ${spell.name}!`, spell.color);
      invokeEffect(game, m2, spell, spell.shape === "self" ? void 0 : { x: p.x, y: p.y });
      m2.specialReady = game.turn + 3;
      return ACTION_COST;
    }
    case "shoot": {
      const { path, hit } = traceProjectile(game, m2, p, 10);
      emit(game, { type: "projectile", path, glyph: projectileGlyph(p.x - m2.x, p.y - m2.y), color: "lightGray", item: "bolt", from: { x: m2.x, y: m2.y } });
      if (hit) rangedAttack(game, m2, hit, { verb: "acerta", damage: `1d6+${Math.floor(m2.level / 2)}` }, "o virote");
      else message(game, `${who} dispara, mas erra feio.`, "darkGray");
      return ACTION_COST;
    }
  }
}

// src/core/actions.ts
function perform(game, actor, action) {
  switch (action.type) {
    case "move":
      return doMove(game, actor, action.dx, action.dy);
    case "attack": {
      const target = actorAt(game, actor.x + action.dx, actor.y + action.dy);
      if (!target || target === actor) return 0;
      if (actor.isPlayer && target.isPlayer) return 0;
      meleeAttack(game, actor, target);
      return ACTION_COST;
    }
    case "wait":
      return ACTION_COST;
    case "raiseStat":
      if (actor.isPlayer) raiseStat(game, action.stat);
      return 0;
    case "cast":
      return castSpell(game, actor, action.spellId, action.tx !== void 0 ? { x: action.tx, y: action.ty } : void 0);
    case "ability":
      return actor.isPlayer ? useAbility(game, action.abilityId, action.dx, action.dy) : 0;
    case "descend":
      return doStairs(game, actor, "down");
    case "ascend":
      return doStairs(game, actor, "up");
    case "fire":
      return actor.isPlayer ? fire(game, actor, { x: action.tx, y: action.ty }) : 0;
    case "search":
      return actor.isPlayer ? doSearch(game) : 0;
    case "special":
      return actor.isPlayer ? 0 : monsterSpecial(game, actor, action.kind);
    case "fountain":
      return actor.isPlayer ? drinkFountain(game) : 0;
    case "disarm":
      return actor.isPlayer ? disarm(game, action.dx, action.dy) : 0;
    case "invoke":
      if (!actor.isPlayer || !game.hasAmulet) {
        message(game, "Voc\xEA n\xE3o tem nada para invocar.", "darkGray");
        return 0;
      }
      message(game, "O Cora\xE7\xE3o do Abismo brilha e o mundo se dobra ao seu redor...", "lightMagenta");
      game.over = { won: true, escaped: false, cause: "venceu: invocou o Cora\xE7\xE3o do Abismo" };
      return ACTION_COST;
  }
  if (!actor.isPlayer) return 0;
  return performItemAction(game, action);
}
function findItem(game, id) {
  return game.hero.inventory.find((i) => i.id === id);
}
function performItemAction(game, action) {
  switch (action.type) {
    case "pickup": {
      const here = itemsAt(level(game), game.player.x, game.player.y);
      const item = action.itemId !== void 0 ? here.find((i) => i.id === action.itemId) : here[0];
      if (!item) {
        message(game, "N\xE3o h\xE1 nada aqui para pegar.", "darkGray");
        return 0;
      }
      if (!pickUp(game, item)) return 0;
      recalcPlayer(game);
      return ACTION_COST;
    }
    case "drop": {
      const item = findItem(game, action.itemId);
      if (!item || !dropItem(game, item, action.quantity)) return 0;
      recalcPlayer(game);
      return ACTION_COST;
    }
    case "equip": {
      const item = findItem(game, action.itemId);
      if (!item || !equip(game, item)) return 0;
      recalcPlayer(game);
      return ACTION_COST;
    }
    case "unequip":
      if (!unequip(game, action.slot)) return 0;
      recalcPlayer(game);
      return ACTION_COST;
    case "quaff": {
      const item = findItem(game, action.itemId);
      return item ? quaff(game, item) : 0;
    }
    case "eat": {
      const item = findItem(game, action.itemId);
      return item ? eat(game, item) : 0;
    }
    case "throw": {
      const item = findItem(game, action.itemId);
      if (!item) return 0;
      const cost = throwItem(game, game.player, item, { x: action.tx, y: action.ty });
      recalcPlayer(game);
      return cost;
    }
    case "read": {
      const item = findItem(game, action.itemId);
      return item ? readItem(game, item, action.targetId) : 0;
    }
    case "zap": {
      const item = findItem(game, action.itemId);
      return item ? zapWand(game, item, { x: action.tx, y: action.ty }) : 0;
    }
  }
  return 0;
}
function doStairs(game, actor, dir) {
  if (!actor.isPlayer) return 0;
  const t = getTile(level(game).map, actor.x, actor.y);
  if (dir === "down") {
    if (t !== Tile.StairsDown) {
      message(game, "N\xE3o h\xE1 escada para baixo aqui.", "darkGray");
      return 0;
    }
    if (game.depth >= MAX_DEPTH) return 0;
    enterLevel(game, game.depth + 1, "up");
    return ACTION_COST;
  }
  if (t !== Tile.StairsUp) {
    message(game, "N\xE3o h\xE1 escada para cima aqui.", "darkGray");
    return 0;
  }
  if (game.depth === 1) {
    if (game.hasAmulet) {
      message(game, "Voc\xEA sobe para a luz do dia com o Cora\xE7\xE3o do Abismo nas m\xE3os!", "gold");
      game.over = { won: true, escaped: true, cause: "escapou do Abismo com o Cora\xE7\xE3o" };
      return ACTION_COST;
    }
    message(game, "A sa\xEDda est\xE1 bloqueada por uma for\xE7a m\xE1gica. S\xF3 o Cora\xE7\xE3o do Abismo pode abri-la.", "lightGray");
    return 0;
  }
  enterLevel(game, game.depth - 1, "down");
  return ACTION_COST;
}
function enterTile(game, t) {
  const p = game.player;
  if (t === Tile.Water) {
    if (hasStatus(p, "burning")) removeStatus(game, p, "burning");
    message(game, "Voc\xEA atravessa a \xE1gua gelada.", "lightBlue");
  } else if (t === Tile.Lava) {
    message(game, "A lava queima seus p\xE9s!", "orange");
    damage(game, p, Math.round(game.rng.loot.roll("4d6") * resistMult(p, "fire")));
    if (!game.over) addStatus(game, p, "burning", 3, 2);
    setDeathCause(game, "derretido na lava");
  } else if (t === Tile.Fountain) message(game, "H\xE1 uma fonte aqui (q para beber).", "lightCyan");
  else if (t === Tile.Altar) message(game, "H\xE1 um altar aqui. Largue itens sobre ele para sentir sua aura.", "white");
}
function drinkFountain(game) {
  const p = game.player;
  const map = level(game).map;
  if (getTile(map, p.x, p.y) !== Tile.Fountain) return 0;
  const roll = game.rng.loot.int(1, 100);
  if (roll <= 30) {
    p.hp = Math.min(p.maxHp, p.hp + game.rng.loot.roll("2d8"));
    message(game, "A \xE1gua \xE9 refrescante. Voc\xEA se sente melhor.", "lightGreen");
  } else if (roll <= 45) {
    p.mp = Math.min(p.maxMp, p.mp + game.rng.loot.roll("2d6"));
    message(game, "A \xE1gua formiga na sua l\xEDngua.", "lightBlue");
  } else if (roll <= 60) {
    addStatus(game, p, "poisoned", 6, 1);
  } else if (roll <= 68) {
    gainXp(game, 10 * game.depth);
    message(game, "Voc\xEA sente uma sabedoria antiga fluir em voc\xEA.", "gold");
  } else if (roll <= 75) {
    addStatus(game, p, "confused", 5);
  } else if (roll <= 80) {
    message(game, "Uma serpente d'\xE1gua salta da fonte!", "lightRed");
    const free = DIRS8.find((d) => isWalkable(map, p.x + d.x, p.y + d.y) && !actorAt(game, p.x + d.x, p.y + d.y));
    if (free) {
      const s = createMonster(game, monsterTemplate("serpent"), p.x + free.x, p.y + free.y, game.rng.loot);
      s.ai.state = "hunting";
      level(game).actors.push(s);
    }
  } else message(game, "A \xE1gua tem um gosto met\xE1lico.", "lightGray");
  if (game.rng.loot.chance(30)) {
    setTile(map, p.x, p.y, Tile.DryFountain);
    message(game, "A fonte seca.", "darkGray");
  }
  return ACTION_COST;
}
function doSearch(game) {
  const map = level(game).map;
  const p = game.player;
  const chance = 30 + (p.flags.includes("secretSense") ? 30 : 0) + 3 * game.hero.level;
  for (const d of DIRS8) {
    const x = p.x + d.x;
    const y = p.y + d.y;
    if (getTile(map, x, y) === Tile.SecretDoor && game.rng.loot.chance(chance)) {
      setTile(map, x, y, Tile.DoorClosed);
      message(game, "Voc\xEA encontra uma porta secreta!", "yellow");
    }
  }
  searchTraps(game, chance + (game.hero.classId === "rogue" ? 30 : 0));
  return ACTION_COST;
}
function doMove(game, actor, dx, dy) {
  if (hasStatus(actor, "confused") && game.rng.ai.chance(50)) {
    const d = game.rng.ai.pick(DIRS8);
    dx = d.x;
    dy = d.y;
    if (actor.isPlayer) message(game, "Voc\xEA cambaleia...", "magenta");
  }
  const nx = actor.x + dx;
  const ny = actor.y + dy;
  const map = level(game).map;
  const other = actorAt(game, nx, ny);
  if (other && actor.isPlayer && other.isPlayer) {
    other.x = actor.x;
    other.y = actor.y;
    actor.x = nx;
    actor.y = ny;
    const name = game.party?.members.find((m2) => m2.actor === other)?.name ?? "seu aliado";
    message(game, `Voc\xEA troca de lugar com ${name}.`, "darkGray");
    return ACTION_COST;
  }
  if (other) {
    if (actor.isPlayer || other.isPlayer) {
      if (hasStatus(actor, "afraid")) {
        if (actor.isPlayer) message(game, "Voc\xEA est\xE1 apavorado demais para atacar!", "orange");
        return actor.isPlayer ? 0 : ACTION_COST;
      }
      meleeAttack(game, actor, other);
      return game.hero.classId === "warrior" && actor.isPlayer && game.hero.level >= 15 ? 75 : ACTION_COST;
    }
    return 0;
  }
  const t = getTile(map, nx, ny);
  if (t === Tile.DoorClosed) {
    if (!actor.isPlayer && !hasFlag(actor, "opensDoors")) return 0;
    setTile(map, nx, ny, Tile.DoorOpen);
    if (map.visible[ny * map.width + nx]) emit(game, { type: "door" });
    if (actor.isPlayer) message(game, "Voc\xEA abre a porta.", "lightGray");
    else if (map.visible[ny * map.width + nx]) message(game, `${capitalize(theName(actor))} abre uma porta.`, "lightGray");
    return ACTION_COST;
  }
  if (t === Tile.DoorLocked) {
    if (actor.isPlayer) message(game, "A porta est\xE1 trancada.", "lightGray");
    return 0;
  }
  if (!isWalkable(map, nx, ny)) return 0;
  if (t === Tile.Lava && actor.isPlayer && (actor.resist?.fire ?? 0) < 100) {
    const key = `${game.depth},${nx},${ny}`;
    if (game.lavaWarned !== key && !hasStatus(actor, "confused")) {
      game.lavaWarned = key;
      message(game, "Isso \xE9 lava! Mova de novo nessa dire\xE7\xE3o para atravessar mesmo assim.", "orange");
      return 0;
    }
  }
  if (t === Tile.Lava && !actor.isPlayer && (actor.resist?.fire ?? 0) < 100) return 0;
  if (actor.isPlayer && burden(game) === 2) {
    message(game, "Voc\xEA est\xE1 carregando peso demais para andar!", "orange");
    return 0;
  }
  actor.x = nx;
  actor.y = ny;
  if (actor.isPlayer) {
    for (const it of itemsAt(level(game), nx, ny)) if (itemBase(it.baseId).category === "gold") pickUp(game, it);
    describeFloor(game);
    enterTile(game, t);
    const trap = trapAt(game, nx, ny);
    if (trap) triggerTrap(game, trap);
  }
  return ACTION_COST;
}

// src/ai/pathing.ts
var UNREACHABLE = 1e9;
function pathable(map, x, y) {
  const t = map.tiles[idx(map, x, y)];
  if (t === Tile.Lava) return false;
  return tileDef(t).walkable || t === Tile.DoorClosed;
}
function dijkstraMap(map, goals) {
  const dist = new Array(map.width * map.height).fill(UNREACHABLE);
  const queue = [];
  for (const g of goals) {
    dist[idx(map, g.x, g.y)] = 0;
    queue.push(g);
  }
  for (let head = 0; head < queue.length; head++) {
    const p = queue[head];
    const d = dist[idx(map, p.x, p.y)];
    for (const dir of DIRS8) {
      const nx = p.x + dir.x;
      const ny = p.y + dir.y;
      if (!inBounds(map, nx, ny) || !pathable(map, nx, ny)) continue;
      const i = idx(map, nx, ny);
      if (dist[i] <= d + 1) continue;
      dist[i] = d + 1;
      queue.push({ x: nx, y: ny });
    }
  }
  return dist;
}
var cache = /* @__PURE__ */ new WeakMap();
function distanceMapTo(map, target, turn) {
  let c = cache.get(map);
  if (!c || c.turn !== turn) {
    c = { turn, byTarget: /* @__PURE__ */ new Map() };
    cache.set(map, c);
  }
  const key = `${target.x},${target.y}`;
  let dist = c.byTarget.get(key);
  if (!dist) {
    dist = dijkstraMap(map, [target]);
    c.byTarget.set(key, dist);
  }
  return dist;
}
function stepDownhill(map, dist, from, blocked) {
  let best = null;
  let bestD = dist[idx(map, from.x, from.y)];
  for (const d of DIRS8) {
    const nx = from.x + d.x;
    const ny = from.y + d.y;
    if (!inBounds(map, nx, ny) || blocked(nx, ny)) continue;
    const v = dist[idx(map, nx, ny)];
    if (v < bestD) {
      bestD = v;
      best = d;
    }
  }
  return best;
}

// src/ai/behaviors.ts
var SIGHT = 10;
var GIVE_UP = 20;
function canSeePlayer(game, m2) {
  const p = game.player;
  if (playerHidden(game) && distance(m2, p) > 1) return false;
  if (hasStatus(p, "invisible") && distance(m2, p) > 1) return false;
  if (hasStatus(m2, "blind") && distance(m2, p) > 1) return false;
  if (m2.ai.state === "sleeping" && p.flags.includes("stealthy") && distance(m2, p) > 2) return false;
  if (distance(m2, p) > SIGHT) return false;
  return hasLineOfSight(level(game).map, m2.x, m2.y, p.x, p.y);
}
function special(game, m2) {
  const rng = game.rng.ai;
  const d = distance(m2, game.player);
  if ((m2.specialReady ?? 0) > game.turn || d > 8) return null;
  if ((hasFlag(m2, "breathFire") || hasFlag(m2, "breathLightning")) && d >= 2 && rng.chance(30)) return { type: "special", kind: "breath" };
  if (hasFlag(m2, "caster") && rng.chance(d === 1 ? 20 : 40)) return { type: "special", kind: "cast" };
  if (hasFlag(m2, "archer") && d >= 2 && rng.chance(65)) return { type: "special", kind: "shoot" };
  return null;
}
function decideAction(game, m2) {
  const rng = game.rng.ai;
  const sees = canSeePlayer(game, m2);
  if (hasFlag(m2, "stationary")) {
    const p = game.player;
    if (m2.ai.state !== "sleeping" && sees && distance(m2, p) === 1) return { type: "move", dx: p.x - m2.x, dy: p.y - m2.y };
    if (m2.ai.state === "sleeping" && sees && distance(m2, p) <= 2) m2.ai.state = "hunting";
    return { type: "wait" };
  }
  switch (m2.ai.state) {
    case "sleeping": {
      const wakeChance = hasFlag(m2, "boss") ? 100 : distance(m2, game.player) <= 3 ? 40 : 15;
      if (sees && rng.chance(wakeChance)) {
        m2.ai.state = "hunting";
        m2.ai.lastSeen = { x: game.player.x, y: game.player.y };
        if (level(game).map.visible[m2.y * level(game).map.width + m2.x]) message(game, `${capitalize(theName(m2))} acorda!`, "orange");
      }
      return { type: "wait" };
    }
    case "wandering":
      if (sees) {
        m2.ai.state = "hunting";
        m2.ai.lastSeen = { x: game.player.x, y: game.player.y };
        return hunt(game, m2);
      }
      return wander(game, m2);
    case "fleeing":
      if ((m2.ai.fleeUntil ?? 0) <= game.turn) {
        m2.ai.state = "hunting";
        return hunt(game, m2);
      }
      return flee(game, m2);
    case "hunting":
      if (sees) {
        m2.ai.lastSeen = { x: game.player.x, y: game.player.y };
        m2.ai.lostTurns = 0;
        if (m2.hp < m2.maxHp * 0.2 && !hasFlag(m2, "boss") && !hasFlag(m2, "undead") && rng.chance(25)) {
          m2.ai.state = "fleeing";
          m2.ai.fleeUntil = game.turn + 10;
          return flee(game, m2);
        }
        const sp = hasLineOfSight(level(game).map, m2.x, m2.y, game.player.x, game.player.y) ? special(game, m2) : null;
        if (sp) return sp;
      } else if (++m2.ai.lostTurns > GIVE_UP) {
        m2.ai.state = "wandering";
        m2.ai.lostTurns = 0;
        return wander(game, m2);
      }
      return hunt(game, m2);
  }
}
function blockedFor(game, m2) {
  const map = level(game).map;
  return (x, y) => {
    const other = actorAt(game, x, y);
    if (other && !other.isPlayer) return true;
    const t = map.tiles[y * map.width + x];
    if (t === Tile.DoorClosed) return !hasFlag(m2, "opensDoors");
    if (t === Tile.Lava && (m2.resist?.fire ?? 0) < 100) return true;
    return !isWalkable(map, x, y) && !other;
  };
}
function hunt(game, m2) {
  const rng = game.rng.ai;
  if (hasFlag(m2, "erratic") && rng.chance(40)) return randomStep(game, m2);
  const target = m2.ai.lastSeen ?? { x: game.player.x, y: game.player.y };
  const p = game.player;
  if (distance(m2, p) === 1 && canSeePlayer(game, m2)) return { type: "move", dx: p.x - m2.x, dy: p.y - m2.y };
  const map = level(game).map;
  const dist = distanceMapTo(map, target, game.turn);
  const step2 = stepDownhill(map, dist, m2, blockedFor(game, m2));
  if (!step2) {
    if (m2.x === target.x && m2.y === target.y) m2.ai.state = "wandering";
    return { type: "wait" };
  }
  return { type: "move", dx: step2.x, dy: step2.y };
}
function flee(game, m2) {
  const p = game.player;
  const blocked = blockedFor(game, m2);
  let best = null;
  let bestD = distance(m2, p);
  for (const d of DIRS8) {
    const nx = m2.x + d.x;
    const ny = m2.y + d.y;
    if (blocked(nx, ny) || nx === p.x && ny === p.y) continue;
    const nd = distance({ x: nx, y: ny }, p);
    if (nd > bestD) {
      bestD = nd;
      best = d;
    }
  }
  if (best) return { type: "move", dx: best.x, dy: best.y };
  if (distance(m2, p) === 1) return { type: "move", dx: p.x - m2.x, dy: p.y - m2.y };
  return { type: "wait" };
}
function wander(game, m2) {
  const rng = game.rng.ai;
  const lvl = level(game);
  if (!m2.ai.wanderTarget || m2.x === m2.ai.wanderTarget.x && m2.y === m2.ai.wanderTarget.y || rng.chance(3)) {
    m2.ai.wanderTarget = void 0;
    for (let tries = 0; tries < 30 && !m2.ai.wanderTarget; tries++) {
      const x = rng.int(1, lvl.map.width - 2);
      const y = rng.int(1, lvl.map.height - 2);
      if (isWalkable(lvl.map, x, y)) m2.ai.wanderTarget = { x, y };
    }
    if (!m2.ai.wanderTarget) return randomStep(game, m2);
  }
  if (rng.chance(30)) return { type: "wait" };
  const dist = distanceMapTo(lvl.map, m2.ai.wanderTarget, game.turn);
  const step2 = stepDownhill(lvl.map, dist, m2, blockedFor(game, m2));
  if (!step2) {
    m2.ai.wanderTarget = void 0;
    return randomStep(game, m2);
  }
  return { type: "move", dx: step2.x, dy: step2.y };
}
function randomStep(game, m2) {
  const blocked = blockedFor(game, m2);
  const options = DIRS8.filter((d2) => !blocked(m2.x + d2.x, m2.y + d2.y));
  if (options.length === 0) return { type: "wait" };
  const d = game.rng.ai.pick(options);
  return { type: "move", dx: d.x, dy: d.y };
}

// src/core/turn.ts
function resolveFall(game) {
  if (!game.pendingFall || game.over) return;
  game.pendingFall = false;
  enterLevel(game, game.depth + 1, "up");
  teleportActor(game, game.player);
  damage(game, game.player, game.rng.loot.roll("1d6"));
  setDeathCause(game, "morto na queda de um al\xE7ap\xE3o");
}
function hungerAndFuel(game) {
  const hero = game.hero;
  const p = game.player;
  const before = hero.nutrition;
  hero.nutrition -= p.flags.includes("regen") ? 2 : 1;
  const crossed = (limit) => before >= limit && hero.nutrition < limit;
  if (crossed(600)) message(game, "Voc\xEA est\xE1 com fome.", "yellow");
  if (crossed(150)) {
    message(game, "Voc\xEA est\xE1 fraco de fome!", "lightRed");
    recalcPlayer(game);
  }
  if (hero.nutrition <= 0 && game.rng.loot.chance(10) && !hasStatus(p, "asleep")) {
    message(game, "Voc\xEA desmaia de fome!", "red");
    addStatus(game, p, "asleep", game.rng.loot.int(2, 4));
  }
  if (hero.nutrition <= -400) {
    damage(game, p, p.hp);
    setDeathCause(game, "morreu de fome");
  }
  const light = equipped(game, "light");
  if (light?.fuel !== void 0 && light.fuel > 0) {
    light.fuel--;
    if (light.fuel === 200) message(game, "Sua luz est\xE1 ficando fraca.", "yellow");
    if (light.fuel === 0) {
      message(game, "Sua luz se apaga! Voc\xEA est\xE1 no escuro.", "lightRed");
      recalcPlayer(game);
    }
  }
}
var REGEN_INTERVAL = 10;
function heroRegen(game) {
  const p = game.player;
  if (game.turn % REGEN_INTERVAL === 0 && p.hp < p.maxHp && !hasStatus(p, "poisoned")) p.hp++;
  if (p.flags.includes("regen") && game.turn % 3 === 0 && p.hp < p.maxHp) p.hp++;
  if (game.turn % 4 === 0 && game.hero.raceId === "half_orc" && p.hp < p.maxHp) p.hp++;
  const mpInterval = Math.max(3, 12 - Math.floor(p.level / 3));
  if (game.turn % mpInterval === 0 && p.mp < p.maxMp) p.mp++;
}

// src/core/party.ts
var PARTY_COLORS = ["#5ad8ff", "#ff7ad8", "#ffd24a", "#7aff8a"];
var MAX_PARTY = 4;
var members = (game) => game.party?.members ?? [];
var aliveMembers = (game) => members(game).filter((m2) => !m2.dead);
var memberById = (game, id) => members(game).find((m2) => m2.id === id);
var memberOfActor = (game, a) => members(game).find((m2) => m2.actor === a || m2.id === a.id);
function setPerspective(game, m2) {
  game.player = m2.actor;
  game.hero = m2.hero;
  const map = level(game).map;
  if (m2.visible.length !== map.tiles.length) m2.visible = new Array(map.tiles.length).fill(0);
  map.visible = m2.visible;
}
function createPartyGame(seed, specs) {
  if (!specs.length) throw new Error("grupo vazio");
  const game = createGame(seed, specs[0]);
  const first = {
    id: game.player.id,
    name: specs[0].name,
    actor: game.player,
    hero: game.hero,
    visible: level(game).map.visible,
    dead: false,
    connected: true,
    color: PARTY_COLORS[0]
  };
  game.party = { members: [first], queue: {}, waiting: [] };
  specs.slice(1, MAX_PARTY).forEach((spec, i) => addMember(game, spec, PARTY_COLORS[(i + 1) % PARTY_COLORS.length]));
  setPerspective(game, first);
  refreshAll(game);
  game.events = [];
  return game;
}
function addMember(game, spec, color) {
  const actor = createActor(newId(game), { templateId: "player", name: "voc\xEA", glyph: "@", color: "white", isPlayer: true, energy: ACTION_COST });
  const hero = createHero(spec.name, spec.raceId, spec.classId, spec.rollSeed !== void 0 ? new RNG(spec.rollSeed) : void 0);
  const m2 = { id: actor.id, name: spec.name, actor, hero, visible: [], dead: false, connected: true, color };
  const leader = members(game)[0].actor;
  game.party.members.push(m2);
  const spot = freeSpotNear(game, leader);
  actor.x = spot.x;
  actor.y = spot.y;
  setPerspective(game, m2);
  giveStartingKit(game);
  for (const it of hero.inventory) learn(game, it.baseId);
  recalcPlayer(game);
  actor.hp = actor.maxHp;
  actor.mp = actor.maxMp;
  return m2;
}
function freeSpotNear(game, p) {
  const map = level(game).map;
  for (let r = 1; r <= 8; r++) {
    for (let dy = -r; dy <= r; dy++) {
      for (let dx = -r; dx <= r; dx++) {
        if (Math.max(Math.abs(dx), Math.abs(dy)) !== r) continue;
        const x = p.x + dx;
        const y = p.y + dy;
        if (isWalkable(map, x, y) && !actorAt(game, x, y)) return { x, y };
      }
    }
  }
  return { x: p.x, y: p.y };
}
function refreshAll(game) {
  const keep = game.player;
  for (const m2 of aliveMembers(game)) {
    setPerspective(game, m2);
    refreshFov(game);
  }
  const back = memberOfActor(game, keep);
  if (back) setPerspective(game, back);
}
function nearestMember(game, a) {
  let best;
  let bestD = Infinity;
  for (const m2 of aliveMembers(game)) {
    const d = Math.max(Math.abs(m2.actor.x - a.x), Math.abs(m2.actor.y - a.y));
    if (d < bestD) {
      best = m2;
      bestD = d;
    }
  }
  return best;
}
function partyArrives(game, traveller) {
  const map = level(game).map;
  for (const m2 of members(game)) {
    m2.visible = new Array(map.tiles.length).fill(0);
    if (m2.actor === traveller) continue;
    if (m2.dead) {
      m2.dead = false;
      m2.cause = void 0;
      m2.actor.hp = Math.max(1, Math.ceil(m2.actor.maxHp / 2));
      m2.actor.effects = [];
      m2.actor.energy = ACTION_COST;
      message(game, `${m2.name} se levanta de novo!`, "lightGreen", null);
    }
    const spot = freeSpotNear(game, traveller);
    m2.actor.x = spot.x;
    m2.actor.y = spot.y;
  }
  game.party.queue = {};
  if (members(game).length > 1) message(game, "O grupo segue junto.", "darkGray", null);
  const back = memberOfActor(game, traveller);
  refreshAll(game);
  if (back) setPerspective(game, back);
}
function memberFalls(game, a, cause) {
  const m2 = memberOfActor(game, a);
  if (!m2) return false;
  m2.dead = true;
  m2.cause = cause;
  m2.actor.effects = [];
  delete game.party.queue[m2.id];
  message(game, `${m2.name} cai!`, "red", null);
  return aliveMembers(game).length > 0;
}
function queueAction(game, id, action) {
  const m2 = memberById(game, id);
  if (!m2 || m2.dead || game.over) return;
  if (FREE_ACTIONS.has(action.type)) {
    const keep = game.player;
    setPerspective(game, m2);
    perform(game, m2.actor, action);
    const back = memberOfActor(game, keep);
    if (back) setPerspective(game, back);
    return;
  }
  game.party.queue[id] = action;
}
var FREE_ACTIONS = /* @__PURE__ */ new Set(["raiseStat"]);
function advanceParty(game) {
  const party = game.party;
  if (!party) return [];
  for (let guard = 0; guard < 2e4; guard++) {
    if (game.over) return party.waiting = [];
    const ready = aliveMembers(game).filter((m2) => m2.actor.energy >= ACTION_COST);
    if (ready.length) {
      let progressed = false;
      const waiting = [];
      for (const m2 of ready) {
        if (m2.dead || m2.actor.energy < ACTION_COST) continue;
        setPerspective(game, m2);
        if (isIncapacitated(m2.actor)) {
          m2.actor.energy -= ACTION_COST;
          progressed = true;
          continue;
        }
        const action = party.queue[m2.id] ?? (m2.connected ? void 0 : { type: "search" });
        if (!action) {
          waiting.push(m2.id);
          continue;
        }
        delete party.queue[m2.id];
        const cost = perform(game, m2.actor, action);
        if (cost > 0) {
          m2.actor.energy -= cost;
          progressed = true;
          resolveFall(game);
        } else waiting.push(m2.id);
        refreshAll(game);
        if (game.over) return party.waiting = [];
      }
      if (!progressed) {
        party.waiting = waiting;
        const first = memberById(game, waiting[0]);
        if (first) setPerspective(game, first);
        return waiting;
      }
      continue;
    }
    let acted = false;
    for (const mon of [...level(game).actors]) {
      if (game.over) return party.waiting = [];
      if (mon.hp <= 0 || mon.energy < ACTION_COST) continue;
      if (isIncapacitated(mon)) {
        mon.energy -= ACTION_COST;
        acted = true;
        continue;
      }
      const target = nearestMember(game, mon);
      if (!target) break;
      setPerspective(game, target);
      const cost = perform(game, mon, decideAction(game, mon));
      mon.energy -= cost > 0 ? cost : ACTION_COST;
      acted = true;
    }
    if (acted) refreshAll(game);
    else tickParty(game);
  }
  return party.waiting = [];
}
function tickParty(game) {
  game.turn++;
  for (const m2 of aliveMembers(game)) m2.actor.energy += effectiveSpeed(m2.actor);
  for (const a of level(game).actors) a.energy += effectiveSpeed(a);
  for (const m2 of aliveMembers(game)) {
    if (!m2.actor.effects?.length) continue;
    setPerspective(game, m2);
    const { damage: dmg, cause } = tickStatuses(game, m2.actor);
    if (dmg > 0) {
      damage(game, m2.actor, dmg);
      if (cause && m2.dead) m2.cause = cause;
      if (cause && game.over && !game.over.won) game.over.cause = cause;
    }
    if (game.over) return;
  }
  for (const a of [...level(game).actors]) {
    if (!a.effects?.length) continue;
    const near = nearestMember(game, a);
    if (near) setPerspective(game, near);
    const { damage: dmg } = tickStatuses(game, a);
    if (dmg > 0) damage(game, a, dmg);
    if (game.over) return;
  }
  for (const m2 of aliveMembers(game)) {
    setPerspective(game, m2);
    hungerAndFuel(game);
    if (game.over) return;
    if (!m2.dead) heroRegen(game);
  }
  if (game.turn % 10 === 0) {
    for (const a of level(game).actors) if (a.hp < a.maxHp && !hasStatus(a, "poisoned")) a.hp++;
  }
  if (game.turn % 4 === 0) {
    for (const a of level(game).actors) if (a.flags.includes("regenerates") && a.hp < a.maxHp) a.hp += 2;
  }
}

// src/net/protocol.ts
var LOG_TAIL = 60;
function snapshotFor(game, memberId) {
  const lvl = level(game);
  const me = memberById(game, memberId);
  const viewer = me && me.dead ? aliveMembers(game)[0] ?? me : me;
  const n = lvl.map.tiles.length;
  const visible = viewer && viewer.visible.length === n ? viewer.visible : new Array(n).fill(0);
  const { events: _e, rng: _r, levels: _l, log, player: _p, hero: _h, party, ...rest } = game;
  const out = {
    ...rest,
    levels: { [game.depth]: { ...lvl, map: { ...lvl.map, visible } } },
    log: log.slice(-LOG_TAIL),
    party: party && { ...party, members: party.members.map((m2) => ({ ...m2, visible: [] })) }
  };
  return JSON.stringify(out);
}
var LAN_PORT = 8080;

// src/net/room.ts
var MAX_CHAT = 20;
var clean = (s, max) => String(s ?? "").replace(/[\u0000-\u001f{}]/g, "").trim().slice(0, max);
var Room = class {
  constructor(newSeed = () => Date.now() >>> 0, newToken = () => globalThis.crypto.randomUUID()) {
    this.newSeed = newSeed;
    this.newToken = newToken;
  }
  players = [];
  game = null;
  chat = [];
  seq = 0;
  /** Primeiro jogador conectado: é quem inicia a partida. */
  get leader() {
    return this.players.find((p) => p.conn) ?? null;
  }
  handle(conn, msg) {
    if (msg.t === "hello") {
      this.hello(conn, msg);
      return;
    }
    const p = this.players.find((x) => x.conn === conn);
    if (!p) {
      conn.send({ t: "error", text: "Entre na sala primeiro." });
      return;
    }
    switch (msg.t) {
      case "ready":
        if (!this.game) {
          p.ready = !!msg.ready;
          this.broadcastLobby();
        }
        break;
      case "start":
        this.start(p);
        break;
      case "action":
        if (this.game && p.memberId !== void 0 && msg.action && typeof msg.action.type === "string") {
          queueAction(this.game, p.memberId, msg.action);
          this.advance();
        }
        break;
      case "chat":
        this.say(p, msg.text);
        break;
    }
  }
  hello(conn, msg) {
    const old = msg.token ? this.players.find((p2) => p2.token === msg.token) : void 0;
    if (old) {
      old.conn = conn;
      conn.send({ t: "welcome", id: old.id, token: old.token });
      const m2 = this.game && old.memberId !== void 0 ? memberById(this.game, old.memberId) : void 0;
      if (m2) {
        m2.connected = true;
        message(this.game, `${old.name} voltou.`, "lightGray", null);
        this.sendState(old, []);
      }
      this.broadcastLobby();
      return;
    }
    if (this.game) {
      conn.send({ t: "error", text: "J\xE1 h\xE1 uma partida em andamento nesta sala. Espere ela acabar." });
      return;
    }
    if (this.players.length >= MAX_PARTY) {
      conn.send({ t: "error", text: `A sala est\xE1 cheia (${MAX_PARTY} jogadores).` });
      return;
    }
    const id = `p${++this.seq}`;
    const p = {
      id,
      token: this.newToken(),
      name: clean(msg.name, 16) || `Jogador ${this.seq}`,
      raceId: RACES.some((r) => r.id === msg.raceId) ? msg.raceId : RACES[0].id,
      classId: CLASSES.some((c) => c.id === msg.classId) ? msg.classId : CLASSES[0].id,
      ready: false,
      conn
    };
    this.players.push(p);
    conn.send({ t: "welcome", id, token: p.token });
    this.broadcastLobby();
  }
  /** A conexão caiu: na sala de espera o jogador sai; na partida, o herói passa a esperar. */
  disconnect(conn) {
    const p = this.players.find((x) => x.conn === conn);
    if (!p) return;
    p.conn = null;
    if (!this.game) {
      this.players = this.players.filter((x) => x !== p);
      this.broadcastLobby();
      return;
    }
    if (!this.players.some((x) => x.conn)) {
      this.game = null;
      this.players = [];
      return;
    }
    const m2 = p.memberId !== void 0 ? memberById(this.game, p.memberId) : void 0;
    if (m2) {
      m2.connected = false;
      message(this.game, `${p.name} se desconectou (o her\xF3i fica esperando).`, "darkGray", null);
    }
    this.advance();
  }
  start(p) {
    if (this.game) return;
    if (p !== this.leader) {
      p.conn?.send({ t: "error", text: "S\xF3 o l\xEDder da sala (o primeiro a entrar) pode iniciar." });
      return;
    }
    const active = this.players.filter((x) => x.conn);
    if (active.some((x) => x !== p && !x.ready)) {
      p.conn?.send({ t: "error", text: 'Espere todos marcarem "pronto".' });
      return;
    }
    const game = createPartyGame(this.newSeed(), active.map((x) => ({ name: x.name, raceId: x.raceId, classId: x.classId })));
    active.forEach((x, i) => x.memberId = game.party.members[i].id);
    this.players = active;
    this.game = game;
    if (active.length > 1) message(game, `Grupo: ${active.map((x) => x.name).join(", ")}. Fiquem juntos!`, "yellow", null);
    this.advance();
  }
  say(p, text) {
    const t = clean(text, 120);
    if (!t) return;
    if (this.game) {
      message(this.game, `${p.name}: ${t}`, "lightCyan", null);
      this.broadcastState([]);
      return;
    }
    this.chat.push(`${p.name}: ${t}`);
    if (this.chat.length > MAX_CHAT) this.chat.splice(0, this.chat.length - MAX_CHAT);
    this.broadcastLobby();
  }
  /** Roda o mundo até alguém precisar decidir e manda o estado a todos. */
  advance() {
    const g = this.game;
    if (!g) return;
    advanceParty(g);
    const events = g.events;
    g.events = [];
    this.broadcastState(events);
    if (g.over) this.finish();
  }
  /** Fim da partida: a sala volta a esperar (os jogadores continuam conectados). */
  finish() {
    this.game = null;
    this.players = this.players.filter((p) => p.conn);
    for (const p of this.players) {
      p.ready = false;
      p.memberId = void 0;
    }
    this.broadcastLobby();
  }
  sendState(p, events) {
    const g = this.game;
    if (!g || !p.conn || p.memberId === void 0) return;
    p.conn.send({ t: "state", you: p.memberId, snapshot: snapshotFor(g, p.memberId), events, waiting: g.party?.waiting ?? [] });
  }
  broadcastState(events) {
    for (const p of this.players) this.sendState(p, events);
  }
  lobby() {
    const leader = this.leader;
    const players = this.players.map((p) => ({
      id: p.id,
      name: p.name,
      raceId: p.raceId,
      classId: p.classId,
      ready: p.ready,
      leader: p === leader,
      connected: !!p.conn
    }));
    return { t: "lobby", players, inGame: !!this.game, chat: [...this.chat] };
  }
  broadcastLobby() {
    const msg = this.lobby();
    for (const p of this.players) p.conn?.send(msg);
  }
};

// server/lan.ts
var ROOT = resolve(dirname(fileURLToPath(import.meta.url)), "..");
var DIST = join(ROOT, "dist");
var argPort = process.argv.indexOf("--port");
var PORT = Number(process.env.PORT ?? (argPort > 0 ? process.argv[argPort + 1] : LAN_PORT));
var TYPES = {
  ".html": "text/html; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".png": "image/png",
  ".svg": "image/svg+xml",
  ".ico": "image/x-icon",
  ".json": "application/json",
  ".woff2": "font/woff2"
};
var LAN_FLAG = "<script>window.__ABISMO_LAN__ = true;</script>";
async function serveFile(req, res) {
  if (!existsSync(DIST)) {
    res.writeHead(500, { "content-type": "text/plain; charset=utf-8" });
    res.end('O jogo ainda n\xE3o foi compilado. Rode "npm run lan" (ou "npm run build" e depois o servidor).');
    return;
  }
  const url = new URL(req.url ?? "/", "http://localhost");
  const rel = normalize(decodeURIComponent(url.pathname)).replace(/^([/\\])+/, "");
  const file = resolve(DIST, rel || "index.html");
  if (file !== DIST && !file.startsWith(DIST + sep)) {
    res.writeHead(403).end();
    return;
  }
  const target = existsSync(file) && extname(file) ? file : join(DIST, "index.html");
  try {
    let body = await readFile(target);
    const type = TYPES[extname(target)] ?? "application/octet-stream";
    if (target.endsWith("index.html")) body = body.toString("utf-8").replace("<head>", `<head>${LAN_FLAG}`);
    res.writeHead(200, { "content-type": type, "cache-control": "no-cache" });
    res.end(body);
  } catch {
    res.writeHead(404).end();
  }
}
var http = createServer((req, res) => void serveFile(req, res));
var wss = new WebSocketServer({ server: http, path: "/ws" });
var fixedSeed = process.env.ABISMO_SEED ? Number(process.env.ABISMO_SEED) >>> 0 : void 0;
var room = new Room(() => fixedSeed ?? Date.now() >>> 0);
wss.on("connection", (ws, req) => {
  const who = req.socket.remoteAddress ?? "?";
  const conn = {
    send: (msg) => {
      if (ws.readyState === 1) ws.send(JSON.stringify(msg));
    }
  };
  let alive = true;
  ws.on("pong", () => alive = true);
  const ping = setInterval(() => {
    if (!alive) {
      ws.terminate();
      return;
    }
    alive = false;
    ws.ping();
  }, 15e3);
  ws.on("message", (data) => {
    let msg;
    try {
      msg = JSON.parse(String(data));
    } catch {
      conn.send({ t: "error", text: "Mensagem inv\xE1lida." });
      return;
    }
    try {
      if (msg.t === "hello") console.log(`  + ${msg.name} entrou (${who})`);
      if (msg.t === "start") console.log("  \u25B6 partida iniciada");
      room.handle(conn, msg);
    } catch (e) {
      console.error("Erro ao tratar mensagem:", e);
      conn.send({ t: "error", text: "Erro no servidor (veja o terminal do anfitri\xE3o)." });
    }
  });
  ws.on("close", () => {
    clearInterval(ping);
    console.log(`  - conex\xE3o encerrada (${who})`);
    room.disconnect(conn);
  });
});
function lanAddresses() {
  const out = [];
  for (const list of Object.values(networkInterfaces())) {
    for (const a of list ?? []) if (a.family === "IPv4" && !a.internal) out.push(a.address);
  }
  return out;
}
http.on("error", (e) => {
  if (e.code === "EADDRINUSE") console.error(`A porta ${PORT} j\xE1 est\xE1 em uso. Use outra: npm run lan -- --port 8090`);
  else console.error(e);
  process.exit(1);
});
http.listen(PORT, "0.0.0.0", () => {
  console.log("\n  ABISMO \u2014 servidor da rede local\n");
  console.log(`  Neste computador:   http://localhost:${PORT}`);
  const ips = lanAddresses();
  for (const ip of ips) console.log(`  Na rede (amigos):   http://${ip}:${PORT}`);
  if (!ips.length) console.log("  (nenhuma rede encontrada \u2014 conecte-se ao Wi-Fi/cabo)");
  console.log('\n  Todos abrem o endere\xE7o no navegador \u2192 "Multijogador (rede local)".');
  console.log("  Se o Windows perguntar, permita o Node.js na rede privada (firewall).");
  console.log("  Ctrl+C encerra.\n");
});
